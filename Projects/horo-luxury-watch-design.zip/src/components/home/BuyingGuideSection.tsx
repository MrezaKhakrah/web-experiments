import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { guides } from "@/lib/guides-content";
import { toPersianDigits } from "@/lib/format";

export function BuyingGuideSection() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
      <div className="mb-8 flex items-end justify-between">
        <div>
          <h2 className="text-xl font-bold text-ink sm:text-2xl">راهنمای خرید</h2>
          <p className="mt-1.5 text-sm text-muted">محتوای کاربردی برای تصمیم‌گیری بهتر</p>
        </div>
        <Link href="/guides" className="hidden text-xs font-medium text-champagne-dark hover:underline sm:block">
          مشاهده همه مقالات
        </Link>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {guides.slice(0, 5).map((guide) => (
          <Link
            key={guide.slug}
            href={`/guides/${guide.slug}`}
            className="group flex flex-col justify-between rounded-md border border-border bg-paper p-5 transition-shadow hover:shadow-card"
          >
            <div>
              <h3 className="text-sm font-semibold leading-6 text-ink">{guide.title}</h3>
              <p className="mt-2 line-clamp-2 text-xs leading-6 text-muted">{guide.excerpt}</p>
            </div>
            <div className="mt-5 flex items-center justify-between text-xs text-muted">
              <span>{toPersianDigits(guide.readMinutes)} دقیقه مطالعه</span>
              <ArrowLeft size={14} className="rtl:-scale-x-100 text-champagne-dark transition-transform group-hover:-translate-x-0.5" />
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
