import { ShieldCheck, Truck, RotateCcw, CreditCard, Headset, BadgeCheck } from "lucide-react";

const items = [
  { icon: BadgeCheck, title: "ضمانت اصالت کالا", desc: "تمامی محصولات هورو دارای کد اصالت و فاکتور رسمی هستند." },
  { icon: ShieldCheck, title: "گارانتی رسمی", desc: "ضمانت تعویض و تعمیر مطابق شرایط اعلام‌شده در صفحه هر محصول." },
  { icon: Truck, title: "ارسال سراسری", desc: "ارسال به سراسر کشور با زمان تحویل تخمینی در صفحه پرداخت." },
  { icon: RotateCcw, title: "بازگشت کالا", desc: "امکان بازگشت کالای سالم طبق شرایط اعلام‌شده در راهنمای بازگشت." },
  { icon: CreditCard, title: "پرداخت امن", desc: "پرداخت آنلاین از طریق درگاه‌های معتبر بانکی یا پرداخت در محل." },
  { icon: Headset, title: "پشتیبانی تخصصی", desc: "مشاوره خرید و پاسخ‌گویی پیش و پس از خرید توسط تیم هورو." },
];

export function TrustSection() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-ink sm:text-2xl">چرا هورو</h2>
        <p className="mt-1.5 text-sm text-muted">خدماتی که واقعاً ارائه می‌کنیم</p>
      </div>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((item) => (
          <div key={item.title} className="flex items-start gap-4 rounded-md border border-border bg-paper p-5">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-surface text-champagne-dark">
              <item.icon size={20} />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-ink">{item.title}</h3>
              <p className="mt-1 text-xs leading-6 text-muted">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
