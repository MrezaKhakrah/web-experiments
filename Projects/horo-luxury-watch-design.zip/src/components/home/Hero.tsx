import Image from "next/image";
import Link from "next/link";

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-ink">
      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-8 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:gap-12 lg:py-0">
        <div className="relative z-10 order-2 lg:order-1">
          <p className="mb-4 text-xs font-medium tracking-[0.2em] text-champagne-light">HORO — TIME, REFINED</p>
          <h1 className="text-balance text-3xl font-bold leading-[1.3] text-paper sm:text-4xl lg:text-5xl">
            دقتی که می‌بینید،
            <br />
            زمانی که احساس می‌کنید.
          </h1>
          <p className="mt-5 max-w-md text-sm leading-7 text-paper/70 sm:text-base">
            از ساعت‌های هوشمند تا مکانیکال‌های سوئیسی؛ مجموعه‌ای منتخب برای کسانی که جزئیات برایشان اهمیت دارد.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link
              href="/products"
              className="rounded-sm bg-champagne px-6 py-3.5 text-sm font-semibold text-ink transition-colors hover:bg-champagne-light"
            >
              مشاهده ساعت‌ها
            </Link>
            <Link
              href="/products?category=luxury"
              className="rounded-sm border border-paper/30 px-6 py-3.5 text-sm font-semibold text-paper transition-colors hover:bg-paper/10"
            >
              کشف مجموعه لوکس
            </Link>
          </div>
        </div>

        <div className="relative order-1 aspect-[4/3] w-full overflow-hidden rounded-md lg:order-2 lg:aspect-auto lg:h-[560px] lg:rounded-none">
          <Image
            src="/images/hero-main.jpg"
            alt="ساعت کرونوگراف استیل هورو هریتیج روی سطحی تیره با نور ملایم طلایی"
            fill
            priority
            sizes="(max-width: 1024px) 100vw, 50vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/40 via-transparent to-transparent lg:bg-gradient-to-l" />
        </div>
      </div>
    </section>
  );
}
