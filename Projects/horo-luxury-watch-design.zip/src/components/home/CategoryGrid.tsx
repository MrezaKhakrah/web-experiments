import Image from "next/image";
import Link from "next/link";

const tiles = [
  { label: "ساعت‌های هوشمند", href: "/products?category=smartwatches", image: "/images/category-smartwatch.jpg" },
  { label: "ساعت‌های کلاسیک", href: "/products?category=classic", image: "/images/category-classic.jpg" },
  { label: "ساعت‌های اسپرت", href: "/products?category=sport", image: "/images/category-sport.jpg" },
  { label: "ساعت‌های لوکس", href: "/products?category=luxury", image: "/images/category-luxury.jpg" },
  { label: "مردانه", href: "/products?gender=men", image: "/images/category-mens.jpg" },
  { label: "زنانه", href: "/products?gender=women", image: "/images/category-womens.jpg" },
  { label: "لوازم جانبی", href: "/products?category=accessories", image: "/images/category-accessories.jpg" },
];

export function CategoryGrid() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
      <div className="mb-8 flex items-end justify-between">
        <div>
          <h2 className="text-xl font-bold text-ink sm:text-2xl">خرید بر اساس دسته‌بندی</h2>
          <p className="mt-1.5 text-sm text-muted">مسیر سریع‌تر برای رسیدن به ساعت مناسب شما</p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-7">
        {tiles.map((tile) => (
          <Link
            key={tile.href}
            href={tile.href}
            className="group flex flex-col items-center gap-3 rounded-md border border-border bg-paper p-3 text-center transition-shadow hover:shadow-card"
          >
            <span className="relative block aspect-square w-full overflow-hidden rounded-sm bg-surface">
              <Image
                src={tile.image}
                alt={tile.label}
                fill
                sizes="(max-width: 640px) 40vw, 160px"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </span>
            <span className="text-xs font-medium text-ink sm:text-sm">{tile.label}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}
