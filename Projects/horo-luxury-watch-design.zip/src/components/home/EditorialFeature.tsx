import Image from "next/image";
import Link from "next/link";
import { toPersianDigits } from "@/lib/format";

export function EditorialFeature() {
  return (
    <section className="bg-charcoal text-paper">
      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
        <div className="relative order-2 aspect-square w-full overflow-hidden rounded-md lg:order-1">
          <Image
            src="/images/editorial-feature.jpg"
            alt="نمای نزدیک از موتور اتوماتیک هورو هریتیج کرونوگراف از پشت بدنه شیشه‌ای"
            fill
            sizes="(max-width: 1024px) 100vw, 50vw"
            className="object-cover"
          />
        </div>
        <div className="order-1 lg:order-2">
          <p className="text-xs font-medium tracking-[0.2em] text-champagne-light">محصول پرچم‌دار</p>
          <h2 className="mt-4 text-2xl font-bold leading-snug sm:text-3xl">هورو هریتیج کرونوگراف</h2>
          <p className="mt-4 text-sm leading-7 text-paper/75 sm:text-base">
            بدنه از استیل جراحی ۳۱۶ال با پرداخت ترکیبی براق و ساتن ساخته شده است. موتور خودکار سوئیسی با
            ذخیره انرژی ۷۲ ساعته، نیاز به کوک روزانه را از بین می‌برد و شیشه کریستال یاقوتی دوطرف
            ضدانعکاس، خوانایی صفحه را در هر زاویه‌ای تضمین می‌کند.
          </p>
          <dl className="mt-8 grid grid-cols-2 gap-6 border-t border-paper/15 pt-6 sm:grid-cols-4">
            {[
              { label: "قطر بدنه", value: `${toPersianDigits("41")} میلی‌متر` },
              { label: "ذخیره انرژی", value: `${toPersianDigits("72")} ساعت` },
              { label: "مقاومت آب", value: `${toPersianDigits("10")} اتمسفر` },
              { label: "ضمانت", value: `${toPersianDigits("24")} ماهه` },
            ].map((item) => (
              <div key={item.label}>
                <dt className="text-xs text-paper/60">{item.label}</dt>
                <dd className="mt-1 text-base font-semibold">{item.value}</dd>
              </div>
            ))}
          </dl>
          <Link
            href="/products/horo-heritage-chronograph"
            className="mt-8 inline-flex rounded-sm bg-champagne px-6 py-3.5 text-sm font-semibold text-ink transition-colors hover:bg-champagne-light"
          >
            مشاهده جزئیات محصول
          </Link>
        </div>
      </div>
    </section>
  );
}
