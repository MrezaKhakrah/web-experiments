import Image from "next/image";
import Link from "next/link";

const collections = [
  {
    title: "ضروریات روزمره",
    description: "ساعت‌هایی ساده و قابل‌اعتماد برای استفاده روزانه",
    href: "/products?sort=popularity",
    image: "/images/category-classic.jpg",
  },
  {
    title: "دقت و عملکرد",
    description: "مدل‌های اسپرت با مقاومت بالا برای فعالیت‌های پرتحرک",
    href: "/products?category=sport",
    image: "/images/category-sport.jpg",
  },
  {
    title: "کلاسیک‌های بی‌زمان",
    description: "طراحی‌هایی که هیچ‌وقت از مد نمی‌افتند",
    href: "/products?category=classic",
    image: "/images/category-womens.jpg",
  },
  {
    title: "هوشمندهای امروزی",
    description: "جدیدترین نسل ساعت‌های هوشمند با پایش سلامت",
    href: "/products?category=smartwatches",
    image: "/images/category-smartwatch.jpg",
  },
  {
    title: "هدایای ممتاز",
    description: "انتخابی شیک برای هدیه‌دادن در مناسبت‌های خاص",
    href: "/products?category=luxury",
    image: "/images/collection-gifts.jpg",
  },
];

export function Collections() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-ink sm:text-2xl">مجموعه‌های منتخب</h2>
        <p className="mt-1.5 text-sm text-muted">روایت‌هایی برای هر سبک زندگی</p>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Link
          href={collections[0].href}
          className="group relative col-span-1 overflow-hidden rounded-md sm:col-span-2 lg:col-span-2 lg:row-span-2"
        >
          <div className="relative aspect-[4/3] w-full lg:aspect-auto lg:h-full lg:min-h-[420px]">
            <Image src={collections[0].image} alt={collections[0].title} fill sizes="(max-width: 1024px) 100vw, 40vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-transparent" />
          </div>
          <div className="absolute inset-x-0 bottom-0 p-6">
            <h3 className="text-xl font-bold text-paper">{collections[0].title}</h3>
            <p className="mt-1 text-sm text-paper/80">{collections[0].description}</p>
          </div>
        </Link>

        {collections.slice(1).map((c) => (
          <Link key={c.href} href={c.href} className="group relative overflow-hidden rounded-md">
            <div className="relative aspect-[4/3] w-full">
              <Image src={c.image} alt={c.title} fill sizes="(max-width: 1024px) 50vw, 20vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-transparent" />
            </div>
            <div className="absolute inset-x-0 bottom-0 p-4">
              <h3 className="text-sm font-bold text-paper">{c.title}</h3>
              <p className="mt-0.5 line-clamp-1 text-xs text-paper/80">{c.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
