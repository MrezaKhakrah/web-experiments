import Link from "next/link";
import type { brands as brandsTable } from "@/db/schema";

export function BrandStrip({ brands }: { brands: (typeof brandsTable.$inferSelect)[] }) {
  return (
    <section className="border-y border-border bg-surface/60">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-base font-semibold text-ink sm:text-lg">برندهای موجود در هورو</h2>
          <Link href="/brands" className="text-xs font-medium text-champagne-dark hover:underline">
            مشاهده همه برندها
          </Link>
        </div>
        <div className="flex flex-wrap items-center gap-x-8 gap-y-5">
          {brands.map((brand) => (
            <Link
              key={brand.slug}
              href={`/products?brand=${brand.slug}`}
              className="text-lg font-bold tracking-tight text-muted transition-colors hover:text-ink"
            >
              {brand.name}
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
