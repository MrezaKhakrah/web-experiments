"use client";

import { useActionState } from "react";
import { subscribeAction, type NewsletterState } from "@/app/actions/newsletter";

const initialState: NewsletterState = { status: "idle", message: "" };

export function Newsletter() {
  const [state, formAction, pending] = useActionState(subscribeAction, initialState);

  return (
    <section className="border-t border-border bg-surface/60">
      <div className="mx-auto max-w-3xl px-4 py-14 text-center sm:px-6">
        <h2 className="text-xl font-bold text-ink sm:text-2xl">عضویت در خبرنامه هورو</h2>
        <p className="mx-auto mt-2 max-w-md text-sm text-muted">
          از محصولات جدید، تخفیف‌های واقعی و راهنمای خرید باخبر شوید.
        </p>
        <form action={formAction} className="mx-auto mt-6 flex max-w-md flex-col gap-3">
          <div className="flex flex-col gap-2 sm:flex-row">
            <label htmlFor="newsletter-email" className="sr-only">
              ایمیل
            </label>
            <input
              id="newsletter-email"
              name="email"
              type="email"
              required
              placeholder="ایمیل شما"
              className="w-full flex-1 rounded-sm border border-border-strong bg-paper px-4 py-3 text-sm text-ink placeholder:text-muted focus:border-champagne-dark focus:outline-none"
              aria-describedby="newsletter-status"
            />
            <button
              type="submit"
              disabled={pending}
              className="shrink-0 rounded-sm bg-ink px-6 py-3 text-sm font-semibold text-paper transition-colors hover:bg-charcoal disabled:bg-muted"
            >
              {pending ? "در حال ارسال…" : "عضویت"}
            </button>
          </div>
          <label className="flex items-center justify-center gap-2 text-xs text-muted">
            <input type="checkbox" name="consent" required className="h-4 w-4 rounded-sm border-border-strong" />
            موافقم ایمیل‌های تبلیغاتی هورو را دریافت کنم.
          </label>
          <p
            id="newsletter-status"
            role="status"
            className={`text-xs ${state.status === "error" ? "text-error" : state.status === "success" ? "text-success" : "text-transparent"}`}
          >
            {state.message || "."}
          </p>
        </form>
      </div>
    </section>
  );
}
