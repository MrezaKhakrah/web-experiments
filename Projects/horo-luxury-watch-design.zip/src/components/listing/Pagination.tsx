import Link from "next/link";
import { ChevronRight, ChevronLeft } from "lucide-react";
import { toPersianDigits } from "@/lib/format";

export function Pagination({
  page,
  totalPages,
  buildHref,
}: {
  page: number;
  totalPages: number;
  buildHref: (page: number) => string;
}) {
  if (totalPages <= 1) return null;

  const pages = Array.from({ length: totalPages }, (_, i) => i + 1).filter(
    (p) => p === 1 || p === totalPages || Math.abs(p - page) <= 1,
  );

  return (
    <nav aria-label="صفحه‌بندی" className="mt-10 flex items-center justify-center gap-1.5">
      <Link
        href={buildHref(Math.max(1, page - 1))}
        aria-disabled={page === 1}
        className={`rounded-sm border border-border-strong p-2 ${page === 1 ? "pointer-events-none opacity-40" : "hover:bg-surface"}`}
      >
        <ChevronRight size={16} className="rtl:-scale-x-100" />
      </Link>
      {pages.map((p, idx) => (
        <span key={p} className="flex items-center gap-1.5">
          {idx > 0 && pages[idx - 1] !== p - 1 && <span className="px-1 text-muted">…</span>}
          <Link
            href={buildHref(p)}
            aria-current={p === page ? "page" : undefined}
            className={`min-w-9 rounded-sm border px-2.5 py-2 text-center text-sm ${
              p === page ? "border-ink bg-ink text-paper" : "border-border-strong text-ink hover:bg-surface"
            }`}
          >
            {toPersianDigits(p)}
          </Link>
        </span>
      ))}
      <Link
        href={buildHref(Math.min(totalPages, page + 1))}
        aria-disabled={page === totalPages}
        className={`rounded-sm border border-border-strong p-2 ${page === totalPages ? "pointer-events-none opacity-40" : "hover:bg-surface"}`}
      >
        <ChevronLeft size={16} className="rtl:-scale-x-100" />
      </Link>
    </nav>
  );
}
