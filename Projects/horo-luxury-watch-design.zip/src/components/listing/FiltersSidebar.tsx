"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { formatCurrency, toPersianDigits } from "@/lib/format";
import type { brands as brandsTable } from "@/db/schema";

export type Facets = {
  caseMaterials: string[];
  strapMaterials: string[];
  movements: string[];
  displayTypes: string[];
  connectivities: string[];
  waterResistances: number[];
  colors: string[]; // "name|hex"
  priceMin: number;
  priceMax: number;
};

const genderOptions = [
  { value: "men", label: "مردانه" },
  { value: "women", label: "زنانه" },
  { value: "unisex", label: "یونیسکس" },
];

function FilterSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="border-b border-border py-5 first:pt-0 last:border-b-0">
      <h3 className="mb-3 text-sm font-semibold text-ink">{title}</h3>
      {children}
    </div>
  );
}

export function FiltersSidebar({
  facets,
  brands,
  activeCategory,
}: {
  facets: Facets;
  brands: (typeof brandsTable.$inferSelect)[];
  activeCategory?: string;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const getList = (key: string) => (searchParams.get(key)?.split(",").filter(Boolean) ?? []);

  function toggleListValue(key: string, value: string) {
    const current = new Set(getList(key));
    if (current.has(value)) current.delete(value);
    else current.add(value);
    const params = new URLSearchParams(searchParams.toString());
    if (current.size === 0) params.delete(key);
    else params.set(key, Array.from(current).join(","));
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  }

  function applyPriceRange(formData: FormData) {
    const min = formData.get("priceMin");
    const max = formData.get("priceMax");
    const params = new URLSearchParams(searchParams.toString());
    if (min) params.set("priceMin", String(min));
    else params.delete("priceMin");
    if (max) params.set("priceMax", String(max));
    else params.delete("priceMax");
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  }

  function toggleInStock() {
    const params = new URLSearchParams(searchParams.toString());
    if (params.get("inStock") === "1") params.delete("inStock");
    else params.set("inStock", "1");
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  }

  const showSmartAttributes = !activeCategory || activeCategory === "smartwatches";
  const showMechanicalAttributes = !activeCategory || ["classic", "sport", "luxury"].includes(activeCategory);

  return (
    <div className="text-sm">
      <FilterSection title="برند">
        <div className="flex max-h-48 flex-col gap-2 overflow-y-auto pe-1">
          {brands.map((brand) => (
            <label key={brand.slug} className="flex cursor-pointer items-center gap-2">
              <input
                type="checkbox"
                checked={getList("brand").includes(brand.slug)}
                onChange={() => toggleListValue("brand", brand.slug)}
                className="h-4 w-4 rounded-sm border-border-strong accent-ink"
              />
              <span className="text-ink">{brand.nameFa}</span>
            </label>
          ))}
        </div>
      </FilterSection>

      <FilterSection title="محدوده قیمت (تومان)">
        <form
          action={(fd) => applyPriceRange(fd)}
          className="flex flex-col gap-2"
        >
          <div className="flex items-center gap-2">
            <input
              name="priceMin"
              type="number"
              defaultValue={searchParams.get("priceMin") ?? ""}
              placeholder={formatCurrency(facets.priceMin)}
              className="w-full rounded-sm border border-border-strong bg-paper px-2.5 py-2 text-xs text-ink focus:border-champagne-dark focus:outline-none"
            />
            <span className="text-muted">تا</span>
            <input
              name="priceMax"
              type="number"
              defaultValue={searchParams.get("priceMax") ?? ""}
              placeholder={formatCurrency(facets.priceMax)}
              className="w-full rounded-sm border border-border-strong bg-paper px-2.5 py-2 text-xs text-ink focus:border-champagne-dark focus:outline-none"
            />
          </div>
          <button type="submit" className="rounded-sm border border-border-strong py-2 text-xs font-medium text-ink hover:bg-surface">
            اعمال محدوده قیمت
          </button>
        </form>
      </FilterSection>

      <FilterSection title="جنسیت">
        <div className="flex flex-col gap-2">
          {genderOptions.map((g) => (
            <label key={g.value} className="flex cursor-pointer items-center gap-2">
              <input
                type="checkbox"
                checked={getList("gender").includes(g.value)}
                onChange={() => toggleListValue("gender", g.value)}
                className="h-4 w-4 rounded-sm border-border-strong accent-ink"
              />
              <span className="text-ink">{g.label}</span>
            </label>
          ))}
        </div>
      </FilterSection>

      {facets.colors.length > 0 && (
        <FilterSection title="رنگ">
          <div className="flex flex-wrap gap-2">
            {facets.colors.map((c) => {
              const [name, hex] = c.split("|");
              const active = getList("color").includes(name);
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => toggleListValue("color", name)}
                  aria-pressed={active}
                  title={name}
                  className={`flex h-8 w-8 items-center justify-center rounded-full border-2 transition-transform ${
                    active ? "border-champagne-dark scale-110" : "border-border"
                  }`}
                >
                  <span className="block h-6 w-6 rounded-full border border-black/10" style={{ backgroundColor: hex }} />
                </button>
              );
            })}
          </div>
        </FilterSection>
      )}

      <FilterSection title="جنس بدنه">
        <div className="flex flex-col gap-2">
          {facets.caseMaterials.map((m) => (
            <label key={m} className="flex cursor-pointer items-center gap-2">
              <input
                type="checkbox"
                checked={getList("caseMaterial").includes(m)}
                onChange={() => toggleListValue("caseMaterial", m)}
                className="h-4 w-4 rounded-sm border-border-strong accent-ink"
              />
              <span className="text-ink">{m}</span>
            </label>
          ))}
        </div>
      </FilterSection>

      <FilterSection title="جنس بند">
        <div className="flex flex-col gap-2">
          {facets.strapMaterials.map((m) => (
            <label key={m} className="flex cursor-pointer items-center gap-2">
              <input
                type="checkbox"
                checked={getList("strapMaterial").includes(m)}
                onChange={() => toggleListValue("strapMaterial", m)}
                className="h-4 w-4 rounded-sm border-border-strong accent-ink"
              />
              <span className="text-ink">{m}</span>
            </label>
          ))}
        </div>
      </FilterSection>

      {showMechanicalAttributes && (
        <FilterSection title="موتور حرکتی">
          <div className="flex flex-col gap-2">
            {facets.movements.map((m) => (
              <label key={m} className="flex cursor-pointer items-center gap-2">
                <input
                  type="checkbox"
                  checked={getList("movement").includes(m)}
                  onChange={() => toggleListValue("movement", m)}
                  className="h-4 w-4 rounded-sm border-border-strong accent-ink"
                />
                <span className="text-ink">{m}</span>
              </label>
            ))}
          </div>
        </FilterSection>
      )}

      {showSmartAttributes && (
        <>
          <FilterSection title="نوع صفحه‌نمایش">
            <div className="flex flex-col gap-2">
              {facets.displayTypes.map((d) => (
                <label key={d} className="flex cursor-pointer items-center gap-2">
                  <input
                    type="checkbox"
                    checked={getList("displayType").includes(d)}
                    onChange={() => toggleListValue("displayType", d)}
                    className="h-4 w-4 rounded-sm border-border-strong accent-ink"
                  />
                  <span className="text-ink">{d}</span>
                </label>
              ))}
            </div>
          </FilterSection>

          {facets.connectivities.length > 0 && (
            <FilterSection title="اتصال‌پذیری">
              <div className="flex flex-col gap-2">
                {facets.connectivities.map((c) => (
                  <label key={c} className="flex cursor-pointer items-center gap-2">
                    <input
                      type="checkbox"
                      checked={getList("connectivity").includes(c)}
                      onChange={() => toggleListValue("connectivity", c)}
                      className="h-4 w-4 rounded-sm border-border-strong accent-ink"
                    />
                    <span className="text-ink">{c}</span>
                  </label>
                ))}
              </div>
            </FilterSection>
          )}
        </>
      )}

      {facets.waterResistances.length > 0 && (
        <FilterSection title="مقاومت در برابر آب">
          <div className="flex flex-col gap-2">
            {facets.waterResistances.map((w) => (
              <label key={w} className="flex cursor-pointer items-center gap-2">
                <input
                  type="checkbox"
                  checked={getList("waterResistance").includes(String(w))}
                  onChange={() => toggleListValue("waterResistance", String(w))}
                  className="h-4 w-4 rounded-sm border-border-strong accent-ink"
                />
                <span className="text-ink">{toPersianDigits(w)} اتمسفر</span>
              </label>
            ))}
          </div>
        </FilterSection>
      )}

      <FilterSection title="موجودی">
        <label className="flex cursor-pointer items-center gap-2">
          <input
            type="checkbox"
            checked={searchParams.get("inStock") === "1"}
            onChange={toggleInStock}
            className="h-4 w-4 rounded-sm border-border-strong accent-ink"
          />
          <span className="text-ink">فقط کالاهای موجود</span>
        </label>
      </FilterSection>
    </div>
  );
}
