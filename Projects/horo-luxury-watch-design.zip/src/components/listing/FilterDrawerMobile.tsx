"use client";

import { useState } from "react";
import { SlidersHorizontal } from "lucide-react";
import { Drawer } from "@/components/ui/Drawer";
import { FiltersSidebar, type Facets } from "./FiltersSidebar";
import type { brands as brandsTable } from "@/db/schema";

export function FilterDrawerMobile({
  facets,
  brands,
  activeCategory,
}: {
  facets: Facets;
  brands: (typeof brandsTable.$inferSelect)[];
  activeCategory?: string;
}) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 rounded-sm border border-border-strong px-4 py-2.5 text-sm text-ink hover:bg-surface lg:hidden"
      >
        <SlidersHorizontal size={16} />
        فیلترها
      </button>
      <Drawer open={open} onClose={() => setOpen(false)} title="فیلترها" side="left" widthClass="max-w-xs">
        <div className="p-4">
          <FiltersSidebar facets={facets} brands={brands} activeCategory={activeCategory} />
        </div>
        <div className="sticky bottom-0 border-t border-border bg-paper p-4">
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="w-full rounded-sm bg-ink py-3 text-sm font-semibold text-paper"
          >
            نمایش نتایج
          </button>
        </div>
      </Drawer>
    </>
  );
}
