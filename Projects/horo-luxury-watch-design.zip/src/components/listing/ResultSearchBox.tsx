"use client";

import { useState } from "react";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { Search } from "lucide-react";

export function ResultSearchBox({ defaultValue }: { defaultValue?: string }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [value, setValue] = useState(defaultValue ?? "");

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams(searchParams.toString());
    if (value.trim()) params.set("q", value.trim());
    else params.delete("q");
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  }

  return (
    <form onSubmit={onSubmit} role="search" className="flex w-full max-w-sm items-center gap-2 rounded-full border border-border bg-surface px-4 py-2.5">
      <Search size={16} className="shrink-0 text-muted" />
      <label htmlFor="in-results-search" className="sr-only">
        جستجو در نتایج
      </label>
      <input
        id="in-results-search"
        type="search"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="جستجو در این نتایج…"
        className="w-full bg-transparent text-sm text-ink placeholder:text-muted focus:outline-none"
      />
    </form>
  );
}
