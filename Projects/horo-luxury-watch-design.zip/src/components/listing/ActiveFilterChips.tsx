"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { X } from "lucide-react";
import { formatCurrency } from "@/lib/format";

const labels: Record<string, string> = {
  brand: "برند",
  gender: "جنسیت",
  caseMaterial: "جنس بدنه",
  strapMaterial: "جنس بند",
  movement: "موتور",
  displayType: "صفحه‌نمایش",
  connectivity: "اتصال‌پذیری",
  waterResistance: "مقاومت آب",
  color: "رنگ",
};

const genderLabels: Record<string, string> = { men: "مردانه", women: "زنانه", unisex: "یونیسکس" };

const multiKeys = Object.keys(labels);

export function ActiveFilterChips() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  type Chip = { key: string; value: string; label: string };
  const chips: Chip[] = [];

  for (const key of multiKeys) {
    const values = searchParams.get(key)?.split(",").filter(Boolean) ?? [];
    for (const value of values) {
      const display = key === "gender" ? (genderLabels[value] ?? value) : value;
      chips.push({ key, value, label: `${labels[key]}: ${display}` });
    }
  }
  if (searchParams.get("priceMin") || searchParams.get("priceMax")) {
    const min = searchParams.get("priceMin");
    const max = searchParams.get("priceMax");
    chips.push({
      key: "price",
      value: "price",
      label: `قیمت: ${min ? formatCurrency(Number(min)) : "۰"} تا ${max ? formatCurrency(Number(max)) : "∞"}`,
    });
  }
  if (searchParams.get("inStock") === "1") {
    chips.push({ key: "inStock", value: "1", label: "فقط موجود" });
  }
  if (searchParams.get("q")) {
    chips.push({ key: "q", value: searchParams.get("q")!, label: `جستجو: ${searchParams.get("q")}` });
  }

  if (chips.length === 0) return null;

  function removeChip(chip: Chip) {
    const params = new URLSearchParams(searchParams.toString());
    if (chip.key === "price") {
      params.delete("priceMin");
      params.delete("priceMax");
    } else if (multiKeys.includes(chip.key)) {
      const values = (params.get(chip.key)?.split(",").filter(Boolean) ?? []).filter((v) => v !== chip.value);
      if (values.length === 0) params.delete(chip.key);
      else params.set(chip.key, values.join(","));
    } else {
      params.delete(chip.key);
    }
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  }

  function clearAll() {
    const params = new URLSearchParams(searchParams.toString());
    const category = params.get("category");
    params.forEach((_, key) => params.delete(key));
    if (category) params.set("category", category);
    router.push(`${pathname}?${params.toString()}`);
  }

  return (
    <div className="mb-5 flex flex-wrap items-center gap-2">
      {chips.map((chip) => (
        <button
          key={`${chip.key}-${chip.value}`}
          type="button"
          onClick={() => removeChip(chip)}
          className="flex items-center gap-1.5 rounded-full border border-border-strong bg-paper px-3 py-1.5 text-xs text-ink hover:bg-surface"
        >
          {chip.label}
          <X size={12} />
        </button>
      ))}
      <button type="button" onClick={clearAll} className="text-xs font-medium text-champagne-dark hover:underline">
        پاک‌کردن همه فیلترها
      </button>
    </div>
  );
}
