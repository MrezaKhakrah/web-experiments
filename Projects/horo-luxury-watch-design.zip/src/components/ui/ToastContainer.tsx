"use client";

import { CheckCircle2, AlertCircle, Info, X } from "lucide-react";
import { useToastStore } from "@/lib/toast-store";

const toneStyles = {
  success: { icon: CheckCircle2, className: "border-success/30 bg-success/10 text-success" },
  error: { icon: AlertCircle, className: "border-error/30 bg-error/10 text-error" },
  info: { icon: Info, className: "border-border-strong bg-paper text-ink" },
};

export function ToastContainer() {
  const toasts = useToastStore((s) => s.toasts);
  const dismiss = useToastStore((s) => s.dismiss);

  if (toasts.length === 0) return null;

  return (
    <div className="fixed inset-x-0 bottom-4 z-[100] flex flex-col items-center gap-2 px-4 sm:bottom-6 sm:items-end sm:px-6" role="region" aria-label="اعلان‌ها">
      {toasts.map((toast) => {
        const { icon: Icon, className } = toneStyles[toast.tone];
        return (
          <div
            key={toast.id}
            role="status"
            className={`flex w-full max-w-sm items-center gap-2.5 rounded-sm border px-4 py-3 shadow-elevated animate-in ${className}`}
            style={{ animation: "toast-in 0.25s ease-out" }}
          >
            <Icon size={18} className="shrink-0" />
            <p className="flex-1 text-sm">{toast.message}</p>
            <button
              type="button"
              onClick={() => dismiss(toast.id)}
              aria-label="بستن اعلان"
              className="shrink-0 rounded-full p-1 text-current/70 hover:bg-black/5"
            >
              <X size={14} />
            </button>
          </div>
        );
      })}
      <style>{`
        @keyframes toast-in {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
