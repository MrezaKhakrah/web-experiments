import { calcDiscountPercent, formatCurrency, toPersianDigits } from "@/lib/format";

export function Price({
  price,
  compareAtPrice,
  size = "md",
}: {
  price: number;
  compareAtPrice?: number | null;
  size?: "sm" | "md" | "lg";
}) {
  const discount = calcDiscountPercent(price, compareAtPrice ?? undefined);
  const priceClass = size === "lg" ? "text-2xl" : size === "sm" ? "text-sm" : "text-base";

  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className={`font-semibold text-ink ${priceClass}`}>{formatCurrency(price)}</span>
      {discount !== null && (
        <>
          <span className="text-xs text-muted line-through">{formatCurrency(compareAtPrice!)}</span>
          <span className="rounded-sm bg-error/10 px-1.5 py-0.5 text-[11px] font-semibold text-error">
            {toPersianDigits(discount)}%-
          </span>
        </>
      )}
    </div>
  );
}
