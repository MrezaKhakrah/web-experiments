import Link from "next/link";
import { ChevronLeft } from "lucide-react";

export function Breadcrumbs({ items }: { items: { label: string; href?: string }[] }) {
  return (
    <nav aria-label="مسیر صفحه" className="flex flex-wrap items-center gap-1.5 text-xs text-muted">
      {items.map((item, idx) => (
        <span key={idx} className="flex items-center gap-1.5">
          {item.href ? (
            <Link href={item.href} className="transition-colors hover:text-ink">
              {item.label}
            </Link>
          ) : (
            <span className="text-ink" aria-current="page">
              {item.label}
            </span>
          )}
          {idx < items.length - 1 && <ChevronLeft size={13} className="rtl:-scale-x-100 text-border-strong" />}
        </span>
      ))}
    </nav>
  );
}
