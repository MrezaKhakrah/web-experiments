import { Star } from "lucide-react";
import { formatNumber, toPersianDigits } from "@/lib/format";

export function Rating({
  value,
  count,
  size = 14,
  hideCount = false,
}: {
  value: number;
  count: number;
  size?: number;
  hideCount?: boolean;
}) {
  if (!count && !hideCount) {
    return <span className="text-xs text-muted">هنوز نظری ثبت نشده</span>;
  }
  const rounded = Math.round(value * 2) / 2;
  return (
    <div className="flex items-center gap-1.5" aria-label={`امتیاز ${toPersianDigits(value)} از ۵`}>
      <div className="flex items-center" aria-hidden="true">
        {Array.from({ length: 5 }).map((_, i) => {
          const fill = i + 1 <= rounded ? 1 : i + 0.5 === rounded ? 0.5 : 0;
          return (
            <span key={i} className="relative inline-block" style={{ width: size, height: size }}>
              <Star size={size} className="absolute inset-0 text-border-strong" />
              {fill > 0 && (
                <span className="absolute inset-0 overflow-hidden" style={{ width: `${fill * 100}%` }}>
                  <Star size={size} className="text-champagne-dark" fill="currentColor" />
                </span>
              )}
            </span>
          );
        })}
      </div>
      {!hideCount && (
        <span className="text-xs text-muted">
          {toPersianDigits(value.toFixed(1))} ({formatNumber(count)})
        </span>
      )}
    </div>
  );
}
