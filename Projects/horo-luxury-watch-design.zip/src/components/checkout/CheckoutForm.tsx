"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { Loader2, ShieldCheck, Truck, Wallet } from "lucide-react";
import { useCartStore, cartSubtotal } from "@/lib/cart-store";
import { calcShippingCost } from "@/lib/commerce";
import { formatCurrency } from "@/lib/format";
import type { addresses as addressesTable } from "@/db/schema";

type Address = typeof addressesTable.$inferSelect;

export function CheckoutForm({
  isLoggedIn,
  savedAddresses,
  userEmail,
}: {
  isLoggedIn: boolean;
  savedAddresses: Address[];
  userEmail?: string;
}) {
  const router = useRouter();
  const items = useCartStore((s) => s.items);
  const discountCode = useCartStore((s) => s.discountCode);
  const discountAmount = useCartStore((s) => s.discountAmount);
  const clearCart = useCartStore((s) => s.clear);

  const subtotal = cartSubtotal(items);
  const shipping = calcShippingCost(subtotal);
  const total = Math.max(0, subtotal + shipping - discountAmount);

  const defaultAddress = savedAddresses.find((a) => a.isDefault) ?? savedAddresses[0];
  const [selectedAddressId, setSelectedAddressId] = useState<number | "new">(defaultAddress ? defaultAddress.id : "new");
  const [paymentMethod, setPaymentMethod] = useState<"cod" | "card">("cod");
  const [deliveryMethod, setDeliveryMethod] = useState<"standard" | "express">("standard");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    province: "",
    city: "",
    addressLine: "",
    postalCode: "",
    guestEmail: userEmail ?? "",
  });

  const deliverySurcharge = deliveryMethod === "express" ? 650000 : 0;
  const finalTotal = total + deliverySurcharge;

  const selectedSavedAddress = useMemo(
    () => (selectedAddressId !== "new" ? savedAddresses.find((a) => a.id === selectedAddressId) : undefined),
    [selectedAddressId, savedAddresses],
  );

  function updateField<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const address = selectedSavedAddress
      ? {
          fullName: selectedSavedAddress.fullName,
          phone: selectedSavedAddress.phone,
          province: selectedSavedAddress.province,
          city: selectedSavedAddress.city,
          addressLine: selectedSavedAddress.addressLine,
          postalCode: selectedSavedAddress.postalCode,
        }
      : form;

    if (!address.fullName || !address.phone || !address.province || !address.city || !address.addressLine || !address.postalCode) {
      setError("لطفاً تمام فیلدهای آدرس را تکمیل کنید.");
      return;
    }
    if (!isLoggedIn && !form.guestEmail) {
      setError("برای پیگیری سفارش، ایمیل خود را وارد کنید.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.map((i) => ({ productId: i.productId, variantSku: i.variantSku, quantity: i.quantity })),
          address,
          paymentMethod,
          discountCode,
          guestEmail: form.guestEmail,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "ثبت سفارش ناموفق بود.");
        setSubmitting(false);
        return;
      }
      clearCart();
      router.push(`/checkout/confirmation/${data.orderNumber}`);
    } catch {
      setError("خطا در ارتباط با سرور. دوباره تلاش کنید.");
      setSubmitting(false);
    }
  }

  if (items.length === 0) {
    return (
      <div className="rounded-md border border-dashed border-border-strong bg-surface/40 p-10 text-center">
        <p className="text-sm text-muted">سبد خرید شما خالی است.</p>
        <Link href="/products" className="mt-4 inline-block rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-paper hover:bg-charcoal">
          مشاهده محصولات
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_360px]">
      <div className="flex flex-col gap-8">
        {!isLoggedIn && (
          <section className="rounded-md border border-border p-5">
            <h2 className="mb-4 text-sm font-semibold text-ink">اطلاعات تماس</h2>
            <label htmlFor="guestEmail" className="mb-1.5 block text-xs font-medium text-ink">
              ایمیل برای پیگیری سفارش
            </label>
            <input
              id="guestEmail"
              type="email"
              required
              value={form.guestEmail}
              onChange={(e) => updateField("guestEmail", e.target.value)}
              className="w-full rounded-sm border border-border-strong bg-paper px-3.5 py-2.5 text-sm focus:border-champagne-dark focus:outline-none"
            />
            <p className="mt-3 text-xs text-muted">
              حساب کاربری دارید؟{" "}
              <Link href="/account/login" className="font-medium text-champagne-dark hover:underline">
                وارد شوید
              </Link>{" "}
              تا آدرس‌های ذخیره‌شده را ببینید.
            </p>
          </section>
        )}

        <section className="rounded-md border border-border p-5">
          <h2 className="mb-4 text-sm font-semibold text-ink">آدرس تحویل سفارش</h2>

          {savedAddresses.length > 0 && (
            <div className="mb-4 flex flex-col gap-2">
              {savedAddresses.map((addr) => (
                <label key={addr.id} className="flex cursor-pointer items-start gap-2.5 rounded-sm border border-border p-3 text-sm has-[:checked]:border-champagne-dark has-[:checked]:bg-surface/60">
                  <input
                    type="radio"
                    name="address"
                    checked={selectedAddressId === addr.id}
                    onChange={() => setSelectedAddressId(addr.id)}
                    className="mt-1 h-4 w-4 accent-ink"
                  />
                  <span>
                    <span className="block font-medium text-ink">{addr.fullName}</span>
                    <span className="block text-xs text-muted">
                      {addr.province}، {addr.city}، {addr.addressLine}
                    </span>
                  </span>
                </label>
              ))}
              <label className="flex cursor-pointer items-center gap-2.5 rounded-sm border border-border p-3 text-sm has-[:checked]:border-champagne-dark has-[:checked]:bg-surface/60">
                <input
                  type="radio"
                  name="address"
                  checked={selectedAddressId === "new"}
                  onChange={() => setSelectedAddressId("new")}
                  className="h-4 w-4 accent-ink"
                />
                آدرس جدید وارد می‌کنم
              </label>
            </div>
          )}

          {selectedAddressId === "new" && (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label htmlFor="fullName" className="mb-1 block text-xs font-medium text-ink">
                  نام گیرنده
                </label>
                <input id="fullName" required value={form.fullName} onChange={(e) => updateField("fullName", e.target.value)} className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
              </div>
              <div>
                <label htmlFor="phone" className="mb-1 block text-xs font-medium text-ink">
                  شماره موبایل
                </label>
                <input id="phone" required value={form.phone} onChange={(e) => updateField("phone", e.target.value)} className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
              </div>
              <div>
                <label htmlFor="postalCode" className="mb-1 block text-xs font-medium text-ink">
                  کد پستی
                </label>
                <input id="postalCode" required minLength={10} value={form.postalCode} onChange={(e) => updateField("postalCode", e.target.value)} className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
              </div>
              <div>
                <label htmlFor="province" className="mb-1 block text-xs font-medium text-ink">
                  استان
                </label>
                <input id="province" required value={form.province} onChange={(e) => updateField("province", e.target.value)} className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
              </div>
              <div>
                <label htmlFor="city" className="mb-1 block text-xs font-medium text-ink">
                  شهر
                </label>
                <input id="city" required value={form.city} onChange={(e) => updateField("city", e.target.value)} className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="addressLine" className="mb-1 block text-xs font-medium text-ink">
                  آدرس کامل
                </label>
                <textarea id="addressLine" required rows={2} value={form.addressLine} onChange={(e) => updateField("addressLine", e.target.value)} className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
              </div>
            </div>
          )}
        </section>

        <section className="rounded-md border border-border p-5">
          <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-ink">
            <Truck size={16} /> روش ارسال
          </h2>
          <div className="flex flex-col gap-2">
            <label className="flex cursor-pointer items-center justify-between rounded-sm border border-border p-3 text-sm has-[:checked]:border-champagne-dark has-[:checked]:bg-surface/60">
              <span className="flex items-center gap-2.5">
                <input type="radio" name="delivery" checked={deliveryMethod === "standard"} onChange={() => setDeliveryMethod("standard")} className="h-4 w-4 accent-ink" />
                ارسال استاندارد (۲ تا ۴ روز کاری)
              </span>
              <span className="text-xs text-muted">{shipping === 0 ? "رایگان" : formatCurrency(shipping)}</span>
            </label>
            <label className="flex cursor-pointer items-center justify-between rounded-sm border border-border p-3 text-sm has-[:checked]:border-champagne-dark has-[:checked]:bg-surface/60">
              <span className="flex items-center gap-2.5">
                <input type="radio" name="delivery" checked={deliveryMethod === "express"} onChange={() => setDeliveryMethod("express")} className="h-4 w-4 accent-ink" />
                ارسال اکسپرس (۱ روز کاری)
              </span>
              <span className="text-xs text-muted">{formatCurrency(650000)}</span>
            </label>
          </div>
        </section>

        <section className="rounded-md border border-border p-5">
          <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-ink">
            <Wallet size={16} /> روش پرداخت
          </h2>
          <div className="flex flex-col gap-2">
            <label className="flex cursor-pointer items-center gap-2.5 rounded-sm border border-border p-3 text-sm has-[:checked]:border-champagne-dark has-[:checked]:bg-surface/60">
              <input type="radio" name="payment" checked={paymentMethod === "cod"} onChange={() => setPaymentMethod("cod")} className="h-4 w-4 accent-ink" />
              پرداخت در محل (نقدی یا کارت‌خوان)
            </label>
            <label className="flex cursor-not-allowed items-center gap-2.5 rounded-sm border border-border bg-surface/40 p-3 text-sm text-muted">
              <input type="radio" name="payment" disabled className="h-4 w-4" />
              پرداخت آنلاین (در این نسخه نمایشی غیرفعال است)
            </label>
          </div>
        </section>
      </div>

      <aside className="h-fit rounded-md border border-border bg-surface/40 p-5">
        <h2 className="mb-4 text-sm font-semibold text-ink">خلاصه سفارش</h2>
        <ul className="flex flex-col gap-3">
          {items.map((item) => (
            <li key={`${item.productId}-${item.variantSku}`} className="flex items-center gap-3">
              <span className="relative h-12 w-12 shrink-0 overflow-hidden rounded-sm bg-surface">
                <Image src={item.image} alt={item.nameFa} fill sizes="48px" className="object-cover" />
              </span>
              <span className="min-w-0 flex-1 text-xs">
                <span className="block truncate text-ink">{item.nameFa}</span>
                <span className="block text-muted">تعداد: {item.quantity}</span>
              </span>
              <span className="shrink-0 text-xs font-medium text-ink">{formatCurrency(item.unitPrice * item.quantity)}</span>
            </li>
          ))}
        </ul>
        <dl className="mt-4 flex flex-col gap-2 border-t border-border pt-4 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted">جمع جزء</dt>
            <dd className="text-ink">{formatCurrency(subtotal)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">هزینه ارسال</dt>
            <dd className="text-ink">{shipping + deliverySurcharge === 0 ? "رایگان" : formatCurrency(shipping + deliverySurcharge)}</dd>
          </div>
          {discountAmount > 0 && (
            <div className="flex justify-between">
              <dt className="text-muted">تخفیف</dt>
              <dd className="text-error">- {formatCurrency(discountAmount)}</dd>
            </div>
          )}
          <div className="flex justify-between border-t border-border pt-3 text-base font-bold">
            <dt className="text-ink">مبلغ نهایی</dt>
            <dd className="text-ink">{formatCurrency(finalTotal)}</dd>
          </div>
        </dl>

        {error && <p role="alert" className="mt-3 rounded-sm bg-error/10 px-3 py-2 text-xs text-error">{error}</p>}

        <button
          type="submit"
          disabled={submitting}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-sm bg-ink py-3.5 text-sm font-semibold text-paper hover:bg-charcoal disabled:bg-muted"
        >
          {submitting && <Loader2 size={16} className="animate-spin" />}
          {submitting ? "در حال ثبت سفارش…" : "ثبت نهایی سفارش"}
        </button>
        <p className="mt-3 flex items-center gap-1.5 text-[11px] text-muted">
          <ShieldCheck size={13} /> اطلاعات پرداخت شما ذخیره نمی‌شود و فقط برای تکمیل سفارش استفاده می‌شود.
        </p>
      </aside>
    </form>
  );
}
