import { BadgeCheck } from "lucide-react";
import { Rating } from "@/components/ui/Rating";
import { formatDate } from "@/lib/format";
import type { reviews as reviewsTable } from "@/db/schema";

export function ReviewsList({
  reviews,
  ratingAvg,
  ratingCount,
}: {
  reviews: (typeof reviewsTable.$inferSelect)[];
  ratingAvg: number;
  ratingCount: number;
}) {
  if (reviews.length === 0) {
    return (
      <div className="rounded-md border border-dashed border-border-strong bg-surface/40 p-8 text-center text-sm text-muted">
        هنوز نظری برای این محصول ثبت نشده است.
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6 flex items-center gap-4 rounded-md border border-border bg-surface/40 p-5">
        <span className="text-3xl font-bold text-ink">{ratingAvg.toFixed(1)}</span>
        <div>
          <Rating value={ratingAvg} count={ratingCount} />
          <p className="mt-1 text-xs text-muted">بر اساس خریدهای ثبت‌شده مشتریان هورو</p>
        </div>
      </div>
      <ul className="flex flex-col divide-y divide-border">
        {reviews.map((review) => (
          <li key={review.id} className="py-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-ink">{review.authorName}</span>
                {review.verifiedPurchase && (
                  <span className="flex items-center gap-1 rounded-sm bg-success/10 px-1.5 py-0.5 text-[11px] font-medium text-success">
                    <BadgeCheck size={12} /> خرید تایید‌شده
                  </span>
                )}
              </div>
              <span className="text-xs text-muted">{formatDate(review.createdAt)}</span>
            </div>
            <div className="mt-1.5">
              <Rating value={review.rating} count={1} size={13} hideCount />
            </div>
            <h4 className="mt-2 text-sm font-semibold text-ink">{review.title}</h4>
            <p className="mt-1 text-sm leading-7 text-muted">{review.body}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
