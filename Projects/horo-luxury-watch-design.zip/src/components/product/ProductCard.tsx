"use client";

import Image from "next/image";
import Link from "next/link";
import { Heart, Scale, Eye } from "lucide-react";
import { Price } from "@/components/ui/Price";
import { Rating } from "@/components/ui/Rating";
import { useWishlistStore } from "@/lib/wishlist-store";
import { useCompareStore } from "@/lib/compare-store";
import { useCartStore } from "@/lib/cart-store";
import { useToastStore } from "@/lib/toast-store";
import type { ProductListItem } from "@/db/queries";

export function ProductCard({ product, onQuickView }: { product: ProductListItem; onQuickView?: (p: ProductListItem) => void }) {
  const wishlisted = useWishlistStore((s) => s.has(product.id));
  const toggleWishlist = useWishlistStore((s) => s.toggle);
  const compared = useCompareStore((s) => s.has(product.id));
  const toggleCompare = useCompareStore((s) => s.toggle);
  const addToCart = useCartStore((s) => s.addItem);
  const pushToast = useToastStore((s) => s.push);

  const outOfStock = product.stock <= 0;

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-md border border-border bg-paper transition-shadow duration-300 hover:shadow-card">
      <div className="relative aspect-square w-full overflow-hidden bg-surface">
        <Link href={`/products/${product.slug}`} className="block h-full w-full" tabIndex={-1}>
          <Image
            src={product.images[0]}
            alt={product.nameFa}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className="object-cover transition-transform duration-500 ease-[var(--ease-standard)] group-hover:scale-[1.04]"
          />
        </Link>

        {product.images[1] && (
          <Image
            src={product.images[1]}
            alt=""
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className="object-cover opacity-0 transition-opacity duration-500 group-hover:opacity-100"
          />
        )}

        <div className="absolute top-2 start-2 flex flex-col gap-1.5">
          {product.compareAtPrice && product.compareAtPrice > product.price && (
            <span className="rounded-sm bg-error px-2 py-1 text-[11px] font-semibold text-white">تخفیف ویژه</span>
          )}
          {product.isNewArrival && (
            <span className="rounded-sm bg-ink px-2 py-1 text-[11px] font-semibold text-paper">جدید</span>
          )}
          {outOfStock && (
            <span className="rounded-sm bg-surface-strong px-2 py-1 text-[11px] font-semibold text-muted">ناموجود</span>
          )}
        </div>

        <div className="absolute top-2 end-2 flex flex-col gap-1.5 opacity-0 transition-opacity duration-200 group-hover:opacity-100 group-focus-within:opacity-100">
          <button
            type="button"
            onClick={() => {
              toggleWishlist(product.id);
              pushToast(wishlisted ? "از علاقه‌مندی‌ها حذف شد" : "به علاقه‌مندی‌ها اضافه شد", "success");
            }}
            aria-pressed={wishlisted}
            aria-label="افزودن به علاقه‌مندی‌ها"
            className={`rounded-full border p-2 shadow-sm backdrop-blur transition-colors ${
              wishlisted ? "border-champagne-dark bg-champagne text-ink" : "border-border bg-paper/90 text-ink hover:bg-paper"
            }`}
          >
            <Heart size={15} fill={wishlisted ? "currentColor" : "none"} />
          </button>
          <button
            type="button"
            onClick={() => {
              const result = toggleCompare(product.id);
              if (result.reason) pushToast(result.reason, "error");
            }}
            aria-pressed={compared}
            aria-label="افزودن به مقایسه"
            className={`rounded-full border p-2 shadow-sm backdrop-blur transition-colors ${
              compared ? "border-champagne-dark bg-champagne text-ink" : "border-border bg-paper/90 text-ink hover:bg-paper"
            }`}
          >
            <Scale size={15} />
          </button>
          {onQuickView && (
            <button
              type="button"
              onClick={() => onQuickView(product)}
              aria-label="نمای سریع"
              className="rounded-full border border-border bg-paper/90 p-2 text-ink shadow-sm backdrop-blur transition-colors hover:bg-paper"
            >
              <Eye size={15} />
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-1.5 p-3.5">
        <span className="text-xs text-muted">{product.brandNameFa}</span>
        <Link href={`/products/${product.slug}`} className="line-clamp-2 min-h-[2.5rem] text-sm font-medium text-ink hover:text-champagne-dark">
          {product.nameFa}
        </Link>
        <Rating value={Number(product.ratingAvg)} count={product.ratingCount} />
        <div className="mt-1 flex items-end justify-between gap-2">
          <Price price={product.price} compareAtPrice={product.compareAtPrice} />
        </div>
        <button
          type="button"
          disabled={outOfStock}
          onClick={() => {
            addToCart(
              {
                productId: product.id,
                slug: product.slug,
                nameFa: product.nameFa,
                brandNameFa: product.brandNameFa,
                image: product.images[0],
                unitPrice: product.price,
                compareAtPrice: product.compareAtPrice,
                stock: product.stock,
              },
              1,
            );
            pushToast("به سبد خرید اضافه شد", "success");
          }}
          className="mt-2 w-full rounded-sm bg-ink py-2.5 text-xs font-semibold text-paper transition-colors hover:bg-charcoal disabled:cursor-not-allowed disabled:bg-surface-strong disabled:text-muted"
        >
          {outOfStock ? "ناموجود" : "افزودن به سبد خرید"}
        </button>
      </div>
    </div>
  );
}
