import { toPersianDigits } from "@/lib/format";

export function SpecsTable({ rows }: { rows: { label: string; value: string | number | null | undefined }[] }) {
  const visibleRows = rows.filter((r) => r.value !== null && r.value !== undefined && r.value !== "" && r.value !== "—");
  if (visibleRows.length === 0) return null;

  return (
    <dl className="divide-y divide-border overflow-hidden rounded-md border border-border">
      {visibleRows.map((row) => (
        <div key={row.label} className="grid grid-cols-2 gap-4 bg-paper px-4 py-3 odd:bg-surface/50">
          <dt className="text-sm text-muted">{row.label}</dt>
          <dd className="text-sm font-medium text-ink">
            {typeof row.value === "number" ? toPersianDigits(row.value) : row.value}
          </dd>
        </div>
      ))}
    </dl>
  );
}
