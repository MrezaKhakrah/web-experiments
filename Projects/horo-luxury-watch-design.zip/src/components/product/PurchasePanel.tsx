"use client";

import { useMemo, useRef, useState } from "react";
import Image from "next/image";
import { Heart, Minus, Plus, Scale, ShieldCheck, Truck } from "lucide-react";
import { Price } from "@/components/ui/Price";
import { useCartStore } from "@/lib/cart-store";
import { useWishlistStore } from "@/lib/wishlist-store";
import { useCompareStore } from "@/lib/compare-store";
import { useToastStore } from "@/lib/toast-store";
import { toPersianDigits, formatCurrency } from "@/lib/format";

export type VariantOption = {
  id: number;
  colorName: string;
  colorHex: string;
  strapMaterial: string;
  sku: string;
  priceDelta: number;
  stock: number;
  image: string | null;
};

export function PurchasePanel({
  productId,
  slug,
  nameFa,
  brandNameFa,
  basePrice,
  compareAtPrice,
  baseStock,
  baseImage,
  warrantyMonths,
  variants,
}: {
  productId: number;
  slug: string;
  nameFa: string;
  brandNameFa: string;
  basePrice: number;
  compareAtPrice?: number | null;
  baseStock: number;
  baseImage: string;
  warrantyMonths: number;
  variants: VariantOption[];
}) {
  const [selectedVariantId, setSelectedVariantId] = useState<number | null>(variants[0]?.id ?? null);
  const [quantity, setQuantity] = useState(1);
  const buttonRef = useRef<HTMLDivElement>(null);

  const addToCart = useCartStore((s) => s.addItem);
  const wishlisted = useWishlistStore((s) => s.has(productId));
  const toggleWishlist = useWishlistStore((s) => s.toggle);
  const compared = useCompareStore((s) => s.has(productId));
  const toggleCompare = useCompareStore((s) => s.toggle);
  const pushToast = useToastStore((s) => s.push);

  const selectedVariant = variants.find((v) => v.id === selectedVariantId) ?? null;
  const unitPrice = basePrice + (selectedVariant?.priceDelta ?? 0);
  const stock = selectedVariant ? selectedVariant.stock : baseStock;
  const outOfStock = stock <= 0;
  const image = selectedVariant?.image ?? baseImage;

  const variantLabel = useMemo(() => {
    if (!selectedVariant) return undefined;
    return `${selectedVariant.colorName} — بند ${selectedVariant.strapMaterial}`;
  }, [selectedVariant]);

  function handleAddToCart() {
    addToCart(
      {
        productId,
        slug,
        nameFa,
        brandNameFa,
        image,
        unitPrice,
        compareAtPrice,
        variantLabel,
        variantSku: selectedVariant?.sku ?? null,
        stock,
      },
      quantity,
    );
    pushToast("به سبد خرید اضافه شد", "success");
  }

  return (
    <div>
      {variants.length > 0 && (
        <div className="mb-5">
          <p className="mb-2 text-sm font-medium text-ink">
            رنگ: <span className="font-normal text-muted">{selectedVariant?.colorName}</span>
          </p>
          <div className="flex flex-wrap gap-2.5">
            {variants.map((v) => (
              <button
                key={v.id}
                type="button"
                onClick={() => {
                  setSelectedVariantId(v.id);
                  setQuantity(1);
                }}
                aria-pressed={selectedVariantId === v.id}
                title={`${v.colorName} — بند ${v.strapMaterial}`}
                className={`flex h-10 w-10 items-center justify-center rounded-full border-2 transition-transform ${
                  selectedVariantId === v.id ? "border-champagne-dark scale-110" : "border-border hover:border-border-strong"
                }`}
              >
                <span className="block h-7 w-7 rounded-full border border-black/10" style={{ backgroundColor: v.colorHex }} />
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="mb-5 flex items-center gap-3">
        <span className="text-sm font-medium text-ink">تعداد:</span>
        <div className="flex items-center rounded-sm border border-border-strong">
          <button
            type="button"
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            disabled={quantity <= 1}
            aria-label="کاهش تعداد"
            className="p-2.5 text-ink disabled:text-muted"
          >
            <Minus size={15} />
          </button>
          <span className="w-10 text-center text-sm font-medium text-ink" aria-live="polite">
            {toPersianDigits(quantity)}
          </span>
          <button
            type="button"
            onClick={() => setQuantity((q) => Math.min(stock || 1, q + 1))}
            disabled={quantity >= stock}
            aria-label="افزایش تعداد"
            className="p-2.5 text-ink disabled:text-muted"
          >
            <Plus size={15} />
          </button>
        </div>
        <span className="text-xs text-muted">
          {outOfStock ? "ناموجود" : stock <= 5 ? `تنها ${toPersianDigits(stock)} عدد باقی مانده` : "موجود در انبار"}
        </span>
      </div>

      <div ref={buttonRef} className="flex flex-col gap-3 sm:flex-row">
        <button
          type="button"
          disabled={outOfStock}
          onClick={handleAddToCart}
          className="flex-1 rounded-sm bg-ink py-3.5 text-sm font-semibold text-paper transition-colors hover:bg-charcoal disabled:cursor-not-allowed disabled:bg-surface-strong disabled:text-muted"
        >
          {outOfStock ? "ناموجود" : `افزودن به سبد — ${formatCurrency(unitPrice * quantity)}`}
        </button>
        <button
          type="button"
          onClick={() => {
            toggleWishlist(productId);
            pushToast(wishlisted ? "از علاقه‌مندی‌ها حذف شد" : "به علاقه‌مندی‌ها اضافه شد", "success");
          }}
          aria-pressed={wishlisted}
          className={`flex items-center justify-center gap-2 rounded-sm border px-4 py-3.5 text-sm font-medium transition-colors ${
            wishlisted ? "border-champagne-dark bg-champagne text-ink" : "border-border-strong text-ink hover:bg-surface"
          }`}
        >
          <Heart size={16} fill={wishlisted ? "currentColor" : "none"} />
          <span className="hidden sm:inline">علاقه‌مندی</span>
        </button>
        <button
          type="button"
          onClick={() => {
            const result = toggleCompare(productId);
            if (result.reason) pushToast(result.reason, "error");
          }}
          aria-pressed={compared}
          className={`flex items-center justify-center gap-2 rounded-sm border px-4 py-3.5 text-sm font-medium transition-colors ${
            compared ? "border-champagne-dark bg-champagne text-ink" : "border-border-strong text-ink hover:bg-surface"
          }`}
        >
          <Scale size={16} />
          <span className="hidden sm:inline">مقایسه</span>
        </button>
      </div>

      <div className="mt-6 flex flex-col gap-3 border-t border-border pt-5 text-xs text-muted">
        <div className="flex items-center gap-2">
          <Truck size={16} className="text-champagne-dark" />
          زمان و هزینه ارسال در مرحله تسویه‌حساب بر اساس مقصد محاسبه می‌شود.
        </div>
        <div className="flex items-center gap-2">
          <ShieldCheck size={16} className="text-champagne-dark" />
          {toPersianDigits(warrantyMonths)} ماه ضمانت رسمی هورو در برابر عیوب ساخت.
        </div>
      </div>

      {/* Mobile sticky purchase bar */}
      <div className="fixed inset-x-0 bottom-0 z-30 flex items-center gap-3 border-t border-border bg-paper/95 px-4 py-3 shadow-elevated backdrop-blur sm:hidden">
        <Image src={image} alt="" width={40} height={40} className="rounded-sm object-cover" />
        <div className="min-w-0 flex-1">
          <Price price={unitPrice} compareAtPrice={compareAtPrice} size="sm" />
        </div>
        <button
          type="button"
          disabled={outOfStock}
          onClick={handleAddToCart}
          className="shrink-0 rounded-sm bg-ink px-4 py-2.5 text-xs font-semibold text-paper disabled:bg-surface-strong disabled:text-muted"
        >
          {outOfStock ? "ناموجود" : "افزودن به سبد"}
        </button>
      </div>
    </div>
  );
}
