"use client";

import { useRef } from "react";
import { ChevronRight, ChevronLeft } from "lucide-react";
import { ProductCard } from "./ProductCard";
import type { ProductListItem } from "@/db/queries";

export function ProductCarousel({ products }: { products: ProductListItem[] }) {
  const scrollerRef = useRef<HTMLDivElement>(null);

  function scrollByAmount(dir: 1 | -1) {
    const el = scrollerRef.current;
    if (!el) return;
    const amount = Math.min(el.clientWidth * 0.8, 640);
    el.scrollBy({ left: dir * amount, behavior: "smooth" });
  }

  if (products.length === 0) return null;

  return (
    <div className="relative">
      <div
        ref={scrollerRef}
        className="no-scrollbar flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-smooth pb-2"
      >
        {products.map((p) => (
          <div key={p.id} className="w-[46%] shrink-0 snap-start sm:w-[31%] lg:w-[23%]">
            <ProductCard product={p} />
          </div>
        ))}
      </div>
      <div className="mt-3 hidden items-center justify-end gap-2 sm:flex">
        <button
          type="button"
          onClick={() => scrollByAmount(1)}
          aria-label="موارد قبلی"
          className="rounded-full border border-border-strong p-2.5 text-ink transition-colors hover:bg-surface"
        >
          <ChevronRight size={18} className="rtl:-scale-x-100" />
        </button>
        <button
          type="button"
          onClick={() => scrollByAmount(-1)}
          aria-label="موارد بعدی"
          className="rounded-full border border-border-strong p-2.5 text-ink transition-colors hover:bg-surface"
        >
          <ChevronLeft size={18} className="rtl:-scale-x-100" />
        </button>
      </div>
    </div>
  );
}
