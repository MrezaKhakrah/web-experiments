"use client";

import { useEffect, useState } from "react";
import { getRecentlyViewed, pushRecentlyViewed } from "@/lib/recently-viewed";
import { ProductCarousel } from "./ProductCarousel";
import type { ProductListItem } from "@/db/queries";

export function TrackRecentlyViewed({ productId }: { productId: number }) {
  useEffect(() => {
    pushRecentlyViewed(productId);
  }, [productId]);
  return null;
}

export function RecentlyViewedSection({ excludeId }: { excludeId: number }) {
  const [products, setProducts] = useState<ProductListItem[] | null>(null);

  useEffect(() => {
    const ids = getRecentlyViewed(excludeId);
    if (ids.length === 0) {
      setProducts([]);
      return;
    }
    fetch(`/api/products?ids=${ids.join(",")}`)
      .then((res) => res.json())
      .then((data) => setProducts(data.items ?? []))
      .catch(() => setProducts([]));
  }, [excludeId]);

  if (!products || products.length === 0) return null;

  return (
    <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
      <h2 className="mb-6 text-xl font-bold text-ink sm:text-2xl">بازدیدهای اخیر شما</h2>
      <ProductCarousel products={products} />
    </section>
  );
}
