"use client";

import { useState } from "react";
import Image from "next/image";
import { X, ZoomIn } from "lucide-react";

export function Gallery({ images, name }: { images: string[]; name: string }) {
  const [active, setActive] = useState(0);
  const [lightbox, setLightbox] = useState(false);

  return (
    <div>
      <div className="relative aspect-square w-full overflow-hidden rounded-md border border-border bg-surface">
        <Image
          key={images[active]}
          src={images[active]}
          alt={`${name} — تصویر ${active + 1}`}
          fill
          priority
          sizes="(max-width: 1024px) 100vw, 50vw"
          className="object-cover transition-opacity duration-300"
        />
        <button
          type="button"
          onClick={() => setLightbox(true)}
          aria-label="بزرگ‌نمایی تصویر"
          className="absolute bottom-3 end-3 rounded-full border border-border bg-paper/90 p-2.5 text-ink shadow-sm backdrop-blur hover:bg-paper"
        >
          <ZoomIn size={18} />
        </button>
      </div>

      {images.length > 1 && (
        <div className="mt-3 flex gap-2.5 overflow-x-auto pb-1">
          {images.map((img, idx) => (
            <button
              key={img + idx}
              type="button"
              onClick={() => setActive(idx)}
              aria-label={`نمایش تصویر ${idx + 1}`}
              aria-current={active === idx}
              className={`relative h-16 w-16 shrink-0 overflow-hidden rounded-sm border-2 transition-colors ${
                active === idx ? "border-champagne-dark" : "border-border hover:border-border-strong"
              }`}
            >
              <Image src={img} alt="" fill sizes="64px" className="object-cover" />
            </button>
          ))}
        </div>
      )}

      {lightbox && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`نمای تمام‌صفحه ${name}`}
          className="fixed inset-0 z-[90] flex items-center justify-center bg-ink/90 p-4"
          onClick={() => setLightbox(false)}
        >
          <button
            type="button"
            onClick={() => setLightbox(false)}
            aria-label="بستن"
            className="absolute top-4 end-4 rounded-full bg-paper/10 p-2.5 text-paper hover:bg-paper/20"
          >
            <X size={22} />
          </button>
          <div className="relative h-[85vh] w-full max-w-3xl" onClick={(e) => e.stopPropagation()}>
            <Image src={images[active]} alt={`${name} — بزرگ‌نمایی`} fill sizes="90vw" className="object-contain" />
          </div>
        </div>
      )}
    </div>
  );
}
