"use client";

import { useActionState } from "react";
import Link from "next/link";
import { loginAction, type AuthState } from "@/app/actions/auth";

const initialState: AuthState = { status: "idle", message: "" };

export function LoginForm() {
  const [state, formAction, pending] = useActionState(loginAction, initialState);

  return (
    <form action={formAction} className="flex flex-col gap-4" noValidate>
      <div>
        <label htmlFor="email" className="mb-1.5 block text-sm font-medium text-ink">
          ایمیل
        </label>
        <input
          id="email"
          name="email"
          type="email"
          required
          autoComplete="email"
          className="w-full rounded-sm border border-border-strong bg-paper px-3.5 py-2.5 text-sm text-ink focus:border-champagne-dark focus:outline-none"
        />
      </div>
      <div>
        <label htmlFor="password" className="mb-1.5 block text-sm font-medium text-ink">
          رمز عبور
        </label>
        <input
          id="password"
          name="password"
          type="password"
          required
          autoComplete="current-password"
          className="w-full rounded-sm border border-border-strong bg-paper px-3.5 py-2.5 text-sm text-ink focus:border-champagne-dark focus:outline-none"
        />
      </div>
      {state.status === "error" && (
        <p role="alert" className="rounded-sm bg-error/10 px-3 py-2 text-xs text-error">
          {state.message}
        </p>
      )}
      <button
        type="submit"
        disabled={pending}
        className="mt-2 rounded-sm bg-ink py-3 text-sm font-semibold text-paper hover:bg-charcoal disabled:bg-muted"
      >
        {pending ? "در حال ورود…" : "ورود"}
      </button>
      <p className="text-center text-xs text-muted">
        حساب کاربری ندارید؟{" "}
        <Link href="/account/register" className="font-medium text-champagne-dark hover:underline">
          ثبت‌نام کنید
        </Link>
      </p>
    </form>
  );
}
