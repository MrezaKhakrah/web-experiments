"use client";

import { useActionState, useRef, useEffect } from "react";
import { addAddressAction, type AddressState } from "@/app/actions/address";

const initialState: AddressState = { status: "idle", message: "" };

export function AddAddressForm() {
  const [state, formAction, pending] = useActionState(addAddressAction, initialState);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.status === "success") formRef.current?.reset();
  }, [state]);

  return (
    <form ref={formRef} action={formAction} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <label htmlFor="addr-fullName" className="mb-1 block text-xs font-medium text-ink">
          نام گیرنده
        </label>
        <input id="addr-fullName" name="fullName" required className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
      </div>
      <div>
        <label htmlFor="addr-phone" className="mb-1 block text-xs font-medium text-ink">
          شماره موبایل
        </label>
        <input id="addr-phone" name="phone" required className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
      </div>
      <div>
        <label htmlFor="addr-postalCode" className="mb-1 block text-xs font-medium text-ink">
          کد پستی
        </label>
        <input id="addr-postalCode" name="postalCode" required minLength={10} className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
      </div>
      <div>
        <label htmlFor="addr-province" className="mb-1 block text-xs font-medium text-ink">
          استان
        </label>
        <input id="addr-province" name="province" required className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
      </div>
      <div>
        <label htmlFor="addr-city" className="mb-1 block text-xs font-medium text-ink">
          شهر
        </label>
        <input id="addr-city" name="city" required className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
      </div>
      <div className="sm:col-span-2">
        <label htmlFor="addr-addressLine" className="mb-1 block text-xs font-medium text-ink">
          آدرس کامل
        </label>
        <textarea id="addr-addressLine" name="addressLine" required rows={2} className="w-full rounded-sm border border-border-strong bg-paper px-3 py-2.5 text-sm focus:border-champagne-dark focus:outline-none" />
      </div>
      {state.status !== "idle" && (
        <p role="status" className={`sm:col-span-2 text-xs ${state.status === "error" ? "text-error" : "text-success"}`}>
          {state.message}
        </p>
      )}
      <div className="sm:col-span-2">
        <button
          type="submit"
          disabled={pending}
          className="rounded-sm bg-ink px-5 py-2.5 text-xs font-semibold text-paper hover:bg-charcoal disabled:bg-muted"
        >
          {pending ? "در حال ذخیره…" : "افزودن آدرس"}
        </button>
      </div>
    </form>
  );
}
