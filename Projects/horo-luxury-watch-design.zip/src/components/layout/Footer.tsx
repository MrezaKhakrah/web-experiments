import Link from "next/link";
import { Camera, Send, MessageCircle } from "lucide-react";

const columns = [
  {
    title: "دسته‌بندی‌ها",
    links: [
      { label: "ساعت‌های هوشمند", href: "/products?category=smartwatches" },
      { label: "ساعت‌های کلاسیک", href: "/products?category=classic" },
      { label: "ساعت‌های اسپرت", href: "/products?category=sport" },
      { label: "ساعت‌های لوکس", href: "/products?category=luxury" },
      { label: "لوازم جانبی", href: "/products?category=accessories" },
    ],
  },
  {
    title: "راهنما و خدمات",
    links: [
      { label: "راهنمای خرید", href: "/guides" },
      { label: "اصالت و ضمانت کالا", href: "/guides/authenticity-warranty" },
      { label: "ارسال و تحویل", href: "/guides/shipping" },
      { label: "بازگشت و تعویض کالا", href: "/guides/returns" },
      { label: "سوالات متداول", href: "/guides" },
    ],
  },
  {
    title: "درباره هورو",
    links: [
      { label: "درباره ما", href: "/about" },
      { label: "برندهای موجود", href: "/brands" },
      { label: "تماس با ما", href: "/contact" },
      { label: "حریم خصوصی", href: "/privacy" },
      { label: "قوانین و مقررات", href: "/terms" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-border bg-surface/60">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <span className="text-2xl font-extrabold tracking-tight text-ink">HORO</span>
            <p className="mt-3 max-w-xs text-sm leading-7 text-muted">
              هورو، مقصدی برای انتخاب ساعت‌های هوشمند، کلاسیک، اسپرت و لوکس با تمرکز بر اصالت کالا،
              مشاوره تخصصی و خدمات پس از فروش شفاف.
            </p>
            <div className="mt-5 flex items-center gap-2">
              <a
                href="#"
                aria-label="اینستاگرام هورو"
                className="rounded-full border border-border-strong p-2 text-ink transition-colors hover:bg-ink hover:text-paper"
              >
                <Camera size={17} />
              </a>
              <a
                href="#"
                aria-label="تلگرام هورو"
                className="rounded-full border border-border-strong p-2 text-ink transition-colors hover:bg-ink hover:text-paper"
              >
                <Send size={17} />
              </a>
              <a
                href="#"
                aria-label="پشتیبانی واتس‌اپ"
                className="rounded-full border border-border-strong p-2 text-ink transition-colors hover:bg-ink hover:text-paper"
              >
                <MessageCircle size={17} />
              </a>
            </div>
          </div>

          {columns.map((col) => (
            <div key={col.title}>
              <h3 className="text-sm font-semibold text-ink">{col.title}</h3>
              <ul className="mt-4 flex flex-col gap-2.5">
                {col.links.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} className="text-sm text-muted transition-colors hover:text-ink">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-border pt-6 text-xs text-muted sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {toJalaliYear()} هورو — کلیهٔ حقوق محفوظ است. نام‌ها و لوگوهای برندهای ثالث صرفاً برای معرفی
            محصول ذکر شده‌اند و به‌معنای همکاری رسمی نیست.
          </p>
          <div className="flex items-center gap-4">
            <Link href="/privacy" className="hover:text-ink">
              حریم خصوصی
            </Link>
            <Link href="/terms" className="hover:text-ink">
              قوانین و مقررات
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

function toJalaliYear() {
  // Lightweight display-only approximation; not used for business logic.
  return new Date().getFullYear() - 621;
}
