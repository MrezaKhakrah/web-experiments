"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, Search, Heart, ShoppingBag, User, ChevronDown } from "lucide-react";
import { SearchBar } from "./SearchBar";
import { Drawer } from "@/components/ui/Drawer";
import { categoryNavLinks, primaryNavLinks } from "@/lib/nav";
import { useCartStore } from "@/lib/cart-store";
import { useWishlistStore } from "@/lib/wishlist-store";
import { toPersianDigits } from "@/lib/format";

export function Header({ isLoggedIn }: { isLoggedIn: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [categoriesOpen, setCategoriesOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  const cartCount = useCartStore((s) => s.items.reduce((n, i) => n + i.quantity, 0));
  const wishlistCount = useWishlistStore((s) => s.productIds.length);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-paper/95 backdrop-blur supports-[backdrop-filter]:bg-paper/80">
      <div
        className={`mx-auto flex max-w-7xl items-center gap-4 px-4 transition-[padding] duration-200 sm:px-6 ${
          scrolled ? "py-2.5" : "py-4"
        }`}
      >
        {/* Mobile menu button */}
        <button
          type="button"
          onClick={() => setMenuOpen(true)}
          className="rounded-sm p-2 text-ink hover:bg-surface lg:hidden"
          aria-label="باز کردن منو"
        >
          <Menu size={22} />
        </button>

        <Link href="/" className="flex shrink-0 items-center gap-2" aria-label="هورو — صفحه اصلی">
          <span className="text-2xl font-extrabold tracking-tight text-ink">HORO</span>
          <span className="hidden text-[11px] text-muted sm:inline">زمان، پالایش‌شده</span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="دسته‌بندی‌های اصلی">
          <div
            className="relative"
            onMouseEnter={() => setCategoriesOpen(true)}
            onMouseLeave={() => setCategoriesOpen(false)}
          >
            <button
              type="button"
              className="flex items-center gap-1 rounded-sm px-3 py-2 text-sm text-ink transition-colors hover:bg-surface"
              aria-expanded={categoriesOpen}
              onClick={() => setCategoriesOpen((v) => !v)}
            >
              دسته‌بندی‌ها <ChevronDown size={14} />
            </button>
            {categoriesOpen && (
              <div className="absolute start-0 top-full w-64 rounded-md border border-border bg-paper p-2 shadow-elevated">
                {categoryNavLinks.map((link) => (
                  <Link
                    key={link.href}
                    href={link.href}
                    className="block rounded-sm px-3 py-2 text-sm text-ink transition-colors hover:bg-surface"
                  >
                    {link.label}
                  </Link>
                ))}
              </div>
            )}
          </div>
          {primaryNavLinks.slice(2).map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-sm px-3 py-2 text-sm text-ink transition-colors hover:bg-surface"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden flex-1 lg:block">
          <SearchBar className="mx-auto max-w-md" />
        </div>

        <div className="mr-auto flex items-center gap-1 lg:mr-0">
          <button
            type="button"
            onClick={() => setMobileSearchOpen((v) => !v)}
            className="rounded-sm p-2.5 text-ink hover:bg-surface lg:hidden"
            aria-label="جستجو"
          >
            <Search size={20} />
          </button>
          <Link
            href={isLoggedIn ? "/account" : "/account/login"}
            className="hidden items-center gap-1.5 rounded-sm px-2.5 py-2 text-sm text-ink hover:bg-surface sm:flex"
          >
            <User size={19} />
            <span className="hidden xl:inline">{isLoggedIn ? "حساب من" : "ورود / ثبت‌نام"}</span>
          </Link>
          <Link
            href="/wishlist"
            className="relative rounded-sm p-2.5 text-ink hover:bg-surface"
            aria-label={`علاقه‌مندی‌ها (${toPersianDigits(wishlistCount)} مورد)`}
          >
            <Heart size={20} />
            {wishlistCount > 0 && (
              <span className="absolute -top-0.5 end-0 flex h-4 min-w-4 items-center justify-center rounded-full bg-champagne-dark px-1 text-[10px] font-semibold text-paper">
                {toPersianDigits(wishlistCount)}
              </span>
            )}
          </Link>
          <Link
            href="/cart"
            className="relative rounded-sm p-2.5 text-ink hover:bg-surface"
            aria-label={`سبد خرید (${toPersianDigits(cartCount)} کالا)`}
          >
            <ShoppingBag size={20} />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 end-0 flex h-4 min-w-4 items-center justify-center rounded-full bg-ink px-1 text-[10px] font-semibold text-paper">
                {toPersianDigits(cartCount)}
              </span>
            )}
          </Link>
        </div>
      </div>

      {mobileSearchOpen && (
        <div className="border-t border-border bg-paper px-4 py-3 lg:hidden">
          <SearchBar autoFocus />
        </div>
      )}

      <Drawer open={menuOpen} onClose={() => setMenuOpen(false)} title="منو" side="left">
        <nav className="flex flex-col p-4" aria-label="منوی موبایل">
          <p className="px-2 pb-2 pt-1 text-xs font-semibold text-muted">دسته‌بندی‌ها</p>
          {categoryNavLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="rounded-sm px-2 py-2.5 text-sm text-ink hover:bg-surface"
            >
              {link.label}
            </Link>
          ))}
          <div className="my-3 border-t border-border" />
          <Link href="/brands" onClick={() => setMenuOpen(false)} className="rounded-sm px-2 py-2.5 text-sm text-ink hover:bg-surface">
            برندها
          </Link>
          <Link href="/guides" onClick={() => setMenuOpen(false)} className="rounded-sm px-2 py-2.5 text-sm text-ink hover:bg-surface">
            راهنمای خرید
          </Link>
          <Link href="/compare" onClick={() => setMenuOpen(false)} className="rounded-sm px-2 py-2.5 text-sm text-ink hover:bg-surface">
            مقایسه محصولات
          </Link>
          <div className="my-3 border-t border-border" />
          <Link
            href={isLoggedIn ? "/account" : "/account/login"}
            onClick={() => setMenuOpen(false)}
            className="rounded-sm px-2 py-2.5 text-sm text-ink hover:bg-surface"
          >
            {isLoggedIn ? "حساب من" : "ورود / ثبت‌نام"}
          </Link>
          <Link href="/wishlist" onClick={() => setMenuOpen(false)} className="rounded-sm px-2 py-2.5 text-sm text-ink hover:bg-surface">
            علاقه‌مندی‌ها
          </Link>
        </nav>
      </Drawer>
    </header>
  );
}
