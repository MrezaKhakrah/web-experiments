"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Search, Loader2 } from "lucide-react";
import { formatCurrency } from "@/lib/format";

type Suggestion = { slug: string; nameFa: string; brandNameFa: string; image: string | null; price: number };

export function SearchBar({ className = "", autoFocus = false }: { className?: string; autoFocus?: boolean }) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  useEffect(() => {
    if (query.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    setLoading(true);
    const timeout = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search/suggest?q=${encodeURIComponent(query.trim())}`);
        const data = await res.json();
        setSuggestions(data.items ?? []);
        setOpen(true);
      } catch {
        setSuggestions([]);
      } finally {
        setLoading(false);
      }
    }, 250);
    return () => clearTimeout(timeout);
  }, [query]);

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!query.trim()) return;
    setOpen(false);
    router.push(`/products?q=${encodeURIComponent(query.trim())}`);
  }

  return (
    <div ref={containerRef} className={`relative w-full ${className}`}>
      <form onSubmit={submitSearch} role="search">
        <label htmlFor="site-search" className="sr-only">
          جستجوی محصولات
        </label>
        <div className="flex items-center gap-2 rounded-full border border-border bg-surface px-4 py-2.5 transition-colors focus-within:border-champagne-dark">
          <Search size={17} className="shrink-0 text-muted" />
          <input
            id="site-search"
            type="search"
            autoFocus={autoFocus}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => suggestions.length > 0 && setOpen(true)}
            placeholder="جستجوی برند، مدل یا نوع ساعت…"
            className="w-full bg-transparent text-sm text-ink placeholder:text-muted focus:outline-none"
          />
          {loading && <Loader2 size={15} className="animate-spin text-muted" />}
        </div>
      </form>

      {open && suggestions.length > 0 && (
        <div className="absolute inset-x-0 top-full z-50 mt-2 overflow-hidden rounded-md border border-border bg-paper shadow-elevated">
          <ul>
            {suggestions.map((s) => (
              <li key={s.slug}>
                <button
                  type="button"
                  onClick={() => {
                    setOpen(false);
                    setQuery("");
                    router.push(`/products/${s.slug}`);
                  }}
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-start transition-colors hover:bg-surface"
                >
                  <span className="relative h-11 w-11 shrink-0 overflow-hidden rounded-sm bg-surface">
                    {s.image && <Image src={s.image} alt="" fill sizes="44px" className="object-cover" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm text-ink">{s.nameFa}</span>
                    <span className="block text-xs text-muted">{s.brandNameFa}</span>
                  </span>
                  <span className="shrink-0 text-xs font-medium text-ink">{formatCurrency(s.price)}</span>
                </button>
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={submitSearch}
            className="block w-full border-t border-border px-4 py-2.5 text-center text-xs font-medium text-champagne-dark hover:bg-surface"
          >
            مشاهده همه نتایج برای «{query}»
          </button>
        </div>
      )}
    </div>
  );
}
