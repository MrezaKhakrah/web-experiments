"use client";

import Link from "next/link";
import { Scale, X } from "lucide-react";
import { useCompareStore } from "@/lib/compare-store";
import { toPersianDigits } from "@/lib/format";

export function CompareBar() {
  const productIds = useCompareStore((s) => s.productIds);
  const clear = useCompareStore((s) => s.clear);

  if (productIds.length === 0) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border-strong bg-ink text-paper shadow-elevated">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <div className="flex items-center gap-2 text-sm">
          <Scale size={18} className="text-champagne-light" />
          <span>
            {toPersianDigits(productIds.length)} محصول برای مقایسه انتخاب شده
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={clear}
            className="flex items-center gap-1 rounded-sm px-3 py-2 text-xs text-paper/70 transition-colors hover:text-paper"
          >
            <X size={14} /> پاک کردن
          </button>
          <Link
            href="/compare"
            className="rounded-sm bg-champagne px-4 py-2 text-xs font-semibold text-ink transition-colors hover:bg-champagne-light"
          >
            مقایسه محصولات
          </Link>
        </div>
      </div>
    </div>
  );
}
