"use client";

import { useEffect, useState } from "react";
import { X } from "lucide-react";

const STORAGE_KEY = "horo-announcement-dismissed-v1";
const MESSAGE = "ارسال رایگان برای سفارش‌های بالای ۱۰٬۰۰۰٬۰۰۰ تومان به سراسر کشور";

export function AnnouncementBar() {
  const [dismissed, setDismissed] = useState(true);

  useEffect(() => {
    setDismissed(localStorage.getItem(STORAGE_KEY) === "1");
  }, []);

  if (dismissed) return null;

  return (
    <div className="relative bg-ink text-paper">
      <div className="mx-auto flex max-w-7xl items-center justify-center px-10 py-2 text-center text-xs sm:text-[13px]">
        <p>{MESSAGE}</p>
        <button
          type="button"
          onClick={() => {
            localStorage.setItem(STORAGE_KEY, "1");
            setDismissed(true);
          }}
          aria-label="بستن اعلان"
          className="absolute end-2 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-paper/70 transition-colors hover:bg-white/10 hover:text-paper"
        >
          <X size={14} />
        </button>
      </div>
    </div>
  );
}
