import { db } from "@/db";
import { brands, categories, products, productVariants, reviews } from "@/db/schema";
import { and, asc, desc, eq, gte, ilike, inArray, lte, or, sql, SQL } from "drizzle-orm";

export type ProductListItem = Awaited<ReturnType<typeof getProducts>>["items"][number];

export type ProductFilters = {
  category?: string; // category slug
  watchType?: string[];
  brand?: string[]; // brand slugs
  gender?: string[];
  priceMin?: number;
  priceMax?: number;
  caseMaterial?: string[];
  strapMaterial?: string[];
  movement?: string[];
  displayType?: string[];
  connectivity?: string[];
  waterResistance?: number[];
  color?: string[];
  inStockOnly?: boolean;
  search?: string;
  sort?: "relevance" | "price-asc" | "price-desc" | "popularity" | "newest";
  page?: number;
  pageSize?: number;
};

const productColumns = {
  id: products.id,
  slug: products.slug,
  name: products.name,
  nameFa: products.nameFa,
  watchType: products.watchType,
  gender: products.gender,
  shortDescriptionFa: products.shortDescriptionFa,
  price: products.price,
  compareAtPrice: products.compareAtPrice,
  currency: products.currency,
  stock: products.stock,
  isFeatured: products.isFeatured,
  isBestseller: products.isBestseller,
  isNewArrival: products.isNewArrival,
  caseDiameterMm: products.caseDiameterMm,
  caseMaterial: products.caseMaterial,
  strapMaterial: products.strapMaterial,
  movement: products.movement,
  displayType: products.displayType,
  connectivity: products.connectivity,
  waterResistanceAtm: products.waterResistanceAtm,
  colorName: products.colorName,
  colorHex: products.colorHex,
  images: products.images,
  ratingAvg: products.ratingAvg,
  ratingCount: products.ratingCount,
  createdAt: products.createdAt,
  brandSlug: brands.slug,
  brandName: brands.name,
  brandNameFa: brands.nameFa,
  categorySlug: categories.slug,
  categoryNameFa: categories.nameFa,
};

function buildWhere(filters: ProductFilters): SQL | undefined {
  const clauses: SQL[] = [];

  if (filters.category) {
    clauses.push(eq(categories.slug, filters.category));
  }
  if (filters.watchType?.length) {
    clauses.push(inArray(products.watchType, filters.watchType));
  }
  if (filters.brand?.length) {
    clauses.push(inArray(brands.slug, filters.brand));
  }
  if (filters.gender?.length) {
    clauses.push(inArray(products.gender, filters.gender));
  }
  if (filters.priceMin !== undefined) {
    clauses.push(gte(products.price, filters.priceMin));
  }
  if (filters.priceMax !== undefined) {
    clauses.push(lte(products.price, filters.priceMax));
  }
  if (filters.caseMaterial?.length) {
    clauses.push(inArray(products.caseMaterial, filters.caseMaterial));
  }
  if (filters.strapMaterial?.length) {
    clauses.push(inArray(products.strapMaterial, filters.strapMaterial));
  }
  if (filters.movement?.length) {
    clauses.push(inArray(products.movement, filters.movement));
  }
  if (filters.displayType?.length) {
    clauses.push(inArray(products.displayType, filters.displayType));
  }
  if (filters.connectivity?.length) {
    clauses.push(inArray(products.connectivity, filters.connectivity));
  }
  if (filters.waterResistance?.length) {
    clauses.push(inArray(products.waterResistanceAtm, filters.waterResistance));
  }
  if (filters.color?.length) {
    clauses.push(inArray(products.colorName, filters.color));
  }
  if (filters.inStockOnly) {
    clauses.push(gte(products.stock, 1));
  }
  if (filters.search) {
    const term = `%${filters.search}%`;
    const searchClause = or(
      ilike(products.nameFa, term),
      ilike(products.name, term),
      ilike(brands.nameFa, term),
      ilike(brands.name, term),
      ilike(products.shortDescriptionFa, term),
    );
    if (searchClause) clauses.push(searchClause);
  }

  if (clauses.length === 0) return undefined;
  return and(...clauses);
}

export async function getProducts(filters: ProductFilters) {
  const page = filters.page && filters.page > 0 ? filters.page : 1;
  const pageSize = filters.pageSize && filters.pageSize > 0 ? filters.pageSize : 12;

  const where = buildWhere(filters);

  let orderBy;
  switch (filters.sort) {
    case "price-asc":
      orderBy = asc(products.price);
      break;
    case "price-desc":
      orderBy = desc(products.price);
      break;
    case "popularity":
      orderBy = desc(products.ratingCount);
      break;
    case "newest":
      orderBy = desc(products.createdAt);
      break;
    default:
      orderBy = desc(products.isFeatured);
  }

  const baseQuery = db
    .select(productColumns)
    .from(products)
    .innerJoin(brands, eq(products.brandId, brands.id))
    .innerJoin(categories, eq(products.categoryId, categories.id));

  const rows = await (where ? baseQuery.where(where) : baseQuery)
    .orderBy(orderBy, desc(products.id))
    .limit(pageSize)
    .offset((page - 1) * pageSize);

  const countQuery = db
    .select({ count: sql<number>`count(*)::int` })
    .from(products)
    .innerJoin(brands, eq(products.brandId, brands.id))
    .innerJoin(categories, eq(products.categoryId, categories.id));

  const countRows = await (where ? countQuery.where(where) : countQuery);
  const total = countRows[0]?.count ?? 0;

  return {
    items: rows,
    total,
    page,
    pageSize,
    totalPages: Math.max(1, Math.ceil(total / pageSize)),
  };
}

export async function getProductBySlug(slug: string) {
  const rows = await db
    .select(productColumns)
    .from(products)
    .innerJoin(brands, eq(products.brandId, brands.id))
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.slug, slug))
    .limit(1);

  const product = rows[0];
  if (!product) return null;

  const [variants, productReviews, fullRow] = await Promise.all([
    db.select().from(productVariants).where(eq(productVariants.productId, product.id)),
    db
      .select()
      .from(reviews)
      .where(eq(reviews.productId, product.id))
      .orderBy(desc(reviews.createdAt)),
    db.select().from(products).where(eq(products.id, product.id)).limit(1),
  ]);

  return { ...product, variants, reviews: productReviews, full: fullRow[0] };
}

export async function getProductsByIds(ids: number[]) {
  if (ids.length === 0) return [];
  return db
    .select(productColumns)
    .from(products)
    .innerJoin(brands, eq(products.brandId, brands.id))
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(inArray(products.id, ids));
}

export async function getRelatedProducts(categoryId: number, excludeId: number, limit = 4) {
  return db
    .select(productColumns)
    .from(products)
    .innerJoin(brands, eq(products.brandId, brands.id))
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(and(eq(products.categoryId, categoryId), sql`${products.id} != ${excludeId}`))
    .limit(limit);
}

export async function getAllCategories() {
  return db.select().from(categories).orderBy(asc(categories.sortOrder));
}

export async function getAllBrands() {
  return db.select().from(brands).orderBy(asc(brands.sortOrder));
}

export async function getFilterFacets() {
  const rows = await db
    .select({
      caseMaterial: products.caseMaterial,
      strapMaterial: products.strapMaterial,
      movement: products.movement,
      displayType: products.displayType,
      connectivity: products.connectivity,
      waterResistanceAtm: products.waterResistanceAtm,
      colorName: products.colorName,
      colorHex: products.colorHex,
      price: products.price,
    })
    .from(products);

  const unique = <T,>(arr: (T | null | undefined)[]) =>
    Array.from(new Set(arr.filter((v): v is T => v !== null && v !== undefined)));

  return {
    caseMaterials: unique(rows.map((r) => r.caseMaterial)),
    strapMaterials: unique(rows.map((r) => r.strapMaterial)),
    movements: unique(rows.map((r) => r.movement)),
    displayTypes: unique(rows.map((r) => r.displayType)),
    connectivities: unique(rows.map((r) => r.connectivity)),
    waterResistances: unique(rows.map((r) => r.waterResistanceAtm)).sort((a, b) => a - b),
    colors: unique(rows.map((r) => (r.colorName ? `${r.colorName}|${r.colorHex}` : null))),
    priceMin: rows.length ? Math.min(...rows.map((r) => r.price)) : 0,
    priceMax: rows.length ? Math.max(...rows.map((r) => r.price)) : 0,
  };
}
