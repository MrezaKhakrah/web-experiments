import {
  pgTable,
  serial,
  text,
  integer,
  numeric,
  boolean,
  jsonb,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Catalog
// ---------------------------------------------------------------------------

export const brands = pgTable("brands", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  nameFa: text("name_fa").notNull(),
  description: text("description"),
  country: text("country"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  nameFa: text("name_fa").notNull(),
  descriptionFa: text("description_fa"),
  icon: text("icon").notNull().default("watch"),
  heroImage: text("hero_image"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull().unique(),
    name: text("name").notNull(),
    nameFa: text("name_fa").notNull(),
    brandId: integer("brand_id")
      .notNull()
      .references(() => brands.id),
    categoryId: integer("category_id")
      .notNull()
      .references(() => categories.id),
    watchType: text("watch_type").notNull(), // smartwatch | classic | sport | luxury
    gender: text("gender").notNull(), // men | women | unisex
    shortDescriptionFa: text("short_description_fa").notNull(),
    descriptionFa: text("description_fa").notNull(),
    sku: text("sku").notNull().unique(),
    price: integer("price").notNull(), // in Toman
    compareAtPrice: integer("compare_at_price"),
    currency: text("currency").notNull().default("IRT"),
    stock: integer("stock").notNull().default(0),
    isFeatured: boolean("is_featured").notNull().default(false),
    isBestseller: boolean("is_bestseller").notNull().default(false),
    isNewArrival: boolean("is_new_arrival").notNull().default(false),
    caseDiameterMm: numeric("case_diameter_mm", { precision: 5, scale: 1 }),
    caseThicknessMm: numeric("case_thickness_mm", { precision: 5, scale: 1 }),
    caseMaterial: text("case_material").notNull(),
    strapMaterial: text("strap_material").notNull(),
    movement: text("movement").notNull(),
    displayType: text("display_type").notNull(), // analog | digital | amoled | hybrid
    glassType: text("glass_type"),
    waterResistanceAtm: integer("water_resistance_atm"),
    batteryLifeDays: integer("battery_life_days"),
    connectivity: text("connectivity"),
    colorName: text("color_name").notNull(),
    colorHex: text("color_hex").notNull(),
    images: jsonb("images").$type<string[]>().notNull(),
    includedAccessories: text("included_accessories"),
    warrantyMonths: integer("warranty_months").notNull().default(12),
    ratingAvg: numeric("rating_avg", { precision: 2, scale: 1 }).notNull().default("0"),
    ratingCount: integer("rating_count").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => [uniqueIndex("products_slug_idx").on(table.slug)],
);

export const productVariants = pgTable("product_variants", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id, { onDelete: "cascade" }),
  colorName: text("color_name").notNull(),
  colorHex: text("color_hex").notNull(),
  strapMaterial: text("strap_material").notNull(),
  sku: text("sku").notNull().unique(),
  priceDelta: integer("price_delta").notNull().default(0),
  stock: integer("stock").notNull().default(0),
  image: text("image"),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id, { onDelete: "cascade" }),
  authorName: text("author_name").notNull(),
  rating: integer("rating").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  verifiedPurchase: boolean("verified_purchase").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------------------------------------------------------------------------
// Accounts
// ---------------------------------------------------------------------------

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  fullName: text("full_name").notNull(),
  phone: text("phone"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const addresses = pgTable("addresses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  province: text("province").notNull(),
  city: text("city").notNull(),
  addressLine: text("address_line").notNull(),
  postalCode: text("postal_code").notNull(),
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------------------------------------------------------------------------
// Commerce
// ---------------------------------------------------------------------------

export const discountCodes = pgTable("discount_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  percentOff: integer("percent_off"),
  amountOff: integer("amount_off"),
  minSubtotal: integer("min_subtotal").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  userId: integer("user_id").references(() => users.id),
  guestEmail: text("guest_email"),
  guestPhone: text("guest_phone"),
  status: text("status").notNull().default("pending"), // pending | confirmed | processing | shipped | delivered | cancelled
  subtotal: integer("subtotal").notNull(),
  shippingCost: integer("shipping_cost").notNull(),
  discountAmount: integer("discount_amount").notNull().default(0),
  discountCode: text("discount_code"),
  total: integer("total").notNull(),
  currency: text("currency").notNull().default("IRT"),
  shippingAddress: jsonb("shipping_address").$type<{
    fullName: string;
    phone: string;
    province: string;
    city: string;
    addressLine: string;
    postalCode: string;
  }>().notNull(),
  paymentMethod: text("payment_method").notNull(), // cod | card
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id")
    .notNull()
    .references(() => orders.id, { onDelete: "cascade" }),
  productId: integer("product_id").references(() => products.id),
  productNameFa: text("product_name_fa").notNull(),
  variantLabel: text("variant_label"),
  unitPrice: integer("unit_price").notNull(),
  quantity: integer("quantity").notNull(),
  imageUrl: text("image_url"),
});

export const newsletterSubscribers = pgTable("newsletter_subscribers", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
