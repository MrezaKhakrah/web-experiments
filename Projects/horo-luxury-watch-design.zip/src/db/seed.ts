import "dotenv/config";
import { db, pool } from "@/db";
import {
  brands,
  categories,
  products,
  productVariants,
  reviews,
  discountCodes,
} from "@/db/schema";
import { sql } from "drizzle-orm";

// Local art-directed studio photography (generated for HORO)
const IMG = {
  hero: "/images/hero-main.jpg",
  smartwatch: "/images/category-smartwatch.jpg",
  classic: "/images/category-classic.jpg",
  sport: "/images/category-sport.jpg",
  luxury: "/images/category-luxury.jpg",
  womens: "/images/category-womens.jpg",
  mens: "/images/category-mens.jpg",
  accessories: "/images/category-accessories.jpg",
  movement: "/images/editorial-feature.jpg",
  gifts: "/images/collection-gifts.jpg",
};

// Licensed stock lifestyle photography (Pexels) used for gallery variety
const STOCK = {
  wheel: "https://images.pexels.com/photos/6722096/pexels-photo-6722096.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1000",
  display: "https://images.pexels.com/photos/39082420/pexels-photo-39082420.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1000",
  silverArm: "https://images.pexels.com/photos/37994761/pexels-photo-37994761.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1000",
  sea: "https://images.pexels.com/photos/13593586/pexels-photo-13593586.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1000",
  suit: "https://images.pexels.com/photos/11745345/pexels-photo-11745345.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1000",
  mountain: "https://images.pexels.com/photos/11136242/pexels-photo-11136242.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1000",
  stone: "https://images.pexels.com/photos/13273982/pexels-photo-13273982.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1000",
  blackBg: "https://images.pexels.com/photos/13273983/pexels-photo-13273983.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1000",
  chrono: "https://images.pexels.com/photos/13273980/pexels-photo-13273980.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1000",
};

type SeedProduct = {
  slug: string;
  name: string;
  nameFa: string;
  brand: string;
  category: "smartwatches" | "classic" | "sport" | "luxury" | "accessories";
  watchType: "smartwatch" | "classic" | "sport" | "luxury" | "accessory";
  gender: "men" | "women" | "unisex";
  shortDescriptionFa: string;
  descriptionFa: string;
  sku: string;
  price: number;
  compareAtPrice?: number;
  stock: number;
  isFeatured?: boolean;
  isBestseller?: boolean;
  isNewArrival?: boolean;
  caseDiameterMm?: string;
  caseThicknessMm?: string;
  caseMaterial: string;
  strapMaterial: string;
  movement: string;
  displayType: string;
  glassType?: string;
  waterResistanceAtm?: number;
  batteryLifeDays?: number;
  connectivity?: string;
  colorName: string;
  colorHex: string;
  images: string[];
  includedAccessories?: string;
  warrantyMonths?: number;
  variants?: { colorName: string; colorHex: string; strapMaterial: string; priceDelta: number; stock: number; image?: string }[];
};

const seedProducts: SeedProduct[] = [
  // ---------------- SMARTWATCHES ----------------
  {
    slug: "apple-watch-series-9-45",
    name: "Apple Watch Series 9 GPS 45mm",
    nameFa: "اپل واچ سری ۹ (GPS) ۴۵ میلی‌متر",
    brand: "Apple",
    category: "smartwatches",
    watchType: "smartwatch",
    gender: "unisex",
    shortDescriptionFa: "صفحه‌نمایش Always-On روشن‌تر، تراشه S9 و قابلیت ژست دوضرب.",
    descriptionFa:
      "اپل واچ سری ۹ با تراشه S9 جدید، سریع‌تر و کارآمدتر از نسل‌های قبل عمل می‌کند. صفحه‌نمایش Retina با حداکثر روشنایی ۲۰۰۰ نیت در نور مستقیم آفتاب نیز به‌خوبی خوانا است. حسگر اکسیژن خون، اپ ECG و تشخیص سقوط برای پایش سلامت روزانه در این مدل تعبیه شده‌اند.",
    sku: "AW-S9-45-MID",
    price: 32500000,
    compareAtPrice: 35900000,
    stock: 14,
    isFeatured: true,
    isBestseller: true,
    caseDiameterMm: "45.0",
    caseThicknessMm: "10.7",
    caseMaterial: "آلومینیوم",
    strapMaterial: "سیلیکون",
    movement: "هوشمند",
    displayType: "amoled",
    glassType: "کریستال یاقوت نسوز",
    waterResistanceAtm: 5,
    batteryLifeDays: 1,
    connectivity: "بلوتوث ۵.۳، وای‌فای، GPS",
    colorName: "مشکی نیمه‌شب",
    colorHex: "#1b1b1f",
    images: [IMG.smartwatch, STOCK.display, STOCK.blackBg],
    includedAccessories: "کابل شارژ مغناطیسی، بند اسپرت",
    warrantyMonths: 12,
    variants: [
      { colorName: "مشکی نیمه‌شب", colorHex: "#1b1b1f", strapMaterial: "سیلیکون", priceDelta: 0, stock: 8 },
      { colorName: "نقره‌ای", colorHex: "#d9d9d9", strapMaterial: "سیلیکون", priceDelta: 0, stock: 6 },
    ],
  },
  {
    slug: "galaxy-watch6-classic-47",
    name: "Samsung Galaxy Watch6 Classic 47mm",
    nameFa: "سامسونگ گلکسی واچ ۶ کلاسیک ۴۷ میلی‌متر",
    brand: "Samsung",
    category: "smartwatches",
    watchType: "smartwatch",
    gender: "unisex",
    shortDescriptionFa: "بزل چرخان فیزیکی، صفحه‌نمایش Super AMOLED و پایش پیشرفته خواب.",
    descriptionFa:
      "گلکسی واچ ۶ کلاسیک با بازگشت بزل چرخان فیزیکی، تعامل لمسی دقیق‌تری ارائه می‌دهد. بدنه استیل ضدزنگ و صفحه‌نمایش Super AMOLED روشن، آن را برای استفاده روزانه و ورزشی مناسب کرده است.",
    sku: "SGW6-C-47-SLV",
    price: 24900000,
    stock: 20,
    isBestseller: true,
    caseDiameterMm: "47.0",
    caseThicknessMm: "11.2",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "سیلیکون",
    movement: "هوشمند",
    displayType: "amoled",
    glassType: "شیشه یاقوتی مقاوم",
    waterResistanceAtm: 5,
    batteryLifeDays: 2,
    connectivity: "بلوتوث، وای‌فای، NFC",
    colorName: "نقره‌ای",
    colorHex: "#c7c9cc",
    images: [IMG.smartwatch, STOCK.silverArm, STOCK.mountain],
    includedAccessories: "کابل شارژ بی‌سیم",
    variants: [
      { colorName: "نقره‌ای", colorHex: "#c7c9cc", strapMaterial: "سیلیکون", priceDelta: 0, stock: 12 },
      { colorName: "مشکی", colorHex: "#222222", strapMaterial: "سیلیکون", priceDelta: 0, stock: 8 },
    ],
  },
  {
    slug: "garmin-fenix-7-solar",
    name: "Garmin Fenix 7 Solar",
    nameFa: "گارمین فنیکس ۷ سولار",
    brand: "Garmin",
    category: "smartwatches",
    watchType: "smartwatch",
    gender: "unisex",
    shortDescriptionFa: "بدنه تیتانیومی، شارژ خورشیدی و نقشه‌های توپوگرافی داخلی.",
    descriptionFa:
      "فنیکس ۷ برای کوهنوردی و ماجراجویی طراحی شده است. صفحه نمایش ترانس‌فلکتیو همیشه‌روشن همراه با پنل شارژ خورشیدی، در مصرف باتری صرفه‌جویی قابل توجهی ایجاد می‌کند و نقشه‌های توپوگرافی از پیش بارگذاری‌شده مسیر را نشان می‌دهند.",
    sku: "GAR-F7-SLR-GRY",
    price: 41000000,
    compareAtPrice: 45500000,
    stock: 7,
    isFeatured: true,
    caseDiameterMm: "47.0",
    caseThicknessMm: "14.5",
    caseMaterial: "تیتانیوم",
    strapMaterial: "سیلیکون",
    movement: "هوشمند",
    displayType: "hybrid",
    glassType: "شیشه یاقوتی",
    waterResistanceAtm: 10,
    batteryLifeDays: 18,
    connectivity: "بلوتوث، ANT+، GPS چندباندی",
    colorName: "خاکستری سنگی",
    colorHex: "#6b6f72",
    images: [IMG.sport, STOCK.mountain, STOCK.stone],
    includedAccessories: "کابل شارژ اختصاصی",
    variants: [
      { colorName: "خاکستری سنگی", colorHex: "#6b6f72", strapMaterial: "سیلیکون", priceDelta: 0, stock: 4 },
      { colorName: "مشکی", colorHex: "#141414", strapMaterial: "سیلیکون", priceDelta: 500000, stock: 3 },
    ],
  },
  {
    slug: "horo-pulse-2-amoled",
    name: "HORO Pulse 2 AMOLED",
    nameFa: "هورو پالس ۲ آمولد",
    brand: "HORO",
    category: "smartwatches",
    watchType: "smartwatch",
    gender: "unisex",
    shortDescriptionFa: "محصول اختصاصی هورو با صفحه آمولد روشن و باتری ۱۰ روزه.",
    descriptionFa:
      "پالس ۲ محصول اختصاصی برند هورو برای کاربرانی است که به دنبال ساعت هوشمند مقرون‌به‌صرفه با کیفیت ساخت بالا هستند. بدنه آلومینیومی سبک، صفحه آمولد با روشنایی بالا و باتری تا ۱۰ روز از ویژگی‌های اصلی آن است.",
    sku: "HORO-P2-GRF",
    price: 7900000,
    stock: 30,
    isNewArrival: true,
    isBestseller: true,
    caseDiameterMm: "44.0",
    caseThicknessMm: "10.9",
    caseMaterial: "آلومینیوم",
    strapMaterial: "سیلیکون",
    movement: "هوشمند",
    displayType: "amoled",
    glassType: "شیشه سخت‌شده",
    waterResistanceAtm: 5,
    batteryLifeDays: 10,
    connectivity: "بلوتوث ۵.۲",
    colorName: "گرافیتی",
    colorHex: "#3a3a3c",
    images: [IMG.smartwatch, STOCK.blackBg],
    includedAccessories: "کابل شارژ مغناطیسی، بند یدک",
    variants: [
      { colorName: "گرافیتی", colorHex: "#3a3a3c", strapMaterial: "سیلیکون", priceDelta: 0, stock: 18 },
      { colorName: "آبی اقیانوسی", colorHex: "#2e5c8a", strapMaterial: "سیلیکون", priceDelta: 0, stock: 12 },
    ],
  },
  {
    slug: "galaxy-watch-fe",
    name: "Samsung Galaxy Watch FE",
    nameFa: "سامسونگ گلکسی واچ FE",
    brand: "Samsung",
    category: "smartwatches",
    watchType: "smartwatch",
    gender: "women",
    shortDescriptionFa: "بدنه سبک و جمع‌وجور، مناسب مچ‌های ظریف با قیمتی مناسب‌تر.",
    descriptionFa:
      "گلکسی واچ FE نسخه‌ای جمع‌وجورتر و مقرون‌به‌صرفه از خانواده گلکسی واچ است که بدون افت کیفیت ساخت، تجربه‌ای روان از پایش سلامت و اعلان‌های هوشمند ارائه می‌دهد.",
    sku: "SGW-FE-PNK",
    price: 12400000,
    stock: 16,
    isNewArrival: true,
    caseDiameterMm: "40.0",
    caseThicknessMm: "9.8",
    caseMaterial: "آلومینیوم",
    strapMaterial: "سیلیکون",
    movement: "هوشمند",
    displayType: "amoled",
    glassType: "شیشه یاقوتی مقاوم",
    waterResistanceAtm: 5,
    batteryLifeDays: 2,
    connectivity: "بلوتوث، وای‌فای",
    colorName: "صورتی‌طلایی",
    colorHex: "#d9b8a7",
    images: [IMG.womens, STOCK.silverArm],
    variants: [
      { colorName: "صورتی‌طلایی", colorHex: "#d9b8a7", strapMaterial: "سیلیکون", priceDelta: 0, stock: 10 },
    ],
  },

  // ---------------- CLASSIC ----------------
  {
    slug: "seiko-presage-cocktail-time",
    name: "Seiko Presage Cocktail Time",
    nameFa: "سایکو پرساژ کوکتل‌تایم",
    brand: "Seiko",
    category: "classic",
    watchType: "classic",
    gender: "unisex",
    shortDescriptionFa: "صفحه آبی چندلایه الهام‌گرفته از هنر کوکتل‌سازی ژاپنی.",
    descriptionFa:
      "مجموعه کوکتل‌تایم با صفحه‌نمایش چندلایه و رنگ‌آمیزی گرادیانی، الهام‌گرفته از فرهنگ کوکتل‌سازی ژاپن است. موتور خودکار ۴R35 بدون نیاز به باتری، با تاب‌خوردن دست یا حرکت طبیعی مچ شارژ می‌شود.",
    sku: "SEI-PRES-CKT-BLU",
    price: 28500000,
    stock: 9,
    isFeatured: true,
    caseDiameterMm: "40.5",
    caseThicknessMm: "11.8",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "چرم",
    movement: "خودکار",
    displayType: "analog",
    glassType: "کریستال یاقوتی",
    waterResistanceAtm: 3,
    colorName: "آبی",
    colorHex: "#1c3f66",
    images: [IMG.classic, STOCK.stone, STOCK.chrono],
    includedAccessories: "جعبه چوبی اورجینال",
    variants: [
      { colorName: "آبی", colorHex: "#1c3f66", strapMaterial: "چرم", priceDelta: 0, stock: 5 },
      { colorName: "سفید مرواریدی", colorHex: "#efe9df", strapMaterial: "چرم", priceDelta: 0, stock: 4 },
    ],
  },
  {
    slug: "tissot-le-locle-automatic",
    name: "Tissot Le Locle Automatic",
    nameFa: "تیسوت لولوکل اتوماتیک",
    brand: "Tissot",
    category: "classic",
    watchType: "classic",
    gender: "men",
    shortDescriptionFa: "طراحی کلاسیک سوئیسی با صفحه گیوشه و عقربه‌های رومی.",
    descriptionFa:
      "لولوکل یکی از نمادی‌ترین مدل‌های کلاسیک تیسوت است که صفحه گیوشه‌دار ظریف و عقربه‌های رومی آن، حس شیک و رسمی را به مچ منتقل می‌کند. موتور خودکار سوئیسی ETC2671 آن دقتی قابل اعتماد ارائه می‌دهد.",
    sku: "TIS-LLC-AUTO-WHT",
    price: 33200000,
    compareAtPrice: 36000000,
    stock: 6,
    caseDiameterMm: "39.3",
    caseThicknessMm: "11.4",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "چرم",
    movement: "خودکار",
    displayType: "analog",
    glassType: "کریستال یاقوتی ضدخش",
    waterResistanceAtm: 3,
    colorName: "سفید",
    colorHex: "#f3efe6",
    images: [IMG.classic, STOCK.suit],
    variants: [{ colorName: "سفید", colorHex: "#f3efe6", strapMaterial: "چرم", priceDelta: 0, stock: 6 }],
  },
  {
    slug: "citizen-eco-drive-classic",
    name: "Citizen Eco-Drive Classic",
    nameFa: "سیتیزن اکو-درایو کلاسیک",
    brand: "Citizen",
    category: "classic",
    watchType: "classic",
    gender: "men",
    shortDescriptionFa: "شارژ با نور محیط، بدون نیاز به تعویض باتری.",
    descriptionFa:
      "فناوری Eco-Drive سیتیزن انرژی را از هر منبع نوری (طبیعی یا مصنوعی) دریافت و ذخیره می‌کند، به‌طوری‌که عملاً هرگز نیازی به تعویض باتری نخواهید داشت. طراحی صفحه ساده و خوانا، این مدل را برای استفاده روزمره رسمی مناسب کرده است.",
    sku: "CTZ-ECO-CLS-SLV",
    price: 14800000,
    stock: 18,
    caseDiameterMm: "41.0",
    caseThicknessMm: "9.7",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "استیل",
    movement: "کوارتز سولار",
    displayType: "analog",
    glassType: "کریستال معدنی",
    waterResistanceAtm: 5,
    colorName: "نقره‌ای",
    colorHex: "#c9cbce",
    images: [IMG.classic, STOCK.silverArm],
    variants: [{ colorName: "نقره‌ای", colorHex: "#c9cbce", strapMaterial: "استیل", priceDelta: 0, stock: 18 }],
  },
  {
    slug: "fossil-minimalist-leather",
    name: "Fossil Minimalist Leather",
    nameFa: "فسیل مینیمالیست چرمی",
    brand: "Fossil",
    category: "classic",
    watchType: "classic",
    gender: "women",
    shortDescriptionFa: "صفحه نازک طلایی‌رز و بند چرمی نرم، مناسب مچ‌های ظریف.",
    descriptionFa:
      "مدل مینیمالیست فسیل با بدنه نازک و صفحه ساده طلایی‌رز، انتخابی کاربردی برای استفاده روزانه است. بند چرمی قابل تعویض آن امکان شخصی‌سازی ظاهر ساعت را فراهم می‌کند.",
    sku: "FOS-MIN-LTH-RSG",
    price: 6200000,
    stock: 22,
    isBestseller: true,
    caseDiameterMm: "36.0",
    caseThicknessMm: "7.7",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "چرم",
    movement: "کوارتز",
    displayType: "analog",
    glassType: "کریستال معدنی",
    waterResistanceAtm: 3,
    colorName: "طلایی‌رز",
    colorHex: "#c79a84",
    images: [IMG.womens, STOCK.stone],
    variants: [
      { colorName: "طلایی‌رز", colorHex: "#c79a84", strapMaterial: "چرم", priceDelta: 0, stock: 14 },
      { colorName: "مشکی", colorHex: "#232323", strapMaterial: "چرم", priceDelta: 0, stock: 8 },
    ],
  },
  {
    slug: "orient-bambino-automatic",
    name: "Orient Bambino Automatic",
    nameFa: "اورینت بامبینو اتوماتیک",
    brand: "Orient",
    category: "classic",
    watchType: "classic",
    gender: "men",
    shortDescriptionFa: "شیشه دوم گنبدی و صفحه ساده، الهام‌گرفته از ساعت‌های دهه ۱۹۶۰.",
    descriptionFa:
      "بامبینو با شیشه دوم (دوم‌شیشه) گنبدی‌شکل و طراحی رترو، حس و حال ساعت‌های کلاسیک دهه ۶۰ میلادی را بازآفرینی می‌کند. موتور خودکار F6724 با ذخیره انرژی حدود ۴۰ ساعت در این مدل به‌کار رفته است.",
    sku: "ORI-BAM-AUTO-BLK",
    price: 11900000,
    stock: 11,
    caseDiameterMm: "40.5",
    caseThicknessMm: "11.7",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "چرم",
    movement: "خودکار",
    displayType: "analog",
    glassType: "شیشه دوم گنبدی",
    waterResistanceAtm: 3,
    colorName: "مشکی",
    colorHex: "#111111",
    images: [IMG.classic, STOCK.chrono],
    variants: [{ colorName: "مشکی", colorHex: "#111111", strapMaterial: "چرم", priceDelta: 0, stock: 11 }],
  },

  // ---------------- SPORT ----------------
  {
    slug: "casio-gshock-ga2100",
    name: "Casio G-Shock GA-2100",
    nameFa: "کاسیو جی‌شاک GA-2100",
    brand: "Casio",
    category: "sport",
    watchType: "sport",
    gender: "men",
    shortDescriptionFa: "بدنه اکتاگونال سبک و مقاوم در برابر ضربه، معروف به «کاسیوک».",
    descriptionFa:
      "GA-2100 با بدنه اکتاگونال نازک و ساختار مقاوم در برابر ضربه، یکی از محبوب‌ترین مدل‌های جی‌شاک در سال‌های اخیر است. ترکیب موتور کوارتز دیجیتال-آنالوگ، کرنومتر، تایمر و روشنایی LED را ارائه می‌دهد.",
    sku: "CAS-GA2100-BLK",
    price: 5400000,
    stock: 40,
    isBestseller: true,
    caseDiameterMm: "45.4",
    caseThicknessMm: "11.8",
    caseMaterial: "رزین مقاوم",
    strapMaterial: "کائوچو",
    movement: "کوارتز",
    displayType: "digital",
    glassType: "کریستال معدنی",
    waterResistanceAtm: 20,
    batteryLifeDays: 1095,
    colorName: "مشکی",
    colorHex: "#151515",
    images: [IMG.sport, STOCK.blackBg],
    variants: [
      { colorName: "مشکی", colorHex: "#151515", strapMaterial: "کائوچو", priceDelta: 0, stock: 25 },
      { colorName: "خاکی", colorHex: "#6b6553", strapMaterial: "کائوچو", priceDelta: 150000, stock: 15 },
    ],
  },
  {
    slug: "seiko-prospex-diver",
    name: "Seiko Prospex Diver",
    nameFa: "سایکو پراسپکس دایور",
    brand: "Seiko",
    category: "sport",
    watchType: "sport",
    gender: "men",
    shortDescriptionFa: "مقاومت در برابر آب تا ۲۰۰ متر، استاندارد غواصی ایزو ۶۴۲۵.",
    descriptionFa:
      "پراسپکس دایور با بزل یک‌طرفه چرخان و درخشش لومینسنت قوی روی عقربه‌ها، برای غواصی حرفه‌ای طراحی شده و مطابق استاندارد ISO 6425 مقاومت آب تا ۲۰۰ متر را تضمین می‌کند.",
    sku: "SEI-PROS-DIV-ORG",
    price: 31000000,
    compareAtPrice: 34500000,
    stock: 8,
    isFeatured: true,
    caseDiameterMm: "42.0",
    caseThicknessMm: "13.2",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "کائوچو",
    movement: "خودکار",
    displayType: "analog",
    glassType: "کریستال یاقوتی",
    waterResistanceAtm: 20,
    colorName: "نارنجی مشکی",
    colorHex: "#c9521d",
    images: [IMG.sport, STOCK.sea],
    variants: [{ colorName: "نارنجی مشکی", colorHex: "#c9521d", strapMaterial: "کائوچو", priceDelta: 0, stock: 8 }],
  },
  {
    slug: "garmin-instinct-2",
    name: "Garmin Instinct 2",
    nameFa: "گارمین اینستینکت ۲",
    brand: "Garmin",
    category: "sport",
    watchType: "sport",
    gender: "unisex",
    shortDescriptionFa: "استاندارد نظامی مقاومت و باتری تا ۲۸ روز در حالت ساعت هوشمند.",
    descriptionFa:
      "اینستینکت ۲ با گواهی مقاومت نظامی (MIL-STD-810) در برابر ضربه، دما و رطوبت ساخته شده و با صفحه ترانس‌فلکتیو کم‌مصرف، تا ۲۸ روز با یک بار شارژ کار می‌کند.",
    sku: "GAR-INST2-GRF",
    price: 16500000,
    stock: 13,
    isNewArrival: true,
    caseDiameterMm: "45.0",
    caseThicknessMm: "14.4",
    caseMaterial: "پلاستیک مقاوم",
    strapMaterial: "سیلیکون",
    movement: "هوشمند",
    displayType: "hybrid",
    glassType: "شیشه کوره‌ای مقاوم",
    waterResistanceAtm: 10,
    batteryLifeDays: 28,
    connectivity: "بلوتوث، ANT+، GPS",
    colorName: "گرافیتی",
    colorHex: "#2e2e2e",
    images: [IMG.sport, STOCK.mountain],
    variants: [{ colorName: "گرافیتی", colorHex: "#2e2e2e", strapMaterial: "سیلیکون", priceDelta: 0, stock: 13 }],
  },
  {
    slug: "citizen-promaster-marine",
    name: "Citizen Promaster Marine",
    nameFa: "سیتیزن پرومستر مارین",
    brand: "Citizen",
    category: "sport",
    watchType: "sport",
    gender: "men",
    shortDescriptionFa: "طراحی غواصی با بزل چرخشی و شارژ نوری Eco-Drive.",
    descriptionFa:
      "پرومستر مارین برای فعالیت‌های دریایی طراحی شده و با فناوری Eco-Drive، انرژی مورد نیاز را از نور محیط تأمین می‌کند. بزل یک‌طرفه و صفحه با کنتراست بالا، خوانایی زیر آب را تضمین می‌کند.",
    sku: "CTZ-PROM-MAR-BLU",
    price: 19800000,
    stock: 10,
    caseDiameterMm: "44.0",
    caseThicknessMm: "12.8",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "کائوچو",
    movement: "کوارتز سولار",
    displayType: "analog",
    glassType: "کریستال معدنی",
    waterResistanceAtm: 20,
    colorName: "آبی",
    colorHex: "#1c4d73",
    images: [IMG.sport, STOCK.sea],
    variants: [{ colorName: "آبی", colorHex: "#1c4d73", strapMaterial: "کائوچو", priceDelta: 0, stock: 10 }],
  },
  {
    slug: "casio-edifice-chronograph",
    name: "Casio Edifice Chronograph",
    nameFa: "کاسیو ادیفیس کرونوگراف",
    brand: "Casio",
    category: "sport",
    watchType: "sport",
    gender: "men",
    shortDescriptionFa: "الهام‌گرفته از دنیای موتورسواری با صفحه چندکاره.",
    descriptionFa:
      "ادیفیس با طراحی الهام‌گرفته از داشبورد موتورهای مسابقه‌ای، کرونوگراف دقیق، تقویم کامل و بدنه استیل براق را در یک مجموعه اسپرت-رسمی ترکیب کرده است.",
    sku: "CAS-EDI-CHR-BLU",
    price: 9300000,
    stock: 17,
    caseDiameterMm: "42.5",
    caseThicknessMm: "11.0",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "استیل",
    movement: "کوارتز",
    displayType: "analog",
    glassType: "کریستال معدنی سخت‌شده",
    waterResistanceAtm: 10,
    batteryLifeDays: 730,
    colorName: "آبی",
    colorHex: "#1d3557",
    images: [IMG.sport, STOCK.chrono],
    variants: [{ colorName: "آبی", colorHex: "#1d3557", strapMaterial: "استیل", priceDelta: 0, stock: 17 }],
  },

  // ---------------- LUXURY ----------------
  {
    slug: "tissot-prx-powermatic-80",
    name: "Tissot PRX Powermatic 80",
    nameFa: "تیسوت PRX پاورماتیک ۸۰",
    brand: "Tissot",
    category: "luxury",
    watchType: "luxury",
    gender: "unisex",
    shortDescriptionFa: "بند یکپارچه استیل و ذخیره انرژی ۸۰ ساعته، احیای طراحی دهه ۷۰.",
    descriptionFa:
      "PRX یکی از موفق‌ترین بازطراحی‌های دهه اخیر تیسوت است که بند یکپارچه استیل و صفحه گیوشه‌دار آن را از دهه ۱۹۷۰ وام گرفته. موتور خودکار Powermatic 80 با ذخیره انرژی ۸۰ ساعته، نیاز به کوک مکرر را از بین می‌برد.",
    sku: "TIS-PRX-P80-CHM",
    price: 46000000,
    stock: 5,
    isFeatured: true,
    caseDiameterMm: "40.0",
    caseThicknessMm: "10.4",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "استیل",
    movement: "خودکار",
    displayType: "analog",
    glassType: "کریستال یاقوتی",
    waterResistanceAtm: 10,
    colorName: "شامپاینی",
    colorHex: "#c9ad7f",
    images: [IMG.luxury, STOCK.chrono, IMG.movement],
    includedAccessories: "جعبه چرمی، دفترچه ضمانت بین‌المللی",
    variants: [{ colorName: "شامپاینی", colorHex: "#c9ad7f", strapMaterial: "استیل", priceDelta: 0, stock: 5 }],
  },
  {
    slug: "mido-commander-gold",
    name: "Mido Commander Gold",
    nameFa: "میدو کوماندر گلد",
    brand: "Mido",
    category: "luxury",
    watchType: "luxury",
    gender: "men",
    shortDescriptionFa: "روکش طلای ۱۸ عیار و صفحه گیوشه کلاسیک سوئیسی.",
    descriptionFa:
      "کوماندر گلد با بدنه روکش‌شده با طلای ۱۸ عیار، نماد میراث طراحی میدو از دهه ۱۹۵۹ است. صفحه گیوشه‌دار مرکزی و تقویم روز-تاریخ، ظاهری رسمی و لوکس به این مدل می‌بخشد.",
    sku: "MID-CMD-GLD",
    price: 58000000,
    compareAtPrice: 63000000,
    stock: 4,
    caseDiameterMm: "40.0",
    caseThicknessMm: "11.2",
    caseMaterial: "استیل با روکش طلا ۱۸ عیار",
    strapMaterial: "استیل",
    movement: "خودکار",
    displayType: "analog",
    glassType: "کریستال یاقوتی",
    waterResistanceAtm: 5,
    colorName: "طلایی",
    colorHex: "#cfa44d",
    images: [IMG.luxury, IMG.movement],
    includedAccessories: "جعبه چوبی، دفترچه ضمانت",
    variants: [{ colorName: "طلایی", colorHex: "#cfa44d", strapMaterial: "استیل", priceDelta: 0, stock: 4 }],
  },
  {
    slug: "seiko-presage-sharp-edged",
    name: "Seiko Presage Sharp Edged",
    nameFa: "سایکو پرساژ شارپ‌اج",
    brand: "Seiko",
    category: "luxury",
    watchType: "luxury",
    gender: "men",
    shortDescriptionFa: "طراحی هندسی الهام‌گرفته از معماری مدرن ژاپنی.",
    descriptionFa:
      "مجموعه شارپ‌اج با خطوط هندسی تیز و صفحه سبز سلطنتی، الهام‌گرفته از معماری مدرن ژاپن است. موتور خودکار 6R35 با ذخیره انرژی ۷۰ ساعته در این مدل به‌کار رفته است.",
    sku: "SEI-PRES-SHP-GRN",
    price: 52500000,
    stock: 3,
    caseDiameterMm: "40.2",
    caseThicknessMm: "12.0",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "چرم",
    movement: "خودکار",
    displayType: "analog",
    glassType: "کریستال یاقوتی",
    waterResistanceAtm: 10,
    colorName: "سبز",
    colorHex: "#17422f",
    images: [IMG.luxury, STOCK.stone],
    variants: [{ colorName: "سبز", colorHex: "#17422f", strapMaterial: "چرم", priceDelta: 0, stock: 3 }],
  },
  {
    slug: "citizen-series-8",
    name: "Citizen Series 8",
    nameFa: "سیتیزن سری ۸",
    brand: "Citizen",
    category: "luxury",
    watchType: "luxury",
    gender: "men",
    shortDescriptionFa: "سری پرچم‌دار مکانیکی سیتیزن با پرداخت Zaratsu.",
    descriptionFa:
      "سری ۸ پرچم‌دار جدید سیتیزن در رده مکانیکی است که با تکنیک پرداخت دستی Zaratsu، سطوح بدنه بازتاب آینه‌ای و بدون اعوجاج پیدا می‌کنند. موتور خودکار 9S65 دقتی در حد ±۳ ثانیه در روز ارائه می‌دهد.",
    sku: "CTZ-SER8-STL",
    price: 61000000,
    stock: 3,
    caseDiameterMm: "40.0",
    caseThicknessMm: "11.9",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "استیل",
    movement: "خودکار",
    displayType: "analog",
    glassType: "کریستال یاقوتی ضدانعکاس",
    waterResistanceAtm: 5,
    colorName: "نقره‌ای",
    colorHex: "#cfd2d6",
    images: [IMG.luxury, IMG.movement],
    variants: [{ colorName: "نقره‌ای", colorHex: "#cfd2d6", strapMaterial: "استیل", priceDelta: 0, stock: 3 }],
  },
  {
    slug: "horo-heritage-chronograph",
    name: "HORO Heritage Chronograph",
    nameFa: "هورو هریتیج کرونوگراف",
    brand: "HORO",
    category: "luxury",
    watchType: "luxury",
    gender: "men",
    shortDescriptionFa: "پرچم‌دار هورو؛ بدنه استیل ۳۱۶ال و موتور خودکار سوئیسی با ذخیره انرژی ۷۲ ساعته.",
    descriptionFa:
      "هریتیج کرونوگراف، محصول پرچم‌دار برند هورو و حاصل همکاری با یک کارگاه موتورسازی سوئیسی است. بدنه از استیل جراحی ۳۱۶ال با پرداخت ترکیبی براق و ساتن ساخته شده و صفحه آن با روکش شامپاینی و عقربه‌های روکش‌رودیوم، خوانایی بالایی در نور کم دارد. شیشه کریستال یاقوتی دوطرف ضدانعکاس، مقاومت در برابر خط‌وخش را تضمین می‌کند.",
    sku: "HORO-HER-CHR-CHM",
    price: 68000000,
    compareAtPrice: 74000000,
    stock: 6,
    isFeatured: true,
    isBestseller: true,
    caseDiameterMm: "41.0",
    caseThicknessMm: "12.6",
    caseMaterial: "استیل جراحی ۳۱۶ال",
    strapMaterial: "چرم ایتالیایی",
    movement: "خودکار سوئیسی",
    displayType: "analog",
    glassType: "کریستال یاقوتی دوطرف ضدانعکاس",
    waterResistanceAtm: 10,
    colorName: "شامپاینی",
    colorHex: "#cbab78",
    images: [IMG.luxury, IMG.movement, STOCK.chrono],
    includedAccessories: "جعبه چوب گردو، دفترچه ضمانت بین‌المللی، دستمال میکروفایبر",
    warrantyMonths: 24,
    variants: [
      { colorName: "شامپاینی", colorHex: "#cbab78", strapMaterial: "چرم ایتالیایی", priceDelta: 0, stock: 3 },
      { colorName: "مشکی مات", colorHex: "#1a1a1a", strapMaterial: "چرم ایتالیایی", priceDelta: 0, stock: 3 },
    ],
  },
  {
    slug: "citizen-l-collection",
    name: "Citizen L Collection",
    nameFa: "سیتیزن ال کالکشن",
    brand: "Citizen",
    category: "classic",
    watchType: "classic",
    gender: "women",
    shortDescriptionFa: "طراحی زنانه ظریف با بدنه طلایی‌رز و نگین‌های کریستال.",
    descriptionFa:
      "مجموعه ال کالکشن ویژه طراحی شده برای مچ‌های ظریف است و با نگین‌های کریستال روی صفحه، ظاهری شیک برای مناسبت‌های خاص ارائه می‌دهد. فناوری Eco-Drive نیاز به تعویض باتری را از بین می‌برد.",
    sku: "CTZ-LCOL-RSG",
    price: 13400000,
    stock: 12,
    caseDiameterMm: "28.5",
    caseThicknessMm: "8.9",
    caseMaterial: "استیل با روکش طلای رز",
    strapMaterial: "استیل",
    movement: "کوارتز سولار",
    displayType: "analog",
    glassType: "کریستال معدنی",
    waterResistanceAtm: 5,
    colorName: "طلایی‌رز",
    colorHex: "#d8b3a1",
    images: [IMG.womens, STOCK.stone],
    variants: [{ colorName: "طلایی‌رز", colorHex: "#d8b3a1", strapMaterial: "استیل", priceDelta: 0, stock: 12 }],
  },
  {
    slug: "seiko-lukia-womens",
    name: "Seiko Lukia Women's",
    nameFa: "سایکو لوکیا زنانه",
    brand: "Seiko",
    category: "classic",
    watchType: "classic",
    gender: "women",
    shortDescriptionFa: "طراحی شده برای زنان شاغل ژاپنی؛ ظریف، دقیق و روزمره.",
    descriptionFa:
      "مجموعه لوکیا با الهام از سبک زندگی زنان شاغل ژاپنی طراحی شده و تعادلی میان ظرافت ظاهری و دقت عملکردی ایجاد می‌کند. صفحه مرواریدی و بدنه استیل براق آن را برای محیط کار و مناسبت‌های رسمی مناسب کرده است.",
    sku: "SEI-LUK-W-SLV",
    price: 17200000,
    compareAtPrice: 18900000,
    stock: 9,
    caseDiameterMm: "30.5",
    caseThicknessMm: "9.1",
    caseMaterial: "استیل ضدزنگ",
    strapMaterial: "استیل",
    movement: "کوارتز",
    displayType: "analog",
    glassType: "کریستال یاقوتی",
    waterResistanceAtm: 5,
    batteryLifeDays: 730,
    colorName: "نقره‌ای صدفی",
    colorHex: "#e3e1dc",
    images: [IMG.womens, STOCK.silverArm],
    variants: [{ colorName: "نقره‌ای صدفی", colorHex: "#e3e1dc", strapMaterial: "استیل", priceDelta: 0, stock: 9 }],
  },

  // ---------------- ACCESSORIES ----------------
  {
    slug: "horo-leather-strap-milano",
    name: "HORO Leather Strap — Milano",
    nameFa: "بند چرمی هورو مدل میلان",
    brand: "HORO",
    category: "accessories",
    watchType: "accessory",
    gender: "unisex",
    shortDescriptionFa: "چرم تمام‌دباغی ایتالیایی، سازگار با اغلب قاب‌های ۲۰ و ۲۲ میلی‌متری.",
    descriptionFa:
      "بند چرمی میلان از چرم تمام‌دباغی ایتالیایی ساخته شده و با دوخت دستی، استحکام و ظاهری شیک را ترکیب می‌کند. سازگار با لاگ عرض ۲۰ و ۲۲ میلی‌متر اغلب ساعت‌های کلاسیک و لوکس هورو.",
    sku: "HORO-ACC-STRAP-ML",
    price: 1250000,
    stock: 50,
    caseMaterial: "—",
    strapMaterial: "چرم",
    movement: "—",
    displayType: "—",
    colorName: "قهوه‌ای",
    colorHex: "#5a3a24",
    images: [IMG.accessories, STOCK.stone],
    variants: [
      { colorName: "قهوه‌ای", colorHex: "#5a3a24", strapMaterial: "چرم", priceDelta: 0, stock: 25 },
      { colorName: "مشکی", colorHex: "#1c1c1c", strapMaterial: "چرم", priceDelta: 0, stock: 25 },
    ],
  },
  {
    slug: "horo-steel-bracelet",
    name: "HORO Steel Bracelet",
    nameFa: "بند استیل هورو",
    brand: "HORO",
    category: "accessories",
    watchType: "accessory",
    gender: "unisex",
    shortDescriptionFa: "بند میلان‌لوپ استیل ضدزنگ با قابلیت تنظیم آسان طول.",
    descriptionFa:
      "بند میلان‌لوپ استیل ضدزنگ هورو با بافت ظریف و بسته مغناطیسی، تنظیم طول را بدون نیاز به ابزار ممکن می‌کند. گزینه‌ای شیک برای تعویض بند ساعت‌های کلاسیک و هوشمند.",
    sku: "HORO-ACC-STRAP-ST",
    price: 2450000,
    stock: 35,
    caseMaterial: "—",
    strapMaterial: "استیل",
    movement: "—",
    displayType: "—",
    colorName: "نقره‌ای",
    colorHex: "#c3c5c8",
    images: [IMG.accessories],
    variants: [{ colorName: "نقره‌ای", colorHex: "#c3c5c8", strapMaterial: "استیل", priceDelta: 0, stock: 35 }],
  },
  {
    slug: "horo-watch-winder-box",
    name: "HORO Watch Winder Box",
    nameFa: "جعبه نگهداری و شارژ هورو",
    brand: "HORO",
    category: "accessories",
    watchType: "accessory",
    gender: "unisex",
    shortDescriptionFa: "جعبه چرخان برای نگهداری و تامین انرژی ساعت‌های خودکار.",
    descriptionFa:
      "جعبه نگهداری هورو با موتور بی‌صدا، حرکت طبیعی مچ را برای ساعت‌های خودکار شبیه‌سازی می‌کند تا همیشه آماده استفاده باشند. داخل آن با مخمل نرم پوشانده شده تا از بدنه و بند ساعت محافظت کند.",
    sku: "HORO-ACC-WINDER",
    price: 3800000,
    stock: 15,
    isNewArrival: true,
    caseMaterial: "—",
    strapMaterial: "—",
    movement: "—",
    displayType: "—",
    colorName: "قهوه‌ای تیره",
    colorHex: "#2b1d14",
    images: [IMG.accessories, IMG.gifts],
    variants: [{ colorName: "قهوه‌ای تیره", colorHex: "#2b1d14", strapMaterial: "—", priceDelta: 0, stock: 15 }],
  },
  {
    slug: "horo-cleaning-tool-kit",
    name: "HORO Cleaning & Tool Kit",
    nameFa: "کیت تمیزکننده و ابزار تعویض بند هورو",
    brand: "HORO",
    category: "accessories",
    watchType: "accessory",
    gender: "unisex",
    shortDescriptionFa: "ابزار کامل تعویض بند به همراه دستمال میکروفایبر و برس نرم.",
    descriptionFa:
      "این کیت شامل ابزار باز کردن پین بند، برس نرم برای تمیزکاری شیار‌های بدنه و دستمال میکروفایبر برای براق‌کاری شیشه و بدنه است؛ مجموعه‌ای ضروری برای نگهداری روزمره از ساعت.",
    sku: "HORO-ACC-KIT",
    price: 650000,
    stock: 60,
    caseMaterial: "—",
    strapMaterial: "—",
    movement: "—",
    displayType: "—",
    colorName: "خاکستری",
    colorHex: "#7a7a7a",
    images: [IMG.accessories],
    variants: [{ colorName: "خاکستری", colorHex: "#7a7a7a", strapMaterial: "—", priceDelta: 0, stock: 60 }],
  },
];

const brandSeed = [
  { slug: "apple", name: "Apple", nameFa: "اپل", country: "آمریکا", sortOrder: 1 },
  { slug: "samsung", name: "Samsung", nameFa: "سامسونگ", country: "کره جنوبی", sortOrder: 2 },
  { slug: "garmin", name: "Garmin", nameFa: "گارمین", country: "سوئیس", sortOrder: 3 },
  { slug: "casio", name: "Casio", nameFa: "کاسیو", country: "ژاپن", sortOrder: 4 },
  { slug: "seiko", name: "Seiko", nameFa: "سایکو", country: "ژاپن", sortOrder: 5 },
  { slug: "tissot", name: "Tissot", nameFa: "تیسوت", country: "سوئیس", sortOrder: 6 },
  { slug: "citizen", name: "Citizen", nameFa: "سیتیزن", country: "ژاپن", sortOrder: 7 },
  { slug: "fossil", name: "Fossil", nameFa: "فسیل", country: "آمریکا", sortOrder: 8 },
  { slug: "mido", name: "Mido", nameFa: "میدو", country: "سوئیس", sortOrder: 9 },
  { slug: "orient", name: "Orient", nameFa: "اورینت", country: "ژاپن", sortOrder: 10 },
  { slug: "horo", name: "HORO", nameFa: "هورو", country: "ایران", sortOrder: 0 },
];

const categorySeed = [
  { slug: "smartwatches", name: "Smartwatches", nameFa: "ساعت‌های هوشمند", descriptionFa: "جدیدترین ساعت‌های هوشمند با قابلیت پایش سلامت و اعلان‌های آنی.", icon: "smartwatch", heroImage: IMG.smartwatch, sortOrder: 1 },
  { slug: "classic", name: "Classic Watches", nameFa: "ساعت‌های کلاسیک", descriptionFa: "طراحی بی‌زمان برای استفاده روزمره و مناسبت‌های رسمی.", icon: "classic", heroImage: IMG.classic, sortOrder: 2 },
  { slug: "sport", name: "Sport Watches", nameFa: "ساعت‌های اسپرت", descriptionFa: "مقاوم، دقیق و آماده برای فعالیت‌های پرتحرک.", icon: "sport", heroImage: IMG.sport, sortOrder: 3 },
  { slug: "luxury", name: "Luxury Watches", nameFa: "ساعت‌های لوکس", descriptionFa: "موتورهای مکانیکی و متریال‌های ممتاز برای اهل مجموعه‌داری.", icon: "luxury", heroImage: IMG.luxury, sortOrder: 4 },
  { slug: "accessories", name: "Accessories", nameFa: "لوازم جانبی ساعت", descriptionFa: "بند، جعبه نگهداری و ابزار مراقبت از ساعت.", icon: "accessories", heroImage: IMG.accessories, sortOrder: 5 },
];

const discountSeed = [
  { code: "HORO10", percentOff: 10, amountOff: null, minSubtotal: 5000000, active: true },
  { code: "WELCOME500", percentOff: null, amountOff: 500000, minSubtotal: 3000000, active: true },
];

const reviewAuthors = [
  "امیر رضایی", "سارا احمدی", "محمد حسینی", "نگار کریمی", "علی موسوی", "مریم صادقی",
  "حسین نجفی", "فاطمه رحیمی", "بهنام شریفی", "الهام قاسمی", "رضا یوسفی", "زهرا کاظمی",
];

const reviewTemplates: { rating: number; title: string; body: string }[] = [
  { rating: 5, title: "کیفیت ساخت عالی", body: "بسته‌بندی و کیفیت ساخت فوق‌العاده بود، دقیقاً مطابق عکس‌ها و توضیحات سایت. ارسال هم سریع انجام شد." },
  { rating: 4, title: "راضی‌کننده با چند نکته", body: "ساعت زیبا و با کیفیتی است، فقط بند کمی سفت بود که با یک بار تنظیم در تعمیرگاه مرتفع شد." },
  { rating: 5, title: "ارزش خرید بالا", body: "با توجه به قیمت، کیفیت ساخت و دقت زمان‌سنجی فوق‌العاده است. پشتیبانی هورو هم پاسخگو بود." },
  { rating: 3, title: "خوب اما نه عالی", body: "ساعت خوبی است ولی انتظار صفحه روشن‌تری داشتم. در مجموع از خرید راضی‌ام." },
  { rating: 5, title: "دقیقاً همونی که میخواستم", body: "برای هدیه خریدم و همسرم خیلی خوشش اومد. جعبه و بسته‌بندی هم شیک بود." },
  { rating: 4, title: "تحویل سریع", body: "دو روزه دستم رسید. کیفیت بند چرم عالی است و رنگ صفحه در نور طبیعی بسیار زیباست." },
];

function pick<T>(arr: T[], seed: number): T {
  return arr[seed % arr.length];
}

async function main() {
  console.log("Seeding HORO catalog…");

  await db.delete(discountCodes);
  await db.delete(reviews);
  await db.delete(productVariants);
  await db.delete(products);
  await db.delete(categories);
  await db.delete(brands);
  await db.execute(sql`ALTER SEQUENCE brands_id_seq RESTART WITH 1`);
  await db.execute(sql`ALTER SEQUENCE categories_id_seq RESTART WITH 1`);
  await db.execute(sql`ALTER SEQUENCE products_id_seq RESTART WITH 1`);
  await db.execute(sql`ALTER SEQUENCE product_variants_id_seq RESTART WITH 1`);
  await db.execute(sql`ALTER SEQUENCE reviews_id_seq RESTART WITH 1`);

  const insertedBrands = await db.insert(brands).values(brandSeed).returning();
  const brandMap = new Map(insertedBrands.map((b) => [b.name, b.id]));

  const insertedCategories = await db.insert(categories).values(categorySeed).returning();
  const categoryMap = new Map(insertedCategories.map((c) => [c.slug, c.id]));

  let seedCounter = 0;
  for (const p of seedProducts) {
    const [product] = await db
      .insert(products)
      .values({
        slug: p.slug,
        name: p.name,
        nameFa: p.nameFa,
        brandId: brandMap.get(p.brand)!,
        categoryId: categoryMap.get(p.category)!,
        watchType: p.watchType,
        gender: p.gender,
        shortDescriptionFa: p.shortDescriptionFa,
        descriptionFa: p.descriptionFa,
        sku: p.sku,
        price: p.price,
        compareAtPrice: p.compareAtPrice,
        stock: p.stock,
        isFeatured: p.isFeatured ?? false,
        isBestseller: p.isBestseller ?? false,
        isNewArrival: p.isNewArrival ?? false,
        caseDiameterMm: p.caseDiameterMm,
        caseThicknessMm: p.caseThicknessMm,
        caseMaterial: p.caseMaterial,
        strapMaterial: p.strapMaterial,
        movement: p.movement,
        displayType: p.displayType,
        glassType: p.glassType,
        waterResistanceAtm: p.waterResistanceAtm,
        batteryLifeDays: p.batteryLifeDays,
        connectivity: p.connectivity,
        colorName: p.colorName,
        colorHex: p.colorHex,
        images: p.images,
        includedAccessories: p.includedAccessories,
        warrantyMonths: p.warrantyMonths ?? 12,
      })
      .returning();

    if (p.variants?.length) {
      await db.insert(productVariants).values(
        p.variants.map((v, idx) => ({
          productId: product.id,
          colorName: v.colorName,
          colorHex: v.colorHex,
          strapMaterial: v.strapMaterial,
          sku: `${p.sku}-V${idx + 1}`,
          priceDelta: v.priceDelta,
          stock: v.stock,
          image: v.image ?? p.images[0],
        })),
      );
    }

    // Seed 3-6 reviews per product with real average rating computed afterwards.
    const reviewCount = 3 + (seedCounter % 4);
    const reviewRows = Array.from({ length: reviewCount }).map((_, i) => {
      const template = pick(reviewTemplates, seedCounter + i);
      return {
        productId: product.id,
        authorName: pick(reviewAuthors, seedCounter * 3 + i),
        rating: template.rating,
        title: template.title,
        body: template.body,
        verifiedPurchase: i % 3 !== 0,
        createdAt: new Date(Date.now() - (i + 1) * 1000 * 60 * 60 * 24 * (3 + i)),
      };
    });
    await db.insert(reviews).values(reviewRows);
    const avg = reviewRows.reduce((s, r) => s + r.rating, 0) / reviewRows.length;
    await db
      .update(products)
      .set({ ratingAvg: avg.toFixed(1), ratingCount: reviewRows.length })
      .where(sql`${products.id} = ${product.id}`);

    seedCounter += 1;
  }

  await db.insert(discountCodes).values(discountSeed);

  console.log(`Seeded ${insertedBrands.length} brands, ${insertedCategories.length} categories, ${seedProducts.length} products.`);
}

main()
  .then(async () => {
    await pool.end();
    process.exit(0);
  })
  .catch(async (err) => {
    console.error(err);
    await pool.end();
    process.exit(1);
  });
