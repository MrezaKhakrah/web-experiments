import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { getProductBySlug, getRelatedProducts } from "@/db/queries";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Gallery } from "@/components/product/Gallery";
import { Rating } from "@/components/ui/Rating";
import { Price } from "@/components/ui/Price";
import { PurchasePanel } from "@/components/product/PurchasePanel";
import { SpecsTable } from "@/components/product/SpecsTable";
import { ReviewsList } from "@/components/product/ReviewsList";
import { ProductCarousel } from "@/components/product/ProductCarousel";
import { TrackRecentlyViewed, RecentlyViewedSection } from "@/components/product/RecentlyViewed";
import { toPersianDigits } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "محصول یافت نشد" };
  return {
    title: `${product.nameFa} | ${product.brandNameFa}`,
    description: product.shortDescriptionFa,
    alternates: { canonical: `/products/${product.slug}` },
    openGraph: {
      title: product.nameFa,
      description: product.shortDescriptionFa,
      images: product.images[0] ? [{ url: product.images[0] }] : undefined,
    },
  };
}

export default async function ProductDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const related = await getRelatedProducts(product.full!.categoryId, product.id, 8);

  const ratingAvg = Number(product.ratingAvg);
  const caseDiameter = product.caseDiameterMm ? Number(product.caseDiameterMm) : null;
  const caseThickness = product.full!.caseThicknessMm ? Number(product.full!.caseThicknessMm) : null;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.nameFa,
    image: product.images,
    description: product.shortDescriptionFa,
    sku: product.full!.sku,
    brand: { "@type": "Brand", name: product.brandName },
    offers: {
      "@type": "Offer",
      priceCurrency: "IRR",
      price: product.price * 10,
      availability: product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      url: `https://horo.example.com/products/${product.slug}`,
    },
    ...(product.ratingCount > 0
      ? {
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: ratingAvg,
            reviewCount: product.ratingCount,
          },
        }
      : {}),
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      {/* eslint-disable-next-line @next/next/no-script-component-in-head */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <TrackRecentlyViewed productId={product.id} />

      <Breadcrumbs
        items={[
          { label: "خانه", href: "/" },
          { label: "محصولات", href: "/products" },
          { label: product.categoryNameFa, href: `/products?category=${product.categorySlug}` },
          { label: product.nameFa },
        ]}
      />

      <div className="mt-6 grid grid-cols-1 gap-10 pb-16 lg:grid-cols-2 lg:gap-14">
        <Gallery images={product.images} name={product.nameFa} />

        <div>
          <Link href={`/products?brand=${product.brandSlug}`} className="text-sm font-medium text-champagne-dark hover:underline">
            {product.brandNameFa}
          </Link>
          <h1 className="mt-1.5 text-2xl font-bold text-ink sm:text-3xl">{product.nameFa}</h1>
          <p className="mt-1 text-xs text-muted">کد محصول: {toPersianDigits(product.full!.sku)}</p>

          <div className="mt-3">
            <Rating value={ratingAvg} count={product.ratingCount} />
          </div>

          <div className="mt-4">
            <Price price={product.price} compareAtPrice={product.compareAtPrice} size="lg" />
          </div>

          <p className="mt-4 text-sm leading-7 text-muted">{product.shortDescriptionFa}</p>

          {(caseDiameter || product.movement) && (
            <div className="mt-5 grid grid-cols-2 gap-3 rounded-md border border-border bg-surface/40 p-4 sm:grid-cols-4">
              {caseDiameter && (
                <div>
                  <p className="text-[11px] text-muted">قطر بدنه</p>
                  <p className="text-sm font-semibold text-ink">{toPersianDigits(caseDiameter)} میلی‌متر</p>
                </div>
              )}
              {product.movement && product.movement !== "—" && (
                <div>
                  <p className="text-[11px] text-muted">موتور</p>
                  <p className="text-sm font-semibold text-ink">{product.movement}</p>
                </div>
              )}
              {product.waterResistanceAtm && (
                <div>
                  <p className="text-[11px] text-muted">مقاومت آب</p>
                  <p className="text-sm font-semibold text-ink">{toPersianDigits(product.waterResistanceAtm)} اتمسفر</p>
                </div>
              )}
              {product.full!.warrantyMonths && (
                <div>
                  <p className="text-[11px] text-muted">ضمانت</p>
                  <p className="text-sm font-semibold text-ink">{toPersianDigits(product.full!.warrantyMonths)} ماه</p>
                </div>
              )}
            </div>
          )}

          <div className="mt-6">
            <PurchasePanel
              productId={product.id}
              slug={product.slug}
              nameFa={product.nameFa}
              brandNameFa={product.brandNameFa}
              basePrice={product.price}
              compareAtPrice={product.compareAtPrice}
              baseStock={product.stock}
              baseImage={product.images[0]}
              warrantyMonths={product.full!.warrantyMonths}
              variants={product.variants.map((v) => ({
                id: v.id,
                colorName: v.colorName,
                colorHex: v.colorHex,
                strapMaterial: v.strapMaterial,
                sku: v.sku,
                priceDelta: v.priceDelta,
                stock: v.stock,
                image: v.image,
              }))}
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-10 border-t border-border py-12 lg:grid-cols-2">
        <div>
          <h2 className="mb-4 text-lg font-bold text-ink">توضیحات محصول</h2>
          <p className="text-sm leading-8 text-muted">{product.full!.descriptionFa}</p>
          {product.full!.includedAccessories && (
            <div className="mt-5">
              <h3 className="mb-2 text-sm font-semibold text-ink">لوازم همراه</h3>
              <p className="text-sm text-muted">{product.full!.includedAccessories}</p>
            </div>
          )}
        </div>
        <div>
          <h2 className="mb-4 text-lg font-bold text-ink">مشخصات فنی</h2>
          <SpecsTable
            rows={[
              { label: "برند", value: product.brandNameFa },
              { label: "قطر بدنه", value: caseDiameter ? `${toPersianDigits(caseDiameter)} میلی‌متر` : null },
              { label: "ضخامت بدنه", value: caseThickness ? `${toPersianDigits(caseThickness)} میلی‌متر` : null },
              { label: "جنس بدنه", value: product.caseMaterial },
              { label: "جنس بند", value: product.strapMaterial },
              { label: "موتور حرکتی", value: product.movement },
              { label: "نوع صفحه‌نمایش", value: product.displayType },
              { label: "جنس شیشه", value: product.full!.glassType },
              { label: "مقاومت آب", value: product.waterResistanceAtm ? `${toPersianDigits(product.waterResistanceAtm)} اتمسفر` : null },
              { label: "عمر باتری", value: product.full!.batteryLifeDays ? `${toPersianDigits(product.full!.batteryLifeDays)} روز` : null },
              { label: "اتصال‌پذیری", value: product.connectivity },
              { label: "رنگ", value: product.colorName },
              { label: "ضمانت", value: `${toPersianDigits(product.full!.warrantyMonths)} ماه` },
            ]}
          />
        </div>
      </div>

      <div className="border-t border-border py-12">
        <h2 className="mb-6 text-lg font-bold text-ink">نظرات مشتریان</h2>
        <ReviewsList reviews={product.reviews} ratingAvg={ratingAvg} ratingCount={product.ratingCount} />
      </div>

      {related.length > 0 && (
        <div className="border-t border-border py-12">
          <h2 className="mb-6 text-lg font-bold text-ink">محصولات مرتبط</h2>
          <ProductCarousel products={related} />
        </div>
      )}
    </div>
  );
}
