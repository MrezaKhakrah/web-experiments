import Link from "next/link";
import type { Metadata } from "next";
import { getProducts, getFilterFacets, getAllBrands, getAllCategories } from "@/db/queries";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { EmptyState } from "@/components/ui/EmptyState";
import { ProductCard } from "@/components/product/ProductCard";
import { FiltersSidebar } from "@/components/listing/FiltersSidebar";
import { FilterDrawerMobile } from "@/components/listing/FilterDrawerMobile";
import { SortDropdown } from "@/components/listing/SortDropdown";
import { ActiveFilterChips } from "@/components/listing/ActiveFilterChips";
import { Pagination } from "@/components/listing/Pagination";
import { ResultSearchBox } from "@/components/listing/ResultSearchBox";
import { formatNumber } from "@/lib/format";
import { PackageSearch } from "lucide-react";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "فروشگاه ساعت | HORO",
  description: "مشاهده و فیلتر کامل مجموعه ساعت‌های هوشمند، کلاسیک، اسپرت و لوکس هورو.",
};

function parseList(value?: string) {
  return value ? value.split(",").filter(Boolean) : undefined;
}

type SearchParams = Record<string, string | string[] | undefined>;

function one(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value;
}

export default async function ProductsPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const sp = await searchParams;
  const category = one(sp.category);
  const brand = parseList(one(sp.brand));
  const gender = parseList(one(sp.gender));
  const caseMaterial = parseList(one(sp.caseMaterial));
  const strapMaterial = parseList(one(sp.strapMaterial));
  const movement = parseList(one(sp.movement));
  const displayType = parseList(one(sp.displayType));
  const connectivity = parseList(one(sp.connectivity));
  const waterResistance = parseList(one(sp.waterResistance))?.map(Number);
  const color = parseList(one(sp.color));
  const priceMin = one(sp.priceMin) ? Number(one(sp.priceMin)) : undefined;
  const priceMax = one(sp.priceMax) ? Number(one(sp.priceMax)) : undefined;
  const inStockOnly = one(sp.inStock) === "1";
  const search = one(sp.q)?.trim() || undefined;
  const sort = (one(sp.sort) as "price-asc" | "price-desc" | "popularity" | "newest" | undefined) ?? "relevance";
  const page = one(sp.page) ? Number(one(sp.page)) : 1;

  const [result, facets, brands, categories] = await Promise.all([
    getProducts({
      category,
      brand,
      gender,
      caseMaterial,
      strapMaterial,
      movement,
      displayType,
      connectivity,
      waterResistance,
      color,
      priceMin,
      priceMax,
      inStockOnly,
      search,
      sort,
      page,
      pageSize: 12,
    }),
    getFilterFacets(),
    getAllBrands(),
    getAllCategories(),
  ]);

  const activeCategoryMeta = categories.find((c) => c.slug === category);
  const title = search
    ? `نتایج جستجو برای «${search}»`
    : activeCategoryMeta
      ? activeCategoryMeta.nameFa
      : "همه محصولات";
  const intro = activeCategoryMeta?.descriptionFa ?? "مجموعه کامل ساعت‌های هورو را با فیلترهای دقیق کاوش کنید.";

  function buildHref(targetPage: number) {
    const params = new URLSearchParams();
    Object.entries(sp).forEach(([key, value]) => {
      if (key === "page" || !value) return;
      params.set(key, Array.isArray(value) ? value[0] : value);
    });
    if (targetPage > 1) params.set("page", String(targetPage));
    const qs = params.toString();
    return qs ? `/products?${qs}` : "/products";
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <Breadcrumbs
        items={[{ label: "خانه", href: "/" }, { label: "محصولات", href: "/products" }, ...(activeCategoryMeta ? [{ label: activeCategoryMeta.nameFa }] : [])]}
      />

      <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-ink sm:text-3xl">{title}</h1>
          <p className="mt-1.5 max-w-2xl text-sm text-muted">{intro}</p>
        </div>
        <p className="text-sm text-muted">{formatNumber(result.total)} محصول</p>
      </div>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <ResultSearchBox defaultValue={search} />
        <div className="flex items-center gap-2">
          <FilterDrawerMobile facets={facets} brands={brands} activeCategory={category} />
          <SortDropdown current={sort} />
        </div>
      </div>

      <ActiveFilterChips />

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[240px_1fr]">
        <aside className="hidden lg:block">
          <div className="sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto rounded-md border border-border bg-paper p-5">
            <FiltersSidebar facets={facets} brands={brands} activeCategory={category} />
          </div>
        </aside>

        <div>
          {result.items.length === 0 ? (
            <EmptyState
              icon={<PackageSearch size={40} />}
              title="محصولی با این فیلترها یافت نشد"
              description="فیلترهای کمتری انتخاب کنید یا محدوده قیمت را گسترده‌تر کنید. می‌توانید دسته‌بندی‌های دیگر را نیز بررسی کنید."
              action={
                <Link href="/products" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-paper hover:bg-charcoal">
                  پاک‌کردن همه فیلترها
                </Link>
              }
            />
          ) : (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
              {result.items.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}

          <Pagination page={result.page} totalPages={result.totalPages} buildHref={buildHref} />
        </div>
      </div>
    </div>
  );
}
