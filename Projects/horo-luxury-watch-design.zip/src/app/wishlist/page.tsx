"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Heart } from "lucide-react";
import { useWishlistStore } from "@/lib/wishlist-store";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { EmptyState } from "@/components/ui/EmptyState";
import { ProductCard } from "@/components/product/ProductCard";
import { ProductCardSkeleton } from "@/components/ui/Skeleton";
import type { ProductListItem } from "@/db/queries";

export default function WishlistPage() {
  const productIds = useWishlistStore((s) => s.productIds);
  const [products, setProducts] = useState<ProductListItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (productIds.length === 0) {
      setProducts([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    fetch(`/api/products?ids=${productIds.join(",")}`)
      .then((res) => res.json())
      .then((data) => setProducts(data.items ?? []))
      .finally(() => setLoading(false));
  }, [productIds]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "علاقه‌مندی‌ها" }]} />
      <h1 className="mt-4 text-2xl font-bold text-ink sm:text-3xl">علاقه‌مندی‌های من</h1>

      {loading ? (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <ProductCardSkeleton key={i} />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="mt-8">
          <EmptyState
            icon={<Heart size={40} />}
            title="لیست علاقه‌مندی‌های شما خالی است"
            description="محصولات مورد علاقه خود را با زدن آیکن قلب ذخیره کنید تا بعداً به آن‌ها دسترسی داشته باشید."
            action={
              <Link href="/products" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-paper hover:bg-charcoal">
                مشاهده محصولات
              </Link>
            }
          />
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
