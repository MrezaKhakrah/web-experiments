"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { X, Scale } from "lucide-react";
import { useCompareStore } from "@/lib/compare-store";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { EmptyState } from "@/components/ui/EmptyState";
import { Price } from "@/components/ui/Price";
import { Rating } from "@/components/ui/Rating";
import { toPersianDigits } from "@/lib/format";
import type { ProductListItem } from "@/db/queries";

const specRows: { label: string; render: (p: ProductListItem) => string | number | null }[] = [
  { label: "برند", render: (p) => p.brandNameFa },
  { label: "قیمت", render: (p) => null },
  { label: "قطر بدنه", render: (p) => (p.caseDiameterMm ? `${toPersianDigits(Number(p.caseDiameterMm))} میلی‌متر` : "—") },
  { label: "جنس بدنه", render: (p) => p.caseMaterial },
  { label: "جنس بند", render: (p) => p.strapMaterial },
  { label: "موتور حرکتی", render: (p) => p.movement },
  { label: "نوع صفحه‌نمایش", render: (p) => p.displayType },
  { label: "اتصال‌پذیری", render: (p) => p.connectivity || "—" },
  { label: "مقاومت آب", render: (p) => (p.waterResistanceAtm ? `${toPersianDigits(p.waterResistanceAtm)} اتمسفر` : "—") },
  { label: "رنگ", render: (p) => p.colorName },
  { label: "وضعیت موجودی", render: (p) => (p.stock > 0 ? "موجود" : "ناموجود") },
];

export default function ComparePage() {
  const productIds = useCompareStore((s) => s.productIds);
  const remove = useCompareStore((s) => s.remove);
  const [products, setProducts] = useState<ProductListItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (productIds.length === 0) {
      setProducts([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    fetch(`/api/products?ids=${productIds.join(",")}`)
      .then((res) => res.json())
      .then((data) => setProducts(data.items ?? []))
      .finally(() => setLoading(false));
  }, [productIds]);

  const sameCategory = products.length > 0 && products.every((p) => p.categorySlug === products[0].categorySlug);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "مقایسه محصولات" }]} />
      <h1 className="mt-4 text-2xl font-bold text-ink sm:text-3xl">مقایسه محصولات</h1>
      <p className="mt-1.5 text-sm text-muted">حداکثر ۴ محصول را به‌صورت هم‌زمان مقایسه کنید.</p>

      {loading ? null : products.length === 0 ? (
        <div className="mt-8">
          <EmptyState
            icon={<Scale size={40} />}
            title="هنوز محصولی برای مقایسه انتخاب نکرده‌اید"
            description="از صفحه محصولات یا فروشگاه، آیکن مقایسه را روی کارت هر محصول بزنید."
            action={
              <Link href="/products" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-paper hover:bg-charcoal">
                مشاهده محصولات
              </Link>
            }
          />
        </div>
      ) : (
        <div className="mt-8 overflow-x-auto">
          {!sameCategory && (
            <p className="mb-4 rounded-sm bg-surface px-4 py-3 text-xs text-muted">
              توجه: محصولات انتخاب‌شده از دسته‌بندی‌های متفاوتی هستند؛ برخی ویژگی‌ها ممکن است برای تمام آن‌ها معنادار نباشد.
            </p>
          )}
          <table className="w-full min-w-[640px] border-separate border-spacing-0">
            <thead>
              <tr>
                <th className="w-36"></th>
                {products.map((p) => (
                  <th key={p.id} className="border-b border-border px-3 pb-4 text-start align-bottom">
                    <div className="relative">
                      <button
                        type="button"
                        onClick={() => remove(p.id)}
                        aria-label="حذف از مقایسه"
                        className="absolute -top-2 end-0 rounded-full bg-paper p-1 text-muted shadow-sm hover:text-ink"
                      >
                        <X size={14} />
                      </button>
                      <Link href={`/products/${p.slug}`} className="block">
                        <span className="relative block aspect-square w-24 overflow-hidden rounded-sm bg-surface">
                          <Image src={p.images[0]} alt={p.nameFa} fill sizes="96px" className="object-cover" />
                        </span>
                        <span className="mt-2 block text-sm font-medium text-ink">{p.nameFa}</span>
                      </Link>
                      <div className="mt-1.5">
                        <Rating value={Number(p.ratingAvg)} count={p.ratingCount} size={12} />
                      </div>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {specRows.map((row) => (
                <tr key={row.label}>
                  <th className="border-b border-border bg-surface/40 px-3 py-3 text-start text-xs font-medium text-muted">
                    {row.label}
                  </th>
                  {products.map((p) => (
                    <td key={p.id} className="border-b border-border px-3 py-3 text-sm text-ink">
                      {row.label === "قیمت" ? <Price price={p.price} compareAtPrice={p.compareAtPrice} size="sm" /> : row.render(p)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
