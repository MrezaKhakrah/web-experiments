"use server";

import bcrypt from "bcryptjs";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createSession, destroySession } from "@/lib/auth";

export type AuthState = { status: "idle" | "error"; message: string };

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function registerAction(_prev: AuthState, formData: FormData): Promise<AuthState> {
  const fullName = String(formData.get("fullName") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const phone = String(formData.get("phone") ?? "").trim();
  const password = String(formData.get("password") ?? "");

  if (fullName.length < 2) return { status: "error", message: "نام و نام‌خانوادگی را کامل وارد کنید." };
  if (!emailRegex.test(email)) return { status: "error", message: "ایمیل وارد‌شده معتبر نیست." };
  if (password.length < 6) return { status: "error", message: "رمز عبور باید حداقل ۶ کاراکتر باشد." };

  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing.length > 0) {
    return { status: "error", message: "حسابی با این ایمیل قبلاً ثبت شده است." };
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const [user] = await db.insert(users).values({ email, passwordHash, fullName, phone }).returning();

  await createSession(user.id);
  redirect("/account");
}

export async function loginAction(_prev: AuthState, formData: FormData): Promise<AuthState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");

  const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
  const user = rows[0];
  if (!user) return { status: "error", message: "ایمیل یا رمز عبور اشتباه است." };

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) return { status: "error", message: "ایمیل یا رمز عبور اشتباه است." };

  await createSession(user.id);
  redirect("/account");
}

export async function logoutAction() {
  await destroySession();
  redirect("/");
}
