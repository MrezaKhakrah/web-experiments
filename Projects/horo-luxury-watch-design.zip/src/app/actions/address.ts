"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { addresses } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export type AddressState = { status: "idle" | "error" | "success"; message: string };

export async function addAddressAction(_prev: AddressState, formData: FormData): Promise<AddressState> {
  const user = await getCurrentUser();
  if (!user) return { status: "error", message: "ابتدا وارد حساب کاربری خود شوید." };

  const fullName = String(formData.get("fullName") ?? "").trim();
  const phone = String(formData.get("phone") ?? "").trim();
  const province = String(formData.get("province") ?? "").trim();
  const city = String(formData.get("city") ?? "").trim();
  const addressLine = String(formData.get("addressLine") ?? "").trim();
  const postalCode = String(formData.get("postalCode") ?? "").trim();

  if (!fullName || !phone || !province || !city || !addressLine || postalCode.length < 10) {
    return { status: "error", message: "لطفاً همه فیلدهای آدرس را به‌درستی تکمیل کنید." };
  }

  const existing = await db.select().from(addresses).where(eq(addresses.userId, user.id));

  await db.insert(addresses).values({
    userId: user.id,
    fullName,
    phone,
    province,
    city,
    addressLine,
    postalCode,
    isDefault: existing.length === 0,
  });

  revalidatePath("/account");
  revalidatePath("/checkout");
  return { status: "success", message: "آدرس جدید با موفقیت ذخیره شد." };
}
