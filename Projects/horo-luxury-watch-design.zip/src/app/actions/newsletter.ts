"use server";

import { db } from "@/db";
import { newsletterSubscribers } from "@/db/schema";
import { sql } from "drizzle-orm";

export type NewsletterState = { status: "idle" | "success" | "error"; message: string };

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function subscribeAction(_prev: NewsletterState, formData: FormData): Promise<NewsletterState> {
  const email = String(formData.get("email") ?? "").trim();
  const consent = formData.get("consent");

  if (!emailRegex.test(email)) {
    return { status: "error", message: "لطفاً یک ایمیل معتبر وارد کنید." };
  }
  if (!consent) {
    return { status: "error", message: "برای عضویت باید با دریافت ایمیل موافقت کنید." };
  }

  try {
    await db
      .insert(newsletterSubscribers)
      .values({ email })
      .onConflictDoUpdate({ target: newsletterSubscribers.email, set: { email: sql`excluded.email` } });
    return { status: "success", message: "عضویت شما با موفقیت ثبت شد." };
  } catch {
    return { status: "error", message: "خطایی رخ داد. لطفاً دوباره تلاش کنید." };
  }
}
