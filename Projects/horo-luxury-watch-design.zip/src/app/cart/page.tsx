"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Minus, Plus, Trash2, ShoppingBag, Tag, Loader2 } from "lucide-react";
import { useCartStore, cartSubtotal } from "@/lib/cart-store";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { EmptyState } from "@/components/ui/EmptyState";
import { formatCurrency, toPersianDigits } from "@/lib/format";
import { calcShippingCost, FREE_SHIPPING_THRESHOLD } from "@/lib/commerce";

export default function CartPage() {
  const items = useCartStore((s) => s.items);
  const setQuantity = useCartStore((s) => s.setQuantity);
  const removeItem = useCartStore((s) => s.removeItem);
  const discountCode = useCartStore((s) => s.discountCode);
  const discountAmount = useCartStore((s) => s.discountAmount);
  const applyDiscount = useCartStore((s) => s.applyDiscount);
  const clearDiscount = useCartStore((s) => s.clearDiscount);

  const [codeInput, setCodeInput] = useState("");
  const [applying, setApplying] = useState(false);
  const [codeMessage, setCodeMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const subtotal = cartSubtotal(items);
  const shipping = calcShippingCost(subtotal);
  const total = Math.max(0, subtotal + shipping - discountAmount);

  async function handleApplyCode(e: React.FormEvent) {
    e.preventDefault();
    if (!codeInput.trim()) return;
    setApplying(true);
    setCodeMessage(null);
    try {
      const res = await fetch("/api/discount", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: codeInput.trim(), subtotal }),
      });
      const data = await res.json();
      if (data.valid) {
        applyDiscount(data.code, data.amount);
        setCodeMessage({ type: "success", text: data.message });
      } else {
        setCodeMessage({ type: "error", text: data.message });
      }
    } catch {
      setCodeMessage({ type: "error", text: "خطا در بررسی کد تخفیف." });
    } finally {
      setApplying(false);
    }
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "سبد خرید" }]} />
        <div className="mt-8">
          <EmptyState
            icon={<ShoppingBag size={40} />}
            title="سبد خرید شما خالی است"
            description="هنوز محصولی به سبد خرید اضافه نکرده‌اید. مجموعه ساعت‌های هورو را مشاهده کنید."
            action={
              <Link href="/products" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-paper hover:bg-charcoal">
                مشاهده محصولات
              </Link>
            }
          />
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "سبد خرید" }]} />
      <h1 className="mt-4 text-2xl font-bold text-ink sm:text-3xl">سبد خرید</h1>

      <div className="mt-8 grid grid-cols-1 gap-10 lg:grid-cols-[1fr_360px]">
        <div className="flex flex-col divide-y divide-border rounded-md border border-border">
          {items.map((item) => (
            <div key={`${item.productId}-${item.variantSku}`} className="flex gap-4 p-4">
              <Link href={`/products/${item.slug}`} className="relative h-24 w-24 shrink-0 overflow-hidden rounded-sm bg-surface">
                <Image src={item.image} alt={item.nameFa} fill sizes="96px" className="object-cover" />
              </Link>
              <div className="flex flex-1 flex-col justify-between">
                <div>
                  <p className="text-xs text-muted">{item.brandNameFa}</p>
                  <Link href={`/products/${item.slug}`} className="text-sm font-medium text-ink hover:text-champagne-dark">
                    {item.nameFa}
                  </Link>
                  {item.variantLabel && <p className="mt-0.5 text-xs text-muted">{item.variantLabel}</p>}
                </div>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center rounded-sm border border-border-strong">
                    <button
                      type="button"
                      onClick={() => setQuantity(item.productId, item.variantSku, item.quantity - 1)}
                      aria-label="کاهش تعداد"
                      className="p-2 text-ink"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="w-8 text-center text-sm">{toPersianDigits(item.quantity)}</span>
                    <button
                      type="button"
                      onClick={() => setQuantity(item.productId, item.variantSku, item.quantity + 1)}
                      disabled={item.quantity >= item.stock}
                      aria-label="افزایش تعداد"
                      className="p-2 text-ink disabled:text-muted"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <span className="text-sm font-semibold text-ink">{formatCurrency(item.unitPrice * item.quantity)}</span>
                  <button
                    type="button"
                    onClick={() => removeItem(item.productId, item.variantSku)}
                    aria-label="حذف از سبد"
                    className="rounded-sm p-2 text-muted hover:bg-surface hover:text-error"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
          <div className="p-4">
            <Link href="/products" className="text-sm font-medium text-champagne-dark hover:underline">
              ادامه خرید
            </Link>
          </div>
        </div>

        <div className="h-fit rounded-md border border-border bg-surface/40 p-5">
          <h2 className="text-sm font-semibold text-ink">خلاصه سفارش</h2>

          <form onSubmit={handleApplyCode} className="mt-4 flex items-center gap-2">
            <div className="flex flex-1 items-center gap-2 rounded-sm border border-border-strong bg-paper px-3 py-2.5">
              <Tag size={15} className="text-muted" />
              <input
                type="text"
                value={codeInput}
                onChange={(e) => setCodeInput(e.target.value)}
                placeholder="کد تخفیف"
                className="w-full bg-transparent text-sm text-ink placeholder:text-muted focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={applying}
              className="shrink-0 rounded-sm border border-border-strong px-3.5 py-2.5 text-xs font-medium text-ink hover:bg-surface"
            >
              {applying ? <Loader2 size={14} className="animate-spin" /> : "اعمال"}
            </button>
          </form>
          {codeMessage && (
            <p className={`mt-2 text-xs ${codeMessage.type === "error" ? "text-error" : "text-success"}`}>{codeMessage.text}</p>
          )}
          {discountCode && (
            <div className="mt-2 flex items-center justify-between rounded-sm bg-success/10 px-3 py-2 text-xs text-success">
              <span>کد «{discountCode}» اعمال شد</span>
              <button type="button" onClick={clearDiscount} className="underline">
                حذف
              </button>
            </div>
          )}

          <dl className="mt-5 flex flex-col gap-2.5 border-t border-border pt-4 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted">جمع جزء</dt>
              <dd className="text-ink">{formatCurrency(subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">هزینه ارسال</dt>
              <dd className="text-ink">{shipping === 0 ? "رایگان" : formatCurrency(shipping)}</dd>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between">
                <dt className="text-muted">تخفیف</dt>
                <dd className="text-error">- {formatCurrency(discountAmount)}</dd>
              </div>
            )}
            {shipping > 0 && (
              <p className="text-[11px] text-muted">
                با {formatCurrency(FREE_SHIPPING_THRESHOLD - subtotal)} خرید بیشتر، ارسال رایگان می‌شود.
              </p>
            )}
            <div className="flex justify-between border-t border-border pt-3 text-base font-bold">
              <dt className="text-ink">مبلغ قابل پرداخت</dt>
              <dd className="text-ink">{formatCurrency(total)}</dd>
            </div>
          </dl>

          <Link
            href="/checkout"
            className="mt-5 block w-full rounded-sm bg-ink py-3.5 text-center text-sm font-semibold text-paper hover:bg-charcoal"
          >
            ادامه فرآیند خرید
          </Link>
        </div>
      </div>
    </div>
  );
}
