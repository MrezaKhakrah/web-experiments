import type { Metadata } from "next";
import Link from "next/link";
import { getAllBrands } from "@/db/queries";
import { db } from "@/db";
import { products } from "@/db/schema";
import { sql } from "drizzle-orm";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { formatNumber } from "@/lib/format";

export const metadata: Metadata = { title: "برندها" };
export const dynamic = "force-dynamic";

export default async function BrandsPage() {
  const brands = await getAllBrands();
  const counts = await db
    .select({ brandId: products.brandId, count: sql<number>`count(*)::int` })
    .from(products)
    .groupBy(products.brandId);
  const countMap = new Map(counts.map((c) => [c.brandId, c.count]));

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "برندها" }]} />
      <h1 className="mt-4 text-2xl font-bold text-ink sm:text-3xl">برندهای موجود در هورو</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted">
        نام‌ها و لوگوهای برندهای ثالث صرفاً برای کمک به یافتن محصول نمایش داده می‌شوند و به‌معنای همکاری یا تاییدیه رسمی از
        سوی آن برندها نیست.
      </p>
      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {brands.map((brand) => (
          <Link
            key={brand.slug}
            href={`/products?brand=${brand.slug}`}
            className="flex items-center justify-between rounded-md border border-border bg-paper p-5 transition-shadow hover:shadow-card"
          >
            <div>
              <p className="text-lg font-bold text-ink">{brand.name}</p>
              <p className="text-xs text-muted">{brand.nameFa} — {brand.country}</p>
            </div>
            <span className="rounded-full bg-surface px-3 py-1 text-xs text-muted">
              {formatNumber(countMap.get(brand.id) ?? 0)} محصول
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
