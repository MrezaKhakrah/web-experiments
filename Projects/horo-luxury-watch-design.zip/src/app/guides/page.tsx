import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { guides } from "@/lib/guides-content";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { toPersianDigits } from "@/lib/format";

export const metadata: Metadata = { title: "راهنمای خرید" };

export default function GuidesPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "راهنمای خرید" }]} />
      <h1 className="mt-4 text-2xl font-bold text-ink sm:text-3xl">راهنمای خرید ساعت</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted">مقالاتی کاربردی برای تصمیم‌گیری آگاهانه‌تر هنگام خرید ساعت.</p>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        {guides.map((guide) => (
          <Link
            key={guide.slug}
            href={`/guides/${guide.slug}`}
            className="group flex flex-col justify-between rounded-md border border-border bg-paper p-6 transition-shadow hover:shadow-card"
          >
            <div>
              <h2 className="text-base font-semibold text-ink">{guide.title}</h2>
              <p className="mt-2 text-sm leading-6 text-muted">{guide.excerpt}</p>
            </div>
            <div className="mt-5 flex items-center justify-between text-xs text-muted">
              <span>{toPersianDigits(guide.readMinutes)} دقیقه مطالعه</span>
              <ArrowLeft size={14} className="rtl:-scale-x-100 text-champagne-dark transition-transform group-hover:-translate-x-0.5" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
