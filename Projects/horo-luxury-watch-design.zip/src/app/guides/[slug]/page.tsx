import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { guides } from "@/lib/guides-content";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { toPersianDigits } from "@/lib/format";

export function generateStaticParams() {
  return guides.map((g) => ({ slug: g.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const guide = guides.find((g) => g.slug === slug);
  if (!guide) return { title: "مقاله یافت نشد" };
  return { title: guide.title, description: guide.excerpt, alternates: { canonical: `/guides/${guide.slug}` } };
}

export default async function GuideArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const guide = guides.find((g) => g.slug === slug);
  if (!guide) notFound();

  return (
    <article className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
      <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "راهنمای خرید", href: "/guides" }, { label: guide.title }]} />
      <h1 className="mt-4 text-2xl font-bold text-ink sm:text-3xl">{guide.title}</h1>
      <p className="mt-2 text-sm text-muted">{toPersianDigits(guide.readMinutes)} دقیقه مطالعه</p>
      <div className="prose-none mt-8 flex flex-col gap-5">
        {guide.body.map((paragraph, idx) => (
          <p key={idx} className="text-sm leading-8 text-ink/90">
            {paragraph}
          </p>
        ))}
      </div>
      <div className="mt-10 border-t border-border pt-6">
        <Link href="/guides" className="text-sm font-medium text-champagne-dark hover:underline">
          بازگشت به راهنمای خرید
        </Link>
      </div>
    </article>
  );
}
