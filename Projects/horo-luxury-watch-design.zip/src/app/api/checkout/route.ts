import { db } from "@/db";
import { products, productVariants, orders, orderItems, discountCodes } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { calcShippingCost } from "@/lib/commerce";

export const dynamic = "force-dynamic";

type CheckoutItem = { productId: number; variantSku?: string | null; quantity: number };

function generateOrderNumber() {
  const date = new Date();
  const stamp = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(date.getDate()).padStart(2, "0")}`;
  const random = Math.floor(1000 + Math.random() * 9000);
  return `HORO-${stamp}-${random}`;
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  if (!body) return Response.json({ error: "بدنه درخواست نامعتبر است." }, { status: 400 });

  const items: CheckoutItem[] = Array.isArray(body.items) ? body.items : [];
  const address = body.address;
  const paymentMethod = body.paymentMethod === "card" ? "card" : "cod";
  const discountCodeInput: string | undefined = body.discountCode;
  const guestEmail: string | undefined = body.guestEmail;
  const guestPhone: string | undefined = body.guestPhone;

  if (items.length === 0) {
    return Response.json({ error: "سبد خرید خالی است." }, { status: 400 });
  }
  if (
    !address ||
    !address.fullName ||
    !address.phone ||
    !address.province ||
    !address.city ||
    !address.addressLine ||
    !address.postalCode
  ) {
    return Response.json({ error: "اطلاعات آدرس ناقص است." }, { status: 400 });
  }

  const user = await getCurrentUser();

  const productIds = Array.from(new Set(items.map((i) => i.productId)));
  const dbProducts = await db.select().from(products).where(inArray(products.id, productIds));
  const productMap = new Map(dbProducts.map((p) => [p.id, p]));

  const variantSkus = items.map((i) => i.variantSku).filter((s): s is string => Boolean(s));
  const dbVariants = variantSkus.length
    ? await db.select().from(productVariants).where(inArray(productVariants.sku, variantSkus))
    : [];
  const variantMap = new Map(dbVariants.map((v) => [v.sku, v]));

  const resolvedItems: {
    productId: number;
    productNameFa: string;
    variantLabel: string | null;
    unitPrice: number;
    quantity: number;
    imageUrl: string;
    variantSku?: string;
  }[] = [];

  for (const item of items) {
    const product = productMap.get(item.productId);
    if (!product) {
      return Response.json({ error: `محصولی با شناسه ${item.productId} یافت نشد.` }, { status: 400 });
    }
    const quantity = Math.max(1, Math.floor(item.quantity));
    const variant = item.variantSku ? variantMap.get(item.variantSku) : undefined;
    const availableStock = variant ? variant.stock : product.stock;

    if (availableStock < quantity) {
      return Response.json(
        { error: `موجودی «${product.nameFa}» کافی نیست. موجودی فعلی: ${availableStock}` },
        { status: 409 },
      );
    }

    resolvedItems.push({
      productId: product.id,
      productNameFa: product.nameFa,
      variantLabel: variant ? `${variant.colorName} — بند ${variant.strapMaterial}` : null,
      unitPrice: product.price + (variant?.priceDelta ?? 0),
      quantity,
      imageUrl: variant?.image ?? (product.images as string[])[0],
      variantSku: variant?.sku,
    });
  }

  const subtotal = resolvedItems.reduce((sum, i) => sum + i.unitPrice * i.quantity, 0);
  const shippingCost = calcShippingCost(subtotal);

  let discountAmount = 0;
  let appliedCode: string | null = null;
  if (discountCodeInput) {
    const code = discountCodeInput.trim().toUpperCase();
    const rows = await db.select().from(discountCodes).where(eq(discountCodes.code, code)).limit(1);
    const discount = rows[0];
    if (discount && discount.active && subtotal >= discount.minSubtotal) {
      discountAmount = discount.percentOff ? Math.round((subtotal * discount.percentOff) / 100) : (discount.amountOff ?? 0);
      appliedCode = discount.code;
    }
  }

  const total = Math.max(0, subtotal + shippingCost - discountAmount);
  const orderNumber = generateOrderNumber();

  const [order] = await db
    .insert(orders)
    .values({
      orderNumber,
      userId: user?.id ?? null,
      guestEmail: user ? null : guestEmail ?? null,
      guestPhone: user ? null : guestPhone ?? null,
      status: "confirmed",
      subtotal,
      shippingCost,
      discountAmount,
      discountCode: appliedCode,
      total,
      shippingAddress: {
        fullName: address.fullName,
        phone: address.phone,
        province: address.province,
        city: address.city,
        addressLine: address.addressLine,
        postalCode: address.postalCode,
      },
      paymentMethod,
    })
    .returning();

  await db.insert(orderItems).values(
    resolvedItems.map((i) => ({
      orderId: order.id,
      productId: i.productId,
      productNameFa: i.productNameFa,
      variantLabel: i.variantLabel,
      unitPrice: i.unitPrice,
      quantity: i.quantity,
      imageUrl: i.imageUrl,
    })),
  );

  // Decrement authoritative stock.
  for (const item of resolvedItems) {
    const product = productMap.get(item.productId)!;
    await db
      .update(products)
      .set({ stock: Math.max(0, product.stock - item.quantity) })
      .where(eq(products.id, item.productId));

    if (item.variantSku) {
      const variant = variantMap.get(item.variantSku)!;
      await db
        .update(productVariants)
        .set({ stock: Math.max(0, variant.stock - item.quantity) })
        .where(eq(productVariants.id, variant.id));
    }
  }

  return Response.json({ orderNumber: order.orderNumber });
}
