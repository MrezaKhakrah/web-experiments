import { getProducts } from "@/db/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const q = searchParams.get("q")?.trim() ?? "";

  if (q.length < 2) {
    return Response.json({ items: [] });
  }

  const { items } = await getProducts({ search: q, pageSize: 6, sort: "relevance" });

  return Response.json({
    items: items.map((p) => ({
      slug: p.slug,
      nameFa: p.nameFa,
      brandNameFa: p.brandNameFa,
      image: p.images?.[0] ?? null,
      price: p.price,
    })),
  });
}
