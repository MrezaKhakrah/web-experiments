import { getProductsByIds } from "@/db/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const idsParam = searchParams.get("ids") ?? "";
  const ids = idsParam
    .split(",")
    .map((v) => Number(v.trim()))
    .filter((v) => Number.isFinite(v) && v > 0);

  if (ids.length === 0) {
    return Response.json({ items: [] });
  }

  const items = await getProductsByIds(ids);
  return Response.json({ items });
}
