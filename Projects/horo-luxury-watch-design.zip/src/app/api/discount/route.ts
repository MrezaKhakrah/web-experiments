import { db } from "@/db";
import { discountCodes } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const code = String(body?.code ?? "").trim().toUpperCase();
  const subtotal = Number(body?.subtotal ?? 0);

  if (!code) {
    return Response.json({ valid: false, message: "کد تخفیف را وارد کنید." }, { status: 400 });
  }

  const rows = await db.select().from(discountCodes).where(eq(discountCodes.code, code)).limit(1);
  const discount = rows[0];

  if (!discount || !discount.active) {
    return Response.json({ valid: false, message: "کد تخفیف نامعتبر است." });
  }
  if (subtotal < discount.minSubtotal) {
    return Response.json({
      valid: false,
      message: `این کد برای سفارش‌های بالای ${discount.minSubtotal.toLocaleString("en-US")} تومان قابل استفاده است.`,
    });
  }

  const amount = discount.percentOff
    ? Math.round((subtotal * discount.percentOff) / 100)
    : (discount.amountOff ?? 0);

  return Response.json({ valid: true, amount, code, message: "کد تخفیف با موفقیت اعمال شد." });
}
