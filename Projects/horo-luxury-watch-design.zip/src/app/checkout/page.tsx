import type { Metadata } from "next";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { addresses } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { CheckoutForm } from "@/components/checkout/CheckoutForm";

export const metadata: Metadata = { title: "تسویه حساب" };
export const dynamic = "force-dynamic";

export default async function CheckoutPage() {
  const user = await getCurrentUser();
  const savedAddresses = user
    ? await db.select().from(addresses).where(eq(addresses.userId, user.id)).orderBy(desc(addresses.isDefault))
    : [];

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "سبد خرید", href: "/cart" }, { label: "تسویه حساب" }]} />
      <h1 className="mt-4 text-2xl font-bold text-ink sm:text-3xl">تسویه‌حساب</h1>
      <div className="mt-8">
        <CheckoutForm isLoggedIn={Boolean(user)} savedAddresses={savedAddresses} userEmail={user?.email} />
      </div>
    </div>
  );
}
