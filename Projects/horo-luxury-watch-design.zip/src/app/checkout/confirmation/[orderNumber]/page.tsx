import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { CheckCircle2 } from "lucide-react";
import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { formatCurrency, formatDate, toPersianDigits } from "@/lib/format";

export const metadata: Metadata = { title: "تایید سفارش" };
export const dynamic = "force-dynamic";

export default async function OrderConfirmationPage({ params }: { params: Promise<{ orderNumber: string }> }) {
  const { orderNumber } = await params;

  const orderRows = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
  const order = orderRows[0];
  if (!order) notFound();

  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <div className="flex flex-col items-center text-center">
        <span className="flex h-16 w-16 items-center justify-center rounded-full bg-success/10 text-success">
          <CheckCircle2 size={34} />
        </span>
        <h1 className="mt-5 text-2xl font-bold text-ink sm:text-3xl">سفارش شما با موفقیت ثبت شد</h1>
        <p className="mt-2 text-sm text-muted">
          شماره سفارش: <span className="font-semibold text-ink">{orderNumber}</span>
        </p>
        <p className="mt-1 text-xs text-muted">{formatDate(order.createdAt)}</p>
      </div>

      <div className="mt-10 rounded-md border border-border">
        <div className="divide-y divide-border">
          {items.map((item) => (
            <div key={item.id} className="flex items-center gap-4 p-4">
              {item.imageUrl && (
                <span className="relative h-16 w-16 shrink-0 overflow-hidden rounded-sm bg-surface">
                  <Image src={item.imageUrl} alt={item.productNameFa} fill sizes="64px" className="object-cover" />
                </span>
              )}
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-ink">{item.productNameFa}</p>
                {item.variantLabel && <p className="text-xs text-muted">{item.variantLabel}</p>}
                <p className="text-xs text-muted">تعداد: {toPersianDigits(item.quantity)}</p>
              </div>
              <span className="shrink-0 text-sm font-semibold text-ink">{formatCurrency(item.unitPrice * item.quantity)}</span>
            </div>
          ))}
        </div>
        <dl className="flex flex-col gap-2 border-t border-border bg-surface/40 p-4 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted">جمع جزء</dt>
            <dd className="text-ink">{formatCurrency(order.subtotal)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">هزینه ارسال</dt>
            <dd className="text-ink">{order.shippingCost === 0 ? "رایگان" : formatCurrency(order.shippingCost)}</dd>
          </div>
          {order.discountAmount > 0 && (
            <div className="flex justify-between">
              <dt className="text-muted">تخفیف ({order.discountCode})</dt>
              <dd className="text-error">- {formatCurrency(order.discountAmount)}</dd>
            </div>
          )}
          <div className="flex justify-between border-t border-border pt-2 text-base font-bold">
            <dt className="text-ink">مبلغ پرداختی</dt>
            <dd className="text-ink">{formatCurrency(order.total)}</dd>
          </div>
        </dl>
      </div>

      <div className="mt-6 rounded-md border border-border p-5 text-sm">
        <h2 className="mb-2 font-semibold text-ink">آدرس تحویل</h2>
        <p className="text-muted">
          {order.shippingAddress.fullName} — {toPersianDigits(order.shippingAddress.phone)}
          <br />
          {order.shippingAddress.province}، {order.shippingAddress.city}، {order.shippingAddress.addressLine}
        </p>
      </div>

      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Link href="/products" className="rounded-sm bg-ink px-6 py-3 text-sm font-semibold text-paper hover:bg-charcoal">
          ادامه خرید
        </Link>
        <Link href="/account" className="rounded-sm border border-border-strong px-6 py-3 text-sm font-semibold text-ink hover:bg-surface">
          مشاهده سفارش‌های من
        </Link>
      </div>
    </div>
  );
}
