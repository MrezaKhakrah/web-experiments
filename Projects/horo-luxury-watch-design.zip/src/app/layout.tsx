import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { vazirmatn } from "@/lib/fonts";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { AnnouncementBar } from "@/components/layout/AnnouncementBar";
import { CompareBar } from "@/components/layout/CompareBar";
import { ToastContainer } from "@/components/ui/ToastContainer";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = {
  title: {
    default: "هورو | HORO — زمان، پالایش‌شده",
    template: "%s | HORO",
  },
  description:
    "هورو مقصد خرید ساعت‌های هوشمند، کلاسیک، اسپرت و لوکس با ضمانت اصالت کالا، مشاوره تخصصی و ارسال سراسری.",
  metadataBase: new URL("https://horo.example.com"),
  icons: { icon: "/favicon.ico" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#faf8f4",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();

  return (
    <html lang="fa" dir="rtl" className={vazirmatn.variable}>
      <body className="flex min-h-screen flex-col bg-paper font-sans text-ink antialiased">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:start-2 focus:z-[200] focus:rounded-sm focus:bg-ink focus:px-4 focus:py-2 focus:text-paper"
        >
          رفتن به محتوای اصلی
        </a>
        <AnnouncementBar />
        <Header isLoggedIn={Boolean(user)} />
        <main id="main-content" className="flex-1">
          {children}
        </main>
        <Footer />
        <CompareBar />
        <ToastContainer />
      </body>
    </html>
  );
}
