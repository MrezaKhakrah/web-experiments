import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { LogOut, PackageCheck, MapPin } from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { logoutAction } from "@/app/actions/auth";
import { db } from "@/db";
import { addresses, orders } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { AddAddressForm } from "@/components/account/AddAddressForm";
import { formatCurrency, formatDate, toPersianDigits } from "@/lib/format";

export const metadata: Metadata = { title: "حساب کاربری" };
export const dynamic = "force-dynamic";

const statusLabels: Record<string, string> = {
  pending: "در انتظار بررسی",
  confirmed: "تایید شده",
  processing: "در حال آماده‌سازی",
  shipped: "ارسال شده",
  delivered: "تحویل داده شده",
  cancelled: "لغو شده",
};

export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/account/login");

  const [userOrders, userAddresses] = await Promise.all([
    db.select().from(orders).where(eq(orders.userId, user.id)).orderBy(desc(orders.createdAt)),
    db.select().from(addresses).where(eq(addresses.userId, user.id)).orderBy(desc(addresses.isDefault)),
  ]);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "حساب کاربری" }]} />
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink sm:text-3xl">سلام {user.fullName} 👋</h1>
          <p className="mt-1 text-sm text-muted">{user.email}</p>
        </div>
        <form action={logoutAction}>
          <button type="submit" className="flex items-center gap-1.5 rounded-sm border border-border-strong px-4 py-2.5 text-sm text-ink hover:bg-surface">
            <LogOut size={15} /> خروج از حساب
          </button>
        </form>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-2">
        <section>
          <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-ink">
            <PackageCheck size={19} /> سفارش‌های من
          </h2>
          {userOrders.length === 0 ? (
            <p className="rounded-md border border-dashed border-border-strong bg-surface/40 p-6 text-center text-sm text-muted">
              هنوز سفارشی ثبت نکرده‌اید.
            </p>
          ) : (
            <ul className="flex flex-col gap-3">
              {userOrders.map((order) => (
                <li key={order.id} className="rounded-md border border-border p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <Link href={`/checkout/confirmation/${order.orderNumber}`} className="text-sm font-semibold text-ink hover:text-champagne-dark">
                      سفارش #{toPersianDigits(order.orderNumber)}
                    </Link>
                    <span className="rounded-sm bg-surface px-2.5 py-1 text-xs text-muted">
                      {statusLabels[order.status] ?? order.status}
                    </span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs text-muted">
                    <span>{formatDate(order.createdAt)}</span>
                    <span className="font-medium text-ink">{formatCurrency(order.total)}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section>
          <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-ink">
            <MapPin size={19} /> آدرس‌های من
          </h2>
          {userAddresses.length > 0 && (
            <ul className="mb-4 flex flex-col gap-3">
              {userAddresses.map((addr) => (
                <li key={addr.id} className="rounded-md border border-border p-4 text-sm">
                  <p className="font-medium text-ink">
                    {addr.fullName} {addr.isDefault && <span className="text-xs text-champagne-dark">(پیش‌فرض)</span>}
                  </p>
                  <p className="mt-1 text-xs text-muted">
                    {addr.province}، {addr.city}، {addr.addressLine}
                  </p>
                  <p className="mt-1 text-xs text-muted">{toPersianDigits(addr.phone)} — کد پستی {toPersianDigits(addr.postalCode)}</p>
                </li>
              ))}
            </ul>
          )}
          <div className="rounded-md border border-border bg-paper p-4">
            <h3 className="mb-3 text-sm font-semibold text-ink">افزودن آدرس جدید</h3>
            <AddAddressForm />
          </div>
        </section>
      </div>
    </div>
  );
}
