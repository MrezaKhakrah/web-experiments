import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { LoginForm } from "@/components/account/LoginForm";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";

export const metadata: Metadata = { title: "ورود به حساب کاربری" };

export default async function LoginPage() {
  const user = await getCurrentUser();
  if (user) redirect("/account");

  return (
    <div className="mx-auto max-w-md px-4 py-10 sm:px-6">
      <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "ورود" }]} />
      <h1 className="mt-4 text-2xl font-bold text-ink">ورود به حساب کاربری</h1>
      <p className="mt-1.5 text-sm text-muted">برای مشاهده سفارش‌ها و آدرس‌های خود وارد شوید.</p>
      <div className="mt-6 rounded-md border border-border bg-paper p-6">
        <LoginForm />
      </div>
    </div>
  );
}
