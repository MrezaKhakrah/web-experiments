import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { RegisterForm } from "@/components/account/RegisterForm";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";

export const metadata: Metadata = { title: "ثبت‌نام" };

export default async function RegisterPage() {
  const user = await getCurrentUser();
  if (user) redirect("/account");

  return (
    <div className="mx-auto max-w-md px-4 py-10 sm:px-6">
      <Breadcrumbs items={[{ label: "خانه", href: "/" }, { label: "ثبت‌نام" }]} />
      <h1 className="mt-4 text-2xl font-bold text-ink">ایجاد حساب کاربری</h1>
      <p className="mt-1.5 text-sm text-muted">برای خرید سریع‌تر و پیگیری سفارش‌ها ثبت‌نام کنید.</p>
      <div className="mt-6 rounded-md border border-border bg-paper p-6">
        <RegisterForm />
      </div>
    </div>
  );
}
