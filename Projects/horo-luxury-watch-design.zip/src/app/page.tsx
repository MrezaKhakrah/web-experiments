import Link from "next/link";
import { getProducts, getAllBrands } from "@/db/queries";
import { Hero } from "@/components/home/Hero";
import { CategoryGrid } from "@/components/home/CategoryGrid";
import { BrandStrip } from "@/components/home/BrandStrip";
import { Collections } from "@/components/home/Collections";
import { ProductCarousel } from "@/components/product/ProductCarousel";
import { EditorialFeature } from "@/components/home/EditorialFeature";
import { TrustSection } from "@/components/home/TrustSection";
import { BuyingGuideSection } from "@/components/home/BuyingGuideSection";
import { Newsletter } from "@/components/home/Newsletter";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [bestsellers, newArrivals, featured, brands] = await Promise.all([
    getProducts({ sort: "popularity", pageSize: 8 }),
    getProducts({ sort: "newest", pageSize: 8 }),
    getProducts({ pageSize: 8 }),
    getAllBrands(),
  ]);

  return (
    <>
      <Hero />
      <CategoryGrid />

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="text-xl font-bold text-ink sm:text-2xl">پرفروش‌ترین‌ها</h2>
            <p className="mt-1.5 text-sm text-muted">انتخاب‌هایی که مشتریان هورو بیشتر پسندیده‌اند</p>
          </div>
          <Link href="/products?sort=popularity" className="hidden text-xs font-medium text-champagne-dark hover:underline sm:block">
            مشاهده همه
          </Link>
        </div>
        <ProductCarousel products={bestsellers.items} />
      </section>

      <BrandStrip brands={brands} />

      <Collections />

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="text-xl font-bold text-ink sm:text-2xl">تازه‌واردها</h2>
            <p className="mt-1.5 text-sm text-muted">جدیدترین اضافه‌شده‌های فروشگاه هورو</p>
          </div>
          <Link href="/products?sort=newest" className="hidden text-xs font-medium text-champagne-dark hover:underline sm:block">
            مشاهده همه
          </Link>
        </div>
        <ProductCarousel products={newArrivals.items} />
      </section>

      <EditorialFeature />

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="text-xl font-bold text-ink sm:text-2xl">پیشنهاد ویژه هورو</h2>
            <p className="mt-1.5 text-sm text-muted">محصولاتی که تیم ما برای شما انتخاب کرده است</p>
          </div>
        </div>
        <ProductCarousel products={featured.items} />
      </section>

      <TrustSection />
      <BuyingGuideSection />
      <Newsletter />
    </>
  );
}
