const KEY = "horo-recently-viewed";
const MAX_ITEMS = 8;

export function pushRecentlyViewed(productId: number) {
  if (typeof window === "undefined") return;
  try {
    const raw = localStorage.getItem(KEY);
    const ids: number[] = raw ? JSON.parse(raw) : [];
    const next = [productId, ...ids.filter((id) => id !== productId)].slice(0, MAX_ITEMS);
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    // ignore storage errors (e.g. private mode)
  }
}

export function getRecentlyViewed(excludeId?: number): number[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    const ids: number[] = raw ? JSON.parse(raw) : [];
    return ids.filter((id) => id !== excludeId);
  } catch {
    return [];
  }
}
