"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

type WishlistState = {
  productIds: number[];
  toggle: (productId: number) => void;
  has: (productId: number) => boolean;
  remove: (productId: number) => void;
};

export const useWishlistStore = create<WishlistState>()(
  persist(
    (set, get) => ({
      productIds: [],
      toggle: (productId) => {
        const exists = get().productIds.includes(productId);
        set({
          productIds: exists
            ? get().productIds.filter((id) => id !== productId)
            : [...get().productIds, productId],
        });
      },
      has: (productId) => get().productIds.includes(productId),
      remove: (productId) => set({ productIds: get().productIds.filter((id) => id !== productId) }),
    }),
    { name: "horo-wishlist", storage: createJSONStorage(() => localStorage) },
  ),
);
