export const FREE_SHIPPING_THRESHOLD = 10_000_000;
export const FLAT_SHIPPING_COST = 450_000;

export function calcShippingCost(subtotal: number) {
  if (subtotal <= 0) return 0;
  return subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : FLAT_SHIPPING_COST;
}
