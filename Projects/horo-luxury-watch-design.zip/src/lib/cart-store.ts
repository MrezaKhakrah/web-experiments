"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

export type CartItem = {
  productId: number;
  slug: string;
  nameFa: string;
  brandNameFa: string;
  image: string;
  unitPrice: number;
  compareAtPrice?: number | null;
  variantLabel?: string | null;
  variantSku?: string | null;
  quantity: number;
  stock: number;
};

type CartState = {
  items: CartItem[];
  discountCode: string | null;
  discountAmount: number;
  addItem: (item: Omit<CartItem, "quantity">, quantity?: number) => void;
  removeItem: (productId: number, variantSku?: string | null) => void;
  setQuantity: (productId: number, variantSku: string | null | undefined, quantity: number) => void;
  applyDiscount: (code: string, amount: number) => void;
  clearDiscount: () => void;
  clear: () => void;
};

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      discountCode: null,
      discountAmount: 0,
      addItem: (item, quantity = 1) => {
        const items = [...get().items];
        const idx = items.findIndex(
          (i) => i.productId === item.productId && i.variantSku === item.variantSku,
        );
        if (idx >= 0) {
          const next = Math.min(items[idx].quantity + quantity, item.stock || 99);
          items[idx] = { ...items[idx], quantity: next };
        } else {
          items.push({ ...item, quantity: Math.min(quantity, item.stock || 99) });
        }
        set({ items });
      },
      removeItem: (productId, variantSku) => {
        set({
          items: get().items.filter(
            (i) => !(i.productId === productId && i.variantSku === variantSku),
          ),
        });
      },
      setQuantity: (productId, variantSku, quantity) => {
        set({
          items: get()
            .items.map((i) =>
              i.productId === productId && i.variantSku === variantSku
                ? { ...i, quantity: Math.max(1, Math.min(quantity, i.stock || 99)) }
                : i,
            )
            .filter((i) => i.quantity > 0),
        });
      },
      applyDiscount: (code, amount) => set({ discountCode: code, discountAmount: amount }),
      clearDiscount: () => set({ discountCode: null, discountAmount: 0 }),
      clear: () => set({ items: [], discountCode: null, discountAmount: 0 }),
    }),
    {
      name: "horo-cart",
      storage: createJSONStorage(() => localStorage),
    },
  ),
);

export function cartSubtotal(items: CartItem[]) {
  return items.reduce((sum, i) => sum + i.unitPrice * i.quantity, 0);
}
