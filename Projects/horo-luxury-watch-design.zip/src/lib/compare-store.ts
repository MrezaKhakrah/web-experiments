"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

const MAX_COMPARE = 4;

type CompareState = {
  productIds: number[];
  toggle: (productId: number) => { added: boolean; reason?: string };
  remove: (productId: number) => void;
  clear: () => void;
  has: (productId: number) => boolean;
};

export const useCompareStore = create<CompareState>()(
  persist(
    (set, get) => ({
      productIds: [],
      toggle: (productId) => {
        const exists = get().productIds.includes(productId);
        if (exists) {
          set({ productIds: get().productIds.filter((id) => id !== productId) });
          return { added: false };
        }
        if (get().productIds.length >= MAX_COMPARE) {
          return { added: false, reason: `حداکثر ${MAX_COMPARE} محصول قابل مقایسه است` };
        }
        set({ productIds: [...get().productIds, productId] });
        return { added: true };
      },
      remove: (productId) => set({ productIds: get().productIds.filter((id) => id !== productId) }),
      clear: () => set({ productIds: [] }),
      has: (productId) => get().productIds.includes(productId),
    }),
    { name: "horo-compare", storage: createJSONStorage(() => localStorage) },
  ),
);
