const PERSIAN_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** Convert any string/number containing ASCII digits into Persian digits. */
export function toPersianDigits(value: string | number): string {
  return String(value).replace(/[0-9]/g, (digit) => PERSIAN_DIGITS[Number(digit)]);
}

/** Format an integer Toman price with thousands separators and Persian digits. */
export function formatPrice(amount: number): string {
  const formatted = new Intl.NumberFormat("en-US").format(Math.round(amount));
  return toPersianDigits(formatted);
}

/** Format a price with currency label (تومان). */
export function formatCurrency(amount: number): string {
  return `${formatPrice(amount)} تومان`;
}

/** Format a plain integer/count using Persian digits. */
export function formatNumber(value: number): string {
  return toPersianDigits(new Intl.NumberFormat("en-US").format(value));
}

/** Format a date in Persian (Jalali-ish simplified) — falls back to locale date. */
export function formatDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  try {
    return toPersianDigits(
      new Intl.DateTimeFormat("fa-IR", { year: "numeric", month: "long", day: "numeric" }).format(d),
    );
  } catch {
    return toPersianDigits(d.toLocaleDateString());
  }
}

export function calcDiscountPercent(price: number, compareAtPrice?: number | null): number | null {
  if (!compareAtPrice || compareAtPrice <= price) return null;
  return Math.round(((compareAtPrice - price) / compareAtPrice) * 100);
}
