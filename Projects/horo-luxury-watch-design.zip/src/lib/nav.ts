export const categoryNavLinks = [
  { label: "ساعت‌های هوشمند", href: "/products?category=smartwatches" },
  { label: "ساعت‌های کلاسیک", href: "/products?category=classic" },
  { label: "ساعت‌های اسپرت", href: "/products?category=sport" },
  { label: "ساعت‌های لوکس", href: "/products?category=luxury" },
  { label: "مردانه", href: "/products?gender=men" },
  { label: "زنانه", href: "/products?gender=women" },
  { label: "لوازم جانبی", href: "/products?category=accessories" },
];

export const primaryNavLinks = [
  { label: "ساعت‌های هوشمند", href: "/products?category=smartwatches" },
  { label: "ساعت‌های کلاسیک", href: "/products?category=classic" },
  { label: "ساعت‌های لوکس", href: "/products?category=luxury" },
  { label: "برندها", href: "/brands" },
  { label: "راهنمای خرید", href: "/guides" },
];
