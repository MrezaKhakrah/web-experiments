"use client";

import { create } from "zustand";

export type Toast = {
  id: number;
  message: string;
  tone: "success" | "error" | "info";
};

let counter = 0;

type ToastState = {
  toasts: Toast[];
  push: (message: string, tone?: Toast["tone"]) => void;
  dismiss: (id: number) => void;
};

export const useToastStore = create<ToastState>()((set, get) => ({
  toasts: [],
  push: (message, tone = "info") => {
    const id = ++counter;
    set({ toasts: [...get().toasts, { id, message, tone }] });
    setTimeout(() => {
      set({ toasts: get().toasts.filter((t) => t.id !== id) });
    }, 3200);
  },
  dismiss: (id) => set({ toasts: get().toasts.filter((t) => t.id !== id) }),
}));
