const puppeteer = require('puppeteer');
(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', msg => { if (msg.type() === 'error') errors.push('CONSOLE: ' + msg.text()); });
  await page.setViewport({ width: 1400, height: 1000 });
  await page.goto('http://localhost:4173/', { waitUntil: 'networkidle0', timeout: 30000 });
  await page.screenshot({ path: '/tmp/home.png', fullPage: false });
  await page.goto('http://localhost:4173/category/sport', { waitUntil: 'networkidle0', timeout: 30000 });
  await page.screenshot({ path: '/tmp/category.png', fullPage: false });
  await page.goto('http://localhost:4173/product/meridian-0', { waitUntil: 'networkidle0', timeout: 30000 });
  await page.screenshot({ path: '/tmp/product.png', fullPage: false });
  await page.goto('http://localhost:4173/cart', { waitUntil: 'networkidle0', timeout: 30000 });
  await page.screenshot({ path: '/tmp/cart.png', fullPage: false });
  console.log('ERRORS:', JSON.stringify(errors, null, 2));
  await browser.close();
})();
