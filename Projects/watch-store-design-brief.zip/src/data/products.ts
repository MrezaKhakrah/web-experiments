import type { Product, ProductCategory, StrapMaterial, MovementType } from "./types";
import { brands } from "./brands";

const IMG: Record<ProductCategory, string[]> = {
  luxury: ["/images/watch-luxury.jpg", "/images/watch-luxury-2.jpg"],
  sport: ["/images/watch-sport.jpg", "/images/watch-sport-2.jpg"],
  smart: ["/images/watch-smart.jpg", "/images/watch-smart-2.jpg"],
};

const COLOR_PALETTE: Record<string, string> = {
  مشکی: "#1d1d1f",
  نقره‌ای: "#c7c9cc",
  طلایی: "#c9a24b",
  آبی: "#0071e3",
  قهوه‌ای: "#6b4a30",
};

function makeReviews(seed: number, productName: string) {
  const sample = [
    { author: "امیرحسین", title: "بهتر از انتظارم بود", body: "کیفیت ساخت عالیه و دقیقاً مثل عکس‌هاست. ارسال هم سریع بود.", rating: 5 },
    { author: "نگار", title: "خوبه ولی بند کمی سفته", body: "بعد از چند روز استفاده بند نرم‌تر شد. راضی‌ام.", rating: 4 },
    { author: "محمدرضا", title: "ارزش خرید داره", body: "نسبت به قیمتش کیفیتش خیلی خوبه. پیشنهاد می‌کنم.", rating: 5 },
    { author: "سارا", title: "بسته‌بندی شیک", body: "جعبه و بسته‌بندی خیلی لاکچری بود. خود ساعت هم سنگینه و محکم.", rating: 4 },
  ];
  return sample.slice(0, 2 + (seed % 3)).map((r, i) => ({
    id: `${productName}-rev-${i}`,
    author: r.author,
    rating: r.rating,
    date: `۱۴۰۳/0${((seed + i) % 9) + 1}/1${i}`,
    title: r.title,
    body: r.body,
    verified: i % 2 === 0,
    helpful: (seed * (i + 1)) % 24,
  }));
}

function makeQna(seed: number) {
  const qs = [
    { q: "گارانتی چند ماهه است؟", a: "۲۴ ماه گارانتی اصالت و سلامت فیزیکی." },
    { q: "ضد آب هست؟", a: "تا عمق ۵۰ متر مقاوم در برابر آب و رطوبت است." },
    { q: "امکان تعویض بند وجود داره؟", a: "بله، با سایز استاندارد لاگ ۲۰ تا ۲۲ میلی‌متر سازگار است." },
  ];
  return qs.slice(0, 1 + (seed % 3)).map((item, i) => ({
    id: `qna-${seed}-${i}`,
    question: item.q,
    answer: item.a,
    date: `۱۴۰۳/0${((seed + i) % 9) + 1}/0${(i % 9) + 1}`,
  }));
}

interface Seed {
  name: string;
  brandSlug: string;
  category: ProductCategory;
  movement: MovementType;
  strap: StrapMaterial;
  caseSize: number;
  price: number;
  oldPrice?: number;
  colors: string[];
  isNew?: boolean;
  isBestSeller?: boolean;
  isDeal?: boolean;
}

const seeds: Seed[] = [
  { name: "مریدین کلاسیک ۴۰", brandSlug: "meridian", category: "luxury", movement: "اتوماتیک", strap: "چرم", caseSize: 40, price: 48500000, oldPrice: 56000000, colors: ["قهوه‌ای", "مشکی"], isBestSeller: true },
  { name: "مریدین هریتج گلد", brandSlug: "meridian", category: "luxury", movement: "اتوماتیک", strap: "استیل", caseSize: 42, price: 72000000, colors: ["طلایی", "نقره‌ای"], isNew: true },
  { name: "آلتیمو سلست", brandSlug: "altimo", category: "luxury", movement: "کوارتز", strap: "استیل", caseSize: 38, price: 35900000, oldPrice: 41000000, colors: ["نقره‌ای", "مشکی"], isDeal: true },
  { name: "آلتیمو دوک", brandSlug: "altimo", category: "luxury", movement: "اتوماتیک", strap: "چرم", caseSize: 41, price: 61500000, colors: ["مشکی", "قهوه‌ای"] },
  { name: "مریدین مون‌فیز", brandSlug: "meridian", category: "luxury", movement: "اتوماتیک", strap: "چرم", caseSize: 40, price: 89000000, colors: ["آبی", "مشکی"], isNew: true },
  { name: "آلتیمو رویال", brandSlug: "altimo", category: "luxury", movement: "کوارتز", strap: "استیل", caseSize: 36, price: 28900000, colors: ["طلایی"] },

  { name: "ولوسیس ریسر کرونوگراف", brandSlug: "velocis", category: "sport", movement: "کوارتز", strap: "سیلیکون", caseSize: 44, price: 12900000, oldPrice: 15500000, colors: ["مشکی", "آبی"], isBestSeller: true, isDeal: true },
  { name: "تراپالس اکسپدیشن", brandSlug: "terrapulse", category: "sport", movement: "کوارتز", strap: "سیلیکون", caseSize: 46, price: 9800000, colors: ["مشکی", "نقره‌ای"], isNew: true },
  { name: "ولوسیس ایرو", brandSlug: "velocis", category: "sport", movement: "اتوماتیک", strap: "استیل", caseSize: 42, price: 24500000, colors: ["نقره‌ای"] },
  { name: "تراپالس دایور ۲۰۰", brandSlug: "terrapulse", category: "sport", movement: "اتوماتیک", strap: "سیلیکون", caseSize: 44, price: 18700000, oldPrice: 21000000, colors: ["آبی", "مشکی"] },
  { name: "ولوسیس استورم", brandSlug: "velocis", category: "sport", movement: "کوارتز", strap: "سیلیکون", caseSize: 40, price: 8200000, colors: ["مشکی"], isBestSeller: true },
  { name: "تراپالس تریل", brandSlug: "terrapulse", category: "sport", movement: "کوارتز", strap: "سیلیکون", caseSize: 42, price: 7450000, colors: ["نقره‌ای", "آبی"] },

  { name: "نکسا پالس ۲", brandSlug: "nexa", category: "smart", movement: "هوشمند", strap: "سیلیکون", caseSize: 44, price: 15900000, oldPrice: 18900000, colors: ["مشکی", "نقره‌ای"], isBestSeller: true, isDeal: true },
  { name: "اوربیت لوپ", brandSlug: "orbit", category: "smart", movement: "هوشمند", strap: "میلان", caseSize: 42, price: 21500000, colors: ["نقره‌ای", "طلایی"], isNew: true },
  { name: "نکسا فیت ایر", brandSlug: "nexa", category: "smart", movement: "هوشمند", strap: "سیلیکون", caseSize: 40, price: 9900000, colors: ["مشکی", "آبی"] },
  { name: "اوربیت پرو مکس", brandSlug: "orbit", category: "smart", movement: "هوشمند", strap: "استیل", caseSize: 46, price: 27900000, oldPrice: 31500000, colors: ["مشکی", "نقره‌ای"], isNew: true },
  { name: "نکسا هلث", brandSlug: "nexa", category: "smart", movement: "هوشمند", strap: "سیلیکون", caseSize: 41, price: 11200000, colors: ["آبی", "مشکی"] },
  { name: "اوربیت مینی", brandSlug: "orbit", category: "smart", movement: "هوشمند", strap: "سیلیکون", caseSize: 38, price: 13400000, colors: ["طلایی", "مشکی"] },
];

export const products: Product[] = seeds.map((s, idx) => {
  const brand = brands.find((b) => b.slug === s.brandSlug)!;
  const imgs = IMG[s.category];
  const images = [imgs[idx % 2], imgs[(idx + 1) % 2]];
  const slug = `${s.brandSlug}-${idx}`;
  const rating = Number((3.8 + ((idx * 7) % 12) / 10).toFixed(1));
  const reviewCount = 8 + ((idx * 13) % 120);

  return {
    id: `p-${idx}`,
    slug,
    name: s.name,
    brand: brand.name,
    brandSlug: brand.slug,
    category: s.category,
    movement: s.movement,
    strap: s.strap,
    caseSize: s.caseSize,
    price: s.price,
    oldPrice: s.oldPrice,
    rating,
    reviewCount,
    stock: s.isDeal ? 3 + (idx % 4) : 10 + (idx % 20),
    images,
    colors: s.colors.map((c, i) => ({
      id: `${slug}-c${i}`,
      name: c,
      hex: COLOR_PALETTE[c] ?? "#1d1d1f",
      image: images[i % images.length],
    })),
    isNew: s.isNew,
    isBestSeller: s.isBestSeller,
    isDeal: s.isDeal,
    dealEndsAt: s.isDeal ? Date.now() + 1000 * 60 * 60 * (6 + idx) : undefined,
    description:
      `${s.name} ترکیبی از طراحی دقیق و کیفیت ساخت بالاست. با موتور ${s.movement} و قاب ${s.caseSize} میلی‌متری، انتخابی مطمئن برای استفاده‌ی روزمره و موقعیت‌های خاص است. بند ${s.strap} آن راحتی و دوام را تضمین می‌کند.`,
    specs: {
      "برند": brand.name,
      "نوع موتور": s.movement,
      "جنس بند": s.strap,
      "قطر قاب": `${s.caseSize} میلی‌متر`,
      "ضد آب": "تا ۵۰ متر",
      "جنس شیشه": "سافایر کریستال",
      "گارانتی": "۲۴ ماه اصالت و سلامت فیزیکی",
      "کشور سازنده": s.category === "smart" ? "تایوان" : "سوئیس",
    },
    reviews: makeReviews(idx + 1, slug),
    qna: makeQna(idx + 1),
  };
});

export function getProductBySlug(slug: string) {
  return products.find((p) => p.slug === slug);
}

export function relatedProducts(p: Product, count = 4) {
  return products
    .filter((x) => x.id !== p.id && (x.category === p.category || x.brandSlug === p.brandSlug))
    .slice(0, count);
}
