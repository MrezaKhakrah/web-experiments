export type MovementType = "کوارتز" | "اتوماتیک" | "هوشمند";
export type StrapMaterial = "چرم" | "استیل" | "سیلیکون" | "میلان";
export type ProductCategory = "luxury" | "sport" | "smart";

export interface ColorVariant {
  id: string;
  name: string;
  hex: string;
  image: string;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  title: string;
  body: string;
  verified: boolean;
  helpful: number;
}

export interface QnA {
  id: string;
  question: string;
  answer?: string;
  date: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  brand: string;
  brandSlug: string;
  category: ProductCategory;
  movement: MovementType;
  strap: StrapMaterial;
  caseSize: number;
  price: number;
  oldPrice?: number;
  rating: number;
  reviewCount: number;
  stock: number;
  images: string[];
  colors: ColorVariant[];
  isNew?: boolean;
  isBestSeller?: boolean;
  isDeal?: boolean;
  dealEndsAt?: number;
  description: string;
  specs: Record<string, string>;
  reviews: Review[];
  qna: QnA[];
}
