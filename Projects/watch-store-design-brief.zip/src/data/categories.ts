export interface CategoryChip {
  slug: string;
  title: string;
  emoji: string;
}

export const categoryChips: CategoryChip[] = [
  { slug: "all", title: "همه", emoji: "⌚" },
  { slug: "luxury", title: "لوکس", emoji: "✨" },
  { slug: "sport", title: "اسپرت", emoji: "🏃" },
  { slug: "smart", title: "هوشمند", emoji: "🔋" },
  { slug: "new", title: "تازه‌ها", emoji: "🆕" },
  { slug: "deal", title: "شگفت‌انگیز", emoji: "🔥" },
];

export const categoryTitles: Record<string, string> = {
  all: "همه‌ی ساعت‌ها",
  luxury: "ساعت‌های لوکس",
  sport: "ساعت‌های اسپرت",
  smart: "ساعت‌های هوشمند",
};
