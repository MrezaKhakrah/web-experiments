export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  image: string;
  readMinutes: number;
  date: string;
}

export const blogPosts: BlogPost[] = [
  {
    id: "b1",
    title: "چطور ساعت هوشمند مناسب خودت را انتخاب کنی",
    excerpt: "از سنسور ضربان قلب تا باتری؛ چک‌لیست خرید ساعت هوشمند در یک نگاه.",
    image: "/images/blog-1.jpg",
    readMinutes: 4,
    date: "۱۴۰۳/۰۶/۱۲",
  },
  {
    id: "b2",
    title: "پشت صحنه‌ی ساخت یک ساعت مکانیکال",
    excerpt: "نگاهی به دنیای ساعت‌سازان و دقتی که در هر چرخ‌دنده نهفته است.",
    image: "/images/blog-2.jpg",
    readMinutes: 6,
    date: "۱۴۰۳/۰۵/۰۲",
  },
  {
    id: "b3",
    title: "راهنمای نگهداری از بند چرم ساعت",
    excerpt: "با چند نکته‌ی ساده عمر بند چرمی ساعتت را دو برابر کن.",
    image: "/images/watch-luxury.jpg",
    readMinutes: 3,
    date: "۱۴۰۳/۰۴/۲۰",
  },
];
