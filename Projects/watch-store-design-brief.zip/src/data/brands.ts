export interface Brand {
  slug: string;
  name: string;
  category: "luxury" | "sport" | "smart";
  tagline: string;
}

export const brands: Brand[] = [
  { slug: "meridian", name: "مریدین", category: "luxury", tagline: "اصالت سوئیسی از ۱۹۶۲" },
  { slug: "altimo", name: "آلتیمو", category: "luxury", tagline: "ساخت دست، میراث ابدی" },
  { slug: "velocis", name: "ولوسیس", category: "sport", tagline: "برای هر قدم، هر میدان" },
  { slug: "terrapulse", name: "تراپالس", category: "sport", tagline: "مقاوم در برابر هر شرایطی" },
  { slug: "nexa", name: "نکسا", category: "smart", tagline: "هوش روی مچ دست" },
  { slug: "orbit", name: "اوربیت", category: "smart", tagline: "متصل به زندگی تو" },
];
