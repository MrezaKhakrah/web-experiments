import { Suspense, lazy, useEffect, useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Header } from "./components/layout/Header";
import { Footer } from "./components/layout/Footer";
import { SkipLink } from "./components/layout/SkipLink";
import { CartDrawer } from "./components/layout/CartDrawer";
import { ToastHost } from "./components/layout/ToastHost";
import { ScrollToTop } from "./components/layout/ScrollToTop";
import { OfflineBanner } from "./components/ui/States";
import { CompareBar } from "./components/product/CompareBar";
import Home from "./pages/Home";
import CategoryListing from "./pages/CategoryListing";
import SearchPage from "./pages/Search";
import Blog from "./pages/Blog";
import { About, Warranty, Returns, Privacy, NotFound } from "./pages/StaticPages";

const ProductDetail = lazy(() => import("./pages/ProductDetail"));
const Compare = lazy(() => import("./pages/Compare"));
const CartPage = lazy(() => import("./pages/CartPage"));
const Checkout = lazy(() => import("./pages/Checkout"));
const Account = lazy(() => import("./pages/Account"));

function PageFallback() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6" aria-busy="true">
      <div className="h-8 w-48 animate-pulse rounded-[12px] bg-border/50" />
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="aspect-square animate-pulse rounded-[18px] bg-border/40" />
        ))}
      </div>
    </div>
  );
}

export default function App() {
  const [cartOpen, setCartOpen] = useState(false);
  const [online, setOnline] = useState(true);

  useEffect(() => {
    setOnline(navigator.onLine);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  return (
    <BrowserRouter>
      <SkipLink />
      <OfflineBanner visible={!online} />
      <div className="flex min-h-screen flex-col bg-bg text-text">
        <Header onOpenCart={() => setCartOpen(true)} />
        <main id="main-content" className="flex-1 pb-20 sm:pb-0">
          <ScrollToTop />
          <Suspense fallback={<PageFallback />}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/category/:slug" element={<CategoryListing />} />
              <Route path="/product/:slug" element={<ProductDetail />} />
              <Route path="/compare" element={<Compare />} />
              <Route path="/cart" element={<CartPage />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/account" element={<Account />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/about" element={<About />} />
              <Route path="/warranty" element={<Warranty />} />
              <Route path="/returns" element={<Returns />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/404" element={<NotFound />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </main>
        <Footer />
      </div>
      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
      <CompareBar />
      <ToastHost />
    </BrowserRouter>
  );
}
