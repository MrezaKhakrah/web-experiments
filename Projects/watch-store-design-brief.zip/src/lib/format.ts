const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** Convert any number/string to Persian digits */
export function toFaDigits(value: number | string): string {
  return String(value).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

/** Format a toman amount with thousand separators + Persian digits */
export function formatPrice(value: number): string {
  const withSeparators = Math.round(value).toLocaleString("en-US");
  return `${toFaDigits(withSeparators)} تومان`;
}

export function formatNumber(value: number): string {
  return toFaDigits(value.toLocaleString("en-US"));
}

export function formatPercent(value: number): string {
  return `${toFaDigits(value)}٪`;
}

export function discountPercent(price: number, oldPrice?: number): number {
  if (!oldPrice || oldPrice <= price) return 0;
  return Math.round(((oldPrice - price) / oldPrice) * 100);
}
