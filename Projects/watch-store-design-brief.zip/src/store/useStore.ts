import { create } from "zustand";
import { persist } from "zustand/middleware";
import { products } from "../data/products";
import type { Product } from "../data/types";

export interface CartLine {
  productId: string;
  colorId: string;
  qty: number;
}

export interface Toast {
  id: number;
  message: string;
  tone: "success" | "error" | "info";
}

interface StoreState {
  cart: CartLine[];
  wishlist: string[];
  compare: string[];
  searchHistory: string[];
  toasts: Toast[];
  addToCart: (productId: string, colorId: string, qty?: number) => void;
  removeFromCart: (productId: string, colorId: string) => void;
  setQty: (productId: string, colorId: string, qty: number) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  toggleCompare: (productId: string) => void;
  removeFromCompare: (productId: string) => void;
  clearCompare: () => void;
  addSearchHistory: (term: string) => void;
  clearSearchHistory: () => void;
  pushToast: (message: string, tone?: Toast["tone"]) => void;
  dismissToast: (id: number) => void;
}

let toastId = 0;

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      cart: [],
      wishlist: [],
      compare: [],
      searchHistory: [],
      toasts: [],

      addToCart: (productId, colorId, qty = 1) => {
        const cart = [...get().cart];
        const idx = cart.findIndex((l) => l.productId === productId && l.colorId === colorId);
        if (idx >= 0) {
          cart[idx] = { ...cart[idx], qty: cart[idx].qty + qty };
        } else {
          cart.push({ productId, colorId, qty });
        }
        set({ cart });
        get().pushToast("به سبد اضافه شد.", "success");
      },

      removeFromCart: (productId, colorId) => {
        set({ cart: get().cart.filter((l) => !(l.productId === productId && l.colorId === colorId)) });
      },

      setQty: (productId, colorId, qty) => {
        set({
          cart: get()
            .cart.map((l) => (l.productId === productId && l.colorId === colorId ? { ...l, qty: Math.max(1, qty) } : l)),
        });
      },

      clearCart: () => set({ cart: [] }),

      toggleWishlist: (productId) => {
        const exists = get().wishlist.includes(productId);
        set({
          wishlist: exists ? get().wishlist.filter((id) => id !== productId) : [...get().wishlist, productId],
        });
        get().pushToast(exists ? "از علاقه‌مندی‌ها حذف شد." : "به علاقه‌مندی‌ها اضافه شد.", "info");
      },

      toggleCompare: (productId) => {
        const cur = get().compare;
        if (cur.includes(productId)) {
          set({ compare: cur.filter((id) => id !== productId) });
          return;
        }
        if (cur.length >= 4) {
          get().pushToast("حداکثر ۴ محصول قابل مقایسه است.", "error");
          return;
        }
        set({ compare: [...cur, productId] });
        get().pushToast("به مقایسه اضافه شد.", "success");
      },

      removeFromCompare: (productId) => set({ compare: get().compare.filter((id) => id !== productId) }),
      clearCompare: () => set({ compare: [] }),

      addSearchHistory: (term) => {
        const t = term.trim();
        if (!t) return;
        const history = [t, ...get().searchHistory.filter((h) => h !== t)].slice(0, 8);
        set({ searchHistory: history });
      },
      clearSearchHistory: () => set({ searchHistory: [] }),

      pushToast: (message, tone = "info") => {
        const id = ++toastId;
        set({ toasts: [...get().toasts, { id, message, tone }] });
        setTimeout(() => get().dismissToast(id), 3200);
      },
      dismissToast: (id) => set({ toasts: get().toasts.filter((t) => t.id !== id) }),
    }),
    {
      name: "chronos-store",
      partialize: (state) => ({
        cart: state.cart,
        wishlist: state.wishlist,
        compare: state.compare,
        searchHistory: state.searchHistory,
      }),
    }
  )
);

export function getProduct(id: string): Product | undefined {
  return products.find((p) => p.id === id);
}

export function useCartDetails() {
  const cart = useStore((s) => s.cart);
  return cart
    .map((line) => {
      const product = getProduct(line.productId);
      if (!product) return null;
      const color = product.colors.find((c) => c.id === line.colorId) ?? product.colors[0];
      return { ...line, product, color };
    })
    .filter(Boolean) as { productId: string; colorId: string; qty: number; product: Product; color: Product["colors"][number] }[];
}
