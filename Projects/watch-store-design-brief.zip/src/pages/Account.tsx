import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Package, Heart, MapPin, MessageSquare, Plus, Trash2 } from "lucide-react";
import { useStore, getProduct } from "../store/useStore";
import { Breadcrumb } from "../components/ui/Breadcrumb";
import { ProductGrid } from "../components/product/ProductGrid";
import { EmptyState } from "../components/ui/States";
import { Button } from "../components/ui/Button";
import { PriceTag } from "../components/ui/PriceTag";
import { formatPrice, toFaDigits } from "../lib/format";
import { products } from "../data/products";
import { cn } from "../utils/cn";

const TABS = [
  { key: "orders", label: "سفارش‌ها", icon: Package },
  { key: "wishlist", label: "علاقه‌مندی‌ها", icon: Heart },
  { key: "addresses", label: "آدرس‌ها", icon: MapPin },
  { key: "reviews", label: "نظرات من", icon: MessageSquare },
] as const;

type TabKey = (typeof TABS)[number]["key"];

const MOCK_ORDERS = [
  { id: "1403-10234", date: "۱۴۰۳/۰۶/۱۰", status: "تحویل‌شده", total: products[0].price, items: [products[0], products[2]] },
  { id: "1403-10198", date: "۱۴۰۳/۰۵/۲۲", status: "در حال ارسال", total: products[6].price, items: [products[6]] },
];

export default function Account() {
  const [params, setParams] = useSearchParams();
  const tab = (params.get("tab") as TabKey) ?? "orders";
  const wishlist = useStore((s) => s.wishlist);
  const [addresses, setAddresses] = useState([
    { id: "a1", title: "خانه", detail: "تهران، خیابان ولیعصر، پلاک ۱۲" },
  ]);

  const wishlistProducts = wishlist.map((id) => getProduct(id)).filter(Boolean) as NonNullable<ReturnType<typeof getProduct>>[];

  function setTab(t: TabKey) {
    setParams({ tab: t });
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <Breadcrumb items={[{ label: "خانه", href: "/" }, { label: "حساب کاربری" }]} />
      <h1 className="mb-6 text-2xl font-semibold sm:text-3xl">حساب کاربری</h1>

      <div className="flex flex-col gap-8 lg:flex-row">
        <nav className="flex gap-2 overflow-x-auto no-scrollbar lg:w-56 lg:flex-col" aria-label="بخش‌های حساب کاربری">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-[12px] px-4 py-2.5 text-sm font-medium transition-colors",
                tab === t.key ? "bg-text text-bg" : "hover:bg-surface"
              )}
              aria-current={tab === t.key}
            >
              <t.icon size={16} />
              {t.label}
            </button>
          ))}
        </nav>

        <div className="flex-1">
          {tab === "orders" && (
            <div className="space-y-4">
              {MOCK_ORDERS.map((order) => (
                <div key={order.id} className="rounded-[18px] border border-border p-4">
                  <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-border pb-3">
                    <div>
                      <p className="text-sm font-medium">سفارش #{toFaDigits(order.id)}</p>
                      <p className="text-xs text-muted">{order.date}</p>
                    </div>
                    <span
                      className={cn(
                        "rounded-full px-3 py-1 text-xs font-medium",
                        order.status === "تحویل‌شده" ? "bg-success/10 text-success" : "bg-accent/10 text-accent"
                      )}
                    >
                      {order.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    {order.items.map((p) => (
                      <img key={p.id} src={p.images[0]} alt={p.name} className="h-14 w-14 rounded-[10px] object-cover" />
                    ))}
                    <div className="mr-auto text-start">
                      <p className="text-xs text-muted">مبلغ کل</p>
                      <p className="tabular font-semibold">{formatPrice(order.total)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === "wishlist" &&
            (wishlistProducts.length === 0 ? (
              <EmptyState
                icon={<Heart size={28} />}
                title="علاقه‌مندی‌ای ثبت نشده"
                message="محصولات مورد علاقه‌ات را اینجا نگه دار."
                ctaLabel="مشاهده‌ی محصولات"
                onCta={() => (window.location.href = "/category/all")}
              />
            ) : (
              <ProductGrid products={wishlistProducts} />
            ))}

          {tab === "addresses" && (
            <div className="space-y-3">
              {addresses.map((a) => (
                <div key={a.id} className="flex items-center justify-between rounded-[14px] border border-border p-4">
                  <div>
                    <p className="font-medium">{a.title}</p>
                    <p className="text-sm text-muted">{a.detail}</p>
                  </div>
                  <button
                    onClick={() => setAddresses(addresses.filter((x) => x.id !== a.id))}
                    aria-label={`حذف آدرس ${a.title}`}
                    className="text-muted hover:text-danger"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
              <Button
                variant="secondary"
                onClick={() =>
                  setAddresses([...addresses, { id: `a${addresses.length + 1}`, title: "آدرس جدید", detail: "در انتظار تکمیل" }])
                }
              >
                <Plus size={16} /> افزودن آدرس جدید
              </Button>
            </div>
          )}

          {tab === "reviews" && (
            <div className="space-y-4">
              {products[0].reviews.slice(0, 1).map((r) => (
                <div key={r.id} className="rounded-[14px] border border-border p-4">
                  <div className="mb-1 flex items-center justify-between">
                    <Link to={`/product/${products[0].slug}`} className="font-medium hover:text-accent">
                      {products[0].name}
                    </Link>
                    <span className="text-xs text-muted">{r.date}</span>
                  </div>
                  <PriceTag price={products[0].price} size="sm" />
                  <p className="mt-2 text-sm leading-7 text-muted">{r.body}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
