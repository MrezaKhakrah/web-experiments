import { Link, useNavigate } from "react-router-dom";
import { X, Scale } from "lucide-react";
import { useStore, getProduct } from "../store/useStore";
import { Breadcrumb } from "../components/ui/Breadcrumb";
import { PriceTag } from "../components/ui/PriceTag";
import { RatingStars } from "../components/ui/RatingStars";
import { EmptyState } from "../components/ui/States";
import { Button } from "../components/ui/Button";

export default function Compare() {
  const navigate = useNavigate();
  const compareIds = useStore((s) => s.compare);
  const removeFromCompare = useStore((s) => s.removeFromCompare);
  const items = compareIds.map((id) => getProduct(id)).filter(Boolean) as NonNullable<ReturnType<typeof getProduct>>[];

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <Breadcrumb items={[{ label: "خانه", href: "/" }, { label: "مقایسه" }]} />
        <EmptyState
          icon={<Scale size={28} />}
          title="چیزی برای مقایسه نیست"
          message="حداکثر ۴ محصول را برای مقایسه انتخاب کن."
          ctaLabel="مشاهده‌ی محصولات"
          onCta={() => navigate("/category/all")}
        />
      </div>
    );
  }

  const specKeys = Array.from(new Set(items.flatMap((p) => Object.keys(p.specs))));

  function isDifferent(key: string) {
    const values = items.map((p) => p.specs[key] ?? "—");
    return new Set(values).size > 1;
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <Breadcrumb items={[{ label: "خانه", href: "/" }, { label: "مقایسه" }]} />
      <h1 className="mb-6 text-2xl font-semibold sm:text-3xl">مقایسه‌ی محصولات</h1>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] border-collapse">
          <thead>
            <tr>
              <th className="sticky right-0 z-10 w-36 bg-bg p-3 text-start text-sm text-muted">ویژگی</th>
              {items.map((p) => (
                <th key={p.id} className="p-3 align-top">
                  <div className="relative rounded-[14px] border border-border p-3">
                    <button
                      onClick={() => removeFromCompare(p.id)}
                      aria-label={`حذف ${p.name}`}
                      className="absolute left-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-surface"
                    >
                      <X size={13} />
                    </button>
                    <img src={p.images[0]} alt={p.name} className="mx-auto h-24 w-24 rounded-[10px] object-cover" />
                    <Link to={`/product/${p.slug}`} className="mt-2 block text-sm font-medium hover:text-accent">
                      {p.name}
                    </Link>
                    <PriceTag price={p.price} oldPrice={p.oldPrice} size="sm" className="mt-1 justify-center" />
                    <RatingStars rating={p.rating} reviewCount={p.reviewCount} className="mt-1 justify-center" />
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {specKeys.map((key) => (
              <tr key={key} className="border-t border-border">
                <td className="sticky right-0 z-10 bg-bg p-3 text-sm font-medium text-muted">{key}</td>
                {items.map((p) => (
                  <td
                    key={p.id}
                    className={`p-3 text-center text-sm ${isDifferent(key) ? "bg-accent/5 font-semibold text-accent" : ""}`}
                  >
                    {p.specs[key] ?? "—"}
                  </td>
                ))}
              </tr>
            ))}
            <tr className="border-t border-border">
              <td className="sticky right-0 z-10 bg-bg p-3 text-sm font-medium text-muted">افزودن به سبد</td>
              {items.map((p) => (
                <td key={p.id} className="p-3 text-center">
                  <Link to={`/product/${p.slug}`}>
                    <Button size="sm">مشاهده</Button>
                  </Link>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
