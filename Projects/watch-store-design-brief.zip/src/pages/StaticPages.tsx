import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { Breadcrumb } from "../components/ui/Breadcrumb";
import { Button } from "../components/ui/Button";

function PageShell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <Breadcrumb items={[{ label: "خانه", href: "/" }, { label: title }]} />
      <h1 className="mb-6 text-2xl font-semibold sm:text-3xl">{title}</h1>
      <div className="space-y-4 leading-8 text-muted">{children}</div>
    </div>
  );
}

export function About() {
  return (
    <PageShell title="درباره‌ی کرونوس">
      <p>
        کرونوس از سال ۱۳۹۸ با یک هدف ساده شروع شد: دسترسی آسان به ساعت‌های اصل، با قیمت شفاف و خدمات پس از فروش قابل
        اعتماد. امروز بیش از ۲۰ برند لوکس، اسپرت و هوشمند را در یک فروشگاه گرد هم آورده‌ایم.
      </p>
      <p>
        تیم ما متشکل از کارشناسان ساعت، طراحان محصول و پشتیبانی مشتریانی است که هر روز برای تجربه‌ی بهتر خرید تو تلاش
        می‌کنند.
      </p>
      <p>زمان برای ما مهم است. برای تو هم همین‌طور.</p>
    </PageShell>
  );
}

export function Warranty() {
  return (
    <PageShell title="گارانتی">
      <p>تمام محصولات کرونوس با ۲۴ ماه گارانتی اصالت و سلامت فیزیکی عرضه می‌شوند.</p>
      <ul className="list-inside list-disc space-y-2">
        <li>گارانتی شامل خرابی‌های ناشی از ساخت است، نه ضربه یا آسیب فیزیکی.</li>
        <li>برای استفاده از گارانتی، فاکتور خرید و کارت گارانتی را نگه دار.</li>
        <li>زمان تعمیر یا تعویض حداکثر ۱۰ روز کاری است.</li>
      </ul>
    </PageShell>
  );
}

export function Returns() {
  return (
    <PageShell title="بازگشت کالا">
      <p>تا ۷ روز پس از دریافت کالا، در صورت عدم استفاده و سالم بودن بسته‌بندی، امکان بازگشت وجود دارد.</p>
      <ol className="list-inside list-decimal space-y-2">
        <li>درخواست بازگشت را از بخش «سفارش‌های من» ثبت کن.</li>
        <li>کالا را با بسته‌بندی اصلی ارسال کن.</li>
        <li>وجه ظرف ۳ روز کاری پس از تایید به حساب شما بازمی‌گردد.</li>
      </ol>
    </PageShell>
  );
}

export function Privacy() {
  return (
    <PageShell title="حریم خصوصی">
      <p>اطلاعات شخصی شما فقط برای پردازش سفارش و بهبود تجربه‌ی خرید استفاده می‌شود و با هیچ شخص ثالثی به اشتراک گذاشته نمی‌شود.</p>
      <p>برای حذف کامل اطلاعات حساب خود می‌توانی از بخش پشتیبانی درخواست بدهی.</p>
    </PageShell>
  );
}

export function NotFound() {
  return (
    <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-24 text-center sm:px-6">
      <span className="mb-4 text-7xl font-semibold tracking-[-0.02em]">۴۰۴</span>
      <h1 className="mb-2 text-xl font-semibold">این صفحه پیدا نشد</h1>
      <p className="mb-8 text-muted">شاید آدرس اشتباه بود. برگرد به خانه و دوباره بگرد.</p>
      <Link to="/">
        <Button>بازگشت به خانه</Button>
      </Link>
    </div>
  );
}
