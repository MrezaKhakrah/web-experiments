import { useEffect, useState } from "react";
import type { ChangeEvent, InputHTMLAttributes } from "react";
import { useNavigate } from "react-router-dom";
import { Check, MapPin, Truck, CreditCard, ShieldCheck } from "lucide-react";
import { useCartDetails, useStore } from "../store/useStore";
import { Breadcrumb } from "../components/ui/Breadcrumb";
import { Button } from "../components/ui/Button";
import { formatPrice } from "../lib/format";
import { cn } from "../utils/cn";

const STEPS = [
  { key: "address", label: "آدرس", icon: MapPin },
  { key: "shipping", label: "ارسال", icon: Truck },
  { key: "payment", label: "پرداخت", icon: CreditCard },
] as const;

type StepKey = (typeof STEPS)[number]["key"];

interface AddressForm {
  fullName: string;
  phone: string;
  province: string;
  city: string;
  address: string;
  postalCode: string;
}

const EMPTY_ADDRESS: AddressForm = { fullName: "", phone: "", province: "", city: "", address: "", postalCode: "" };

function validatePhone(v: string) {
  return /^09\d{9}$/.test(v);
}
function validatePostal(v: string) {
  return /^\d{10}$/.test(v);
}

export default function Checkout() {
  const navigate = useNavigate();
  const lines = useCartDetails();
  const clearCart = useStore((s) => s.clearCart);
  const [step, setStep] = useState<StepKey>("address");
  const [form, setForm] = useState<AddressForm>(EMPTY_ADDRESS);
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [shippingMethod, setShippingMethod] = useState<"express" | "standard">("standard");
  const [payment, setPayment] = useState<"online" | "cod">("online");
  const [placing, setPlacing] = useState(false);
  const [done, setDone] = useState(false);

  const subtotal = lines.reduce((sum, l) => sum + l.product.price * l.qty, 0);
  const shippingCost = shippingMethod === "express" ? 650000 : subtotal > 5000000 ? 0 : 350000;
  const total = subtotal + shippingCost;

  const errors = {
    fullName: form.fullName.trim().length < 3 ? "نام کامل را وارد کن" : "",
    phone: !validatePhone(form.phone) ? "شماره موبایل معتبر نیست" : "",
    province: !form.province ? "استان را انتخاب کن" : "",
    city: form.city.trim().length < 2 ? "نام شهر را وارد کن" : "",
    address: form.address.trim().length < 8 ? "آدرس کامل را بنویس" : "",
    postalCode: !validatePostal(form.postalCode) ? "کد پستی باید ۱۰ رقم باشد" : "",
  };
  const addressValid = Object.values(errors).every((e) => !e);

  function field<K extends keyof AddressForm>(key: K) {
    return {
      value: form[key],
      onChange: (e: ChangeEvent<HTMLInputElement>) => setForm({ ...form, [key]: e.target.value }),
      onBlur: () => setTouched({ ...touched, [key]: true }),
    };
  }

  function placeOrder() {
    setPlacing(true);
    setTimeout(() => {
      setPlacing(false);
      setDone(true);
      clearCart();
    }, 1200);
  }

  useEffect(() => {
    if (lines.length === 0 && !done) {
      navigate("/cart");
    }
  }, [lines.length, done, navigate]);

  if (lines.length === 0 && !done) {
    return null;
  }

  if (done) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center sm:px-6">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-success/10 text-success">
          <Check size={32} />
        </div>
        <h1 className="mb-2 text-2xl font-semibold">سفارش ثبت شد</h1>
        <p className="mb-8 leading-7 text-muted">
          کد پیگیری سفارش برای شماره {form.phone || "ثبت‌شده"} پیامک می‌شود. از خرید شما سپاسگزاریم.
        </p>
        <Button onClick={() => navigate("/")}>بازگشت به خانه</Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <Breadcrumb items={[{ label: "خانه", href: "/" }, { label: "سبد خرید", href: "/cart" }, { label: "تسویه‌حساب" }]} />

      {/* progress */}
      <ol className="mb-8 flex items-center">
        {STEPS.map((s, i) => {
          const stepIdx = STEPS.findIndex((x) => x.key === step);
          const state = i < stepIdx ? "done" : i === stepIdx ? "current" : "upcoming";
          return (
            <li key={s.key} className="flex flex-1 items-center">
              <div className="flex flex-col items-center gap-1.5">
                <div
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-full border-2 transition-colors",
                    state === "done" && "border-accent bg-accent text-white",
                    state === "current" && "border-accent text-accent",
                    state === "upcoming" && "border-border text-muted"
                  )}
                >
                  {state === "done" ? <Check size={18} /> : <s.icon size={17} />}
                </div>
                <span className={cn("text-xs font-medium", state === "upcoming" ? "text-muted" : "text-text")}>{s.label}</span>
              </div>
              {i < STEPS.length - 1 && (
                <div className={cn("mx-2 h-0.5 flex-1", i < stepIdx ? "bg-accent" : "bg-border")} />
              )}
            </li>
          );
        })}
      </ol>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          {step === "address" && (
            <div className="space-y-4 rounded-[18px] border border-border p-5">
              <h2 className="font-semibold">اطلاعات گیرنده (مهمان مجاز است)</h2>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <TextField label="نام و نام خانوادگی" error={touched.fullName ? errors.fullName : ""} {...field("fullName")} />
                <TextField label="شماره موبایل" dir="ltr" placeholder="09xxxxxxxxx" error={touched.phone ? errors.phone : ""} {...field("phone")} />
                <TextField label="استان" error={touched.province ? errors.province : ""} {...field("province")} />
                <TextField label="شهر" error={touched.city ? errors.city : ""} {...field("city")} />
                <TextField label="کد پستی" dir="ltr" error={touched.postalCode ? errors.postalCode : ""} {...field("postalCode")} />
              </div>
              <TextField label="آدرس کامل" error={touched.address ? errors.address : ""} {...field("address")} />
              <Button
                className="w-full sm:w-auto"
                onClick={() => {
                  setTouched({ fullName: true, phone: true, province: true, city: true, address: true, postalCode: true });
                  if (addressValid) setStep("shipping");
                }}
              >
                ادامه به روش ارسال
              </Button>
            </div>
          )}

          {step === "shipping" && (
            <div className="space-y-4 rounded-[18px] border border-border p-5">
              <h2 className="font-semibold">روش ارسال</h2>
              {[
                { key: "standard", title: "ارسال استاندارد", desc: "۳ تا ۵ روز کاری", price: subtotal > 5000000 ? 0 : 350000 },
                { key: "express", title: "ارسال اکسپرس", desc: "یک روز کاری", price: 650000 },
              ].map((opt) => (
                <label
                  key={opt.key}
                  className={cn(
                    "flex cursor-pointer items-center justify-between rounded-[14px] border p-4 transition-colors",
                    shippingMethod === opt.key ? "border-accent bg-accent/5" : "border-border"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="shipping"
                      checked={shippingMethod === opt.key}
                      onChange={() => setShippingMethod(opt.key as "standard" | "express")}
                      className="h-4 w-4 accent-[#0071e3]"
                    />
                    <div>
                      <p className="font-medium">{opt.title}</p>
                      <p className="text-xs text-muted">{opt.desc}</p>
                    </div>
                  </div>
                  <span className="tabular text-sm font-semibold">{opt.price === 0 ? "رایگان" : formatPrice(opt.price)}</span>
                </label>
              ))}
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => setStep("address")}>
                  بازگشت
                </Button>
                <Button onClick={() => setStep("payment")}>ادامه به پرداخت</Button>
              </div>
            </div>
          )}

          {step === "payment" && (
            <div className="space-y-4 rounded-[18px] border border-border p-5">
              <h2 className="font-semibold">روش پرداخت</h2>
              {[
                { key: "online", title: "پرداخت آنلاین", desc: "اتصال مستقیم به درگاه بانکی" },
                { key: "cod", title: "پرداخت در محل", desc: "پرداخت نقدی یا کارت‌خوان هنگام تحویل" },
              ].map((opt) => (
                <label
                  key={opt.key}
                  className={cn(
                    "flex cursor-pointer items-center gap-3 rounded-[14px] border p-4 transition-colors",
                    payment === opt.key ? "border-accent bg-accent/5" : "border-border"
                  )}
                >
                  <input
                    type="radio"
                    name="payment"
                    checked={payment === opt.key}
                    onChange={() => setPayment(opt.key as "online" | "cod")}
                    className="h-4 w-4 accent-[#0071e3]"
                  />
                  <div>
                    <p className="font-medium">{opt.title}</p>
                    <p className="text-xs text-muted">{opt.desc}</p>
                  </div>
                </label>
              ))}
              <p className="flex items-center gap-1.5 text-xs text-muted">
                <ShieldCheck size={14} className="text-success" /> پرداخت شما با رمزنگاری کامل محافظت می‌شود.
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => setStep("shipping")}>
                  بازگشت
                </Button>
                <Button onClick={placeOrder} loading={placing}>
                  {placing ? "در حال ثبت سفارش…" : "ثبت نهایی سفارش"}
                </Button>
              </div>
            </div>
          )}
        </div>

        <aside className="h-fit space-y-3 rounded-[18px] border border-border p-5">
          <h2 className="font-semibold">خلاصه‌ی سفارش</h2>
          <ul className="space-y-2 text-sm">
            {lines.map((l) => (
              <li key={l.productId + l.colorId} className="flex justify-between">
                <span className="text-muted">
                  {l.product.name} × {l.qty}
                </span>
                <span className="tabular">{formatPrice(l.product.price * l.qty)}</span>
              </li>
            ))}
          </ul>
          <div className="space-y-1.5 border-t border-border pt-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted">جمع کالاها</span>
              <span className="tabular">{formatPrice(subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted">هزینه‌ی ارسال</span>
              <span className="tabular">{shippingCost === 0 ? "رایگان" : formatPrice(shippingCost)}</span>
            </div>
            <div className="flex justify-between border-t border-border pt-2 text-base font-semibold">
              <span>مبلغ نهایی</span>
              <span className="tabular">{formatPrice(total)}</span>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function TextField({
  label,
  error,
  ...rest
}: { label: string; error?: string } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label className="mb-1 block text-sm text-muted">{label}</label>
      <input
        {...rest}
        aria-invalid={!!error}
        className={cn(
          "w-full rounded-[12px] border bg-bg px-3 py-2.5 text-sm outline-none transition-colors",
          error ? "border-danger" : "border-border focus:border-accent"
        )}
      />
      {error && <p className="mt-1 text-xs text-danger">{error}</p>}
    </div>
  );
}
