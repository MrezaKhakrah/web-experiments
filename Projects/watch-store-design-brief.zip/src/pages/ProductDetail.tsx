import { useMemo, useState } from "react";
import { Link, useParams, Navigate } from "react-router-dom";
import {
  Heart,
  Scale,
  ShoppingBag,
  ShieldCheck,
  Truck,
  RotateCcw,
  BadgeCheck,
  RefreshCw,
  ChevronDown,
  ZoomIn,
} from "lucide-react";
import { getProductBySlug, relatedProducts } from "../data/products";
import { useStore } from "../store/useStore";
import { Breadcrumb } from "../components/ui/Breadcrumb";
import { PriceTag } from "../components/ui/PriceTag";
import { RatingStars } from "../components/ui/RatingStars";
import { Button } from "../components/ui/Button";
import { ProductGrid } from "../components/product/ProductGrid";
import { formatNumber, toFaDigits } from "../lib/format";
import { cn } from "../utils/cn";
import { categoryTitles } from "../data/categories";

const trustItems = [
  { icon: BadgeCheck, label: "ضمانت اصالت کالا" },
  { icon: ShieldCheck, label: "۲۴ ماه گارانتی" },
  { icon: RotateCcw, label: "۷ روز ضمانت بازگشت" },
  { icon: Truck, label: "ارسال رایگان" },
];

type TabKey = "specs" | "reviews" | "qna" | "size";

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const product = slug ? getProductBySlug(slug) : undefined;

  const [colorIdx, setColorIdx] = useState(0);
  const [imgIdx, setImgIdx] = useState(0);
  const [qty, setQty] = useState(1);
  const [tab, setTab] = useState<TabKey>("specs");
  const [rotate, setRotate] = useState(false);
  const [zoomPos, setZoomPos] = useState({ x: 50, y: 50 });
  const [zooming, setZooming] = useState(false);

  const wishlist = useStore((s) => s.wishlist);
  const compare = useStore((s) => s.compare);
  const toggleWishlist = useStore((s) => s.toggleWishlist);
  const toggleCompare = useStore((s) => s.toggleCompare);
  const addToCart = useStore((s) => s.addToCart);

  const related = useMemo(() => (product ? relatedProducts(product) : []), [product]);

  if (!product) return <Navigate to="/404" replace />;

  const color = product.colors[colorIdx];
  const images = [color.image, ...product.images.filter((i) => i !== color.image)];
  const isWished = wishlist.includes(product.id);
  const isCompared = compare.includes(product.id);
  const outOfStock = product.stock <= 0;
  const lowStock = product.stock > 0 && product.stock <= 5;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <Breadcrumb
        items={[
          { label: "خانه", href: "/" },
          { label: categoryTitles[product.category], href: `/category/${product.category}` },
          { label: product.name },
        ]}
      />

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
        {/* Gallery */}
        <div>
          <div
            className="relative mb-3 aspect-square cursor-zoom-in overflow-hidden rounded-[18px] bg-surface"
            onMouseMove={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              setZoomPos({ x: ((e.clientX - rect.left) / rect.width) * 100, y: ((e.clientY - rect.top) / rect.height) * 100 });
            }}
            onMouseEnter={() => setZooming(true)}
            onMouseLeave={() => setZooming(false)}
          >
            <img
              src={images[imgIdx]}
              alt={`${product.brand} ${product.name} - تصویر ${toFaDigits(imgIdx + 1)}`}
              className={cn(
                "h-full w-full object-cover transition-transform duration-300",
                rotate && "motion-safe:animate-[spin_3s_linear_infinite]"
              )}
              style={
                zooming
                  ? { transform: "scale(1.8)", transformOrigin: `${zoomPos.x}% ${zoomPos.y}%` }
                  : undefined
              }
            />
            <button
              onClick={() => setRotate((r) => !r)}
              className="absolute bottom-3 right-3 flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-1.5 text-xs font-medium text-white"
            >
              <RefreshCw size={13} className={rotate ? "animate-spin" : ""} />
              نمای ۳۶۰ درجه
            </button>
            <span className="absolute bottom-3 left-3 flex items-center gap-1 rounded-full bg-black/70 px-2 py-1 text-[11px] text-white">
              <ZoomIn size={12} /> برای زوم اشاره کن
            </span>
          </div>
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {images.map((img, i) => (
              <button
                key={img + i}
                onClick={() => setImgIdx(i)}
                aria-label={`تصویر ${toFaDigits(i + 1)}`}
                aria-pressed={imgIdx === i}
                className={cn(
                  "h-16 w-16 shrink-0 overflow-hidden rounded-[10px] border-2",
                  imgIdx === i ? "border-accent" : "border-transparent"
                )}
              >
                <img src={img} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Buy column */}
        <div>
          <Link to={`/category/${product.category}`} className="text-sm font-medium text-accent hover:underline">
            {product.brand}
          </Link>
          <h1 className="mt-1 text-2xl font-semibold sm:text-3xl">{product.name}</h1>
          <div className="mt-2">
            <RatingStars rating={product.rating} reviewCount={product.reviewCount} />
          </div>

          <div className="mt-5">
            <PriceTag price={product.price} oldPrice={product.oldPrice} size="lg" />
          </div>

          <p className="mt-2 text-sm">
            {outOfStock ? (
              <span className="font-medium text-danger">ناموجود</span>
            ) : lowStock ? (
              <span className="font-medium text-danger">فقط {toFaDigits(product.stock)} عدد باقی مانده</span>
            ) : (
              <span className="font-medium text-success">موجود در انبار</span>
            )}
          </p>

          <div className="mt-6">
            <span className="mb-2 block text-sm font-medium">رنگ: {color.name}</span>
            <div className="flex items-center gap-2">
              {product.colors.map((c, i) => (
                <button
                  key={c.id}
                  onClick={() => setColorIdx(i)}
                  aria-pressed={colorIdx === i}
                  aria-label={c.name}
                  title={c.name}
                  className={cn(
                    "h-9 w-9 rounded-full border-2 transition-transform",
                    colorIdx === i ? "scale-110 border-accent" : "border-border"
                  )}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
            {Object.entries({ "موتور": product.movement, "بند": product.strap, "قاب": `${product.caseSize} میلی‌متر` }).map(([k, v]) => (
              <div key={k} className="rounded-[12px] border border-border px-3 py-2 text-center">
                <p className="text-xs text-muted">{k}</p>
                <p className="font-medium">{v}</p>
              </div>
            ))}
          </div>

          <div className="mt-7 flex items-center gap-3">
            <div className="flex items-center gap-3 rounded-full border border-border px-3 py-2">
              <button
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                aria-label="کم کردن تعداد"
                className="flex h-6 w-6 items-center justify-center text-lg disabled:opacity-30"
                disabled={qty <= 1}
              >
                −
              </button>
              <span className="tabular w-5 text-center">{toFaDigits(qty)}</span>
              <button
                onClick={() => setQty((q) => Math.min(product.stock, q + 1))}
                aria-label="افزودن تعداد"
                className="flex h-6 w-6 items-center justify-center text-lg"
              >
                +
              </button>
            </div>
            <Button
              className="flex-1"
              size="lg"
              disabled={outOfStock}
              onClick={() => addToCart(product.id, color.id, qty)}
            >
              <ShoppingBag size={18} aria-hidden="true" />
              {outOfStock ? "ناموجود" : "افزودن به سبد"}
            </Button>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <Button variant="secondary" className="flex-1" onClick={() => toggleWishlist(product.id)}>
              <Heart size={16} className={isWished ? "fill-danger text-danger" : ""} />
              {isWished ? "در علاقه‌مندی‌ها" : "افزودن به علاقه‌مندی"}
            </Button>
            <Button variant="secondary" className="flex-1" onClick={() => toggleCompare(product.id)}>
              <Scale size={16} className={isCompared ? "text-accent" : ""} />
              {isCompared ? "در مقایسه" : "افزودن به مقایسه"}
            </Button>
          </div>

          <div className="mt-8 grid grid-cols-2 gap-4 rounded-[18px] bg-surface p-4 sm:grid-cols-4">
            {trustItems.map((t) => (
              <div key={t.label} className="flex flex-col items-center gap-1.5 text-center">
                <t.icon size={20} className="text-accent" aria-hidden="true" />
                <span className="text-xs leading-5 text-muted">{t.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-14">
        <div className="flex gap-1 overflow-x-auto border-b border-border no-scrollbar" role="tablist">
          {(
            [
              ["specs", "مشخصات"],
              ["reviews", `نظرات (${formatNumber(product.reviews.length)})`],
              ["qna", `پرسش و پاسخ (${formatNumber(product.qna.length)})`],
              ["size", "راهنمای سایز"],
            ] as [TabKey, string][]
          ).map(([key, label]) => (
            <button
              key={key}
              role="tab"
              aria-selected={tab === key}
              onClick={() => setTab(key)}
              className={cn(
                "shrink-0 border-b-2 px-4 py-3 text-sm font-medium transition-colors",
                tab === key ? "border-text text-text" : "border-transparent text-muted hover:text-text"
              )}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="py-6">
          {tab === "specs" && (
            <div>
              <p className="mb-6 max-w-2xl leading-8 text-muted">{product.description}</p>
              <dl className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
                {Object.entries(product.specs).map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between border-b border-border py-2 text-sm">
                    <dt className="text-muted">{k}</dt>
                    <dd className="font-medium">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}

          {tab === "reviews" && (
            <div className="space-y-5">
              {product.reviews.length === 0 ? (
                <p className="text-sm text-muted">هنوز نظری ثبت نشده. اولین نفر باش.</p>
              ) : (
                product.reviews.map((r) => (
                  <div key={r.id} className="border-b border-border pb-5">
                    <div className="mb-1 flex items-center justify-between">
                      <span className="font-medium">{r.author}</span>
                      <span className="text-xs text-muted">{r.date}</span>
                    </div>
                    <RatingStars rating={r.rating} showNumber={false} />
                    <p className="mt-2 font-medium">{r.title}</p>
                    <p className="mt-1 leading-7 text-muted">{r.body}</p>
                    <div className="mt-2 flex items-center gap-3 text-xs text-muted">
                      {r.verified && <span className="text-success">خرید تایید‌شده</span>}
                      <span>{toFaDigits(r.helpful)} نفر این نظر را مفید دانستند</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {tab === "qna" && (
            <div className="space-y-4">
              {product.qna.map((q) => (
                <details key={q.id} className="group rounded-[14px] border border-border p-4">
                  <summary className="flex cursor-pointer list-none items-center justify-between font-medium">
                    {q.question}
                    <ChevronDown size={16} className="transition-transform group-open:rotate-180" />
                  </summary>
                  {q.answer && <p className="mt-2 leading-7 text-muted">{q.answer}</p>}
                  <p className="mt-2 text-xs text-muted">{q.date}</p>
                </details>
              ))}
            </div>
          )}

          {tab === "size" && (
            <div className="max-w-2xl space-y-3 text-sm leading-8 text-muted">
              <p>اندازه‌ی مچ خود را با متر نواری اندازه بگیر و بر اساس جدول زیر قطر قاب مناسب را انتخاب کن:</p>
              <table className="w-full border-collapse overflow-hidden rounded-[12px] border border-border text-start">
                <thead className="bg-surface text-text">
                  <tr>
                    <th className="px-3 py-2 text-start">دور مچ</th>
                    <th className="px-3 py-2 text-start">قطر پیشنهادی</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ["۱۴ تا ۱۶ سانتی‌متر", "۳۶ تا ۳۸ میلی‌متر"],
                    ["۱۶ تا ۱۸ سانتی‌متر", "۴۰ تا ۴۲ میلی‌متر"],
                    ["۱۸ تا ۲۰ سانتی‌متر", "۴۲ تا ۴۴ میلی‌متر"],
                    ["۲۰ سانتی‌متر به بالا", "۴۴ میلی‌متر به بالا"],
                  ].map((row) => (
                    <tr key={row[0]} className="border-t border-border">
                      <td className="px-3 py-2">{row[0]}</td>
                      <td className="px-3 py-2">{row[1]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Related */}
      {related.length > 0 && (
        <section className="mt-14">
          <h2 className="mb-5 text-xl font-semibold sm:text-2xl">مشابه‌ها</h2>
          <ProductGrid products={related} />
        </section>
      )}
    </div>
  );
}
