import { useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { LayoutGrid, List, SlidersHorizontal, X } from "lucide-react";
import { products } from "../data/products";
import { categoryTitles } from "../data/categories";
import { Breadcrumb } from "../components/ui/Breadcrumb";
import { ProductGrid } from "../components/product/ProductGrid";
import { FilterSidebar, EMPTY_FILTERS, type Filters } from "../components/product/FilterSidebar";
import { BottomSheet } from "../components/ui/BottomSheet";
import { Chip } from "../components/ui/Chip";
import { Button } from "../components/ui/Button";
import { formatPrice, formatNumber } from "../lib/format";
import type { ProductCategory } from "../data/types";

type SortKey = "popular" | "newest" | "price-asc" | "price-desc" | "rating";

const SORT_LABELS: Record<SortKey, string> = {
  popular: "محبوب‌ترین",
  newest: "جدیدترین",
  "price-asc": "ارزان‌ترین",
  "price-desc": "گران‌ترین",
  rating: "بالاترین امتیاز",
};

export default function CategoryListing() {
  const { slug } = useParams<{ slug: string }>();
  const category = (slug ?? "all") as ProductCategory | "all";

  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const [sort, setSort] = useState<SortKey>("popular");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [sheetOpen, setSheetOpen] = useState(false);
  const [loading] = useState(false);

  const baseProducts = useMemo(
    () => (category === "all" ? products : products.filter((p) => p.category === category)),
    [category]
  );

  const facets = useMemo(() => {
    const brands = Array.from(new Set(baseProducts.map((p) => p.brand)));
    const straps = Array.from(new Set(baseProducts.map((p) => p.strap)));
    const movements = Array.from(new Set(baseProducts.map((p) => p.movement)));
    const sizes = Array.from(new Set(baseProducts.map((p) => p.caseSize))).sort((a, b) => a - b);
    const colorMap = new Map<string, string>();
    baseProducts.forEach((p) => p.colors.forEach((c) => colorMap.set(c.name, c.hex)));
    const colors = Array.from(colorMap, ([name, hex]) => ({ name, hex }));
    return { brands, straps, movements, sizes, colors };
  }, [baseProducts]);

  const filtered = useMemo(() => {
    let list = baseProducts.filter((p) => {
      if (filters.brands.length && !filters.brands.includes(p.brand)) return false;
      if (filters.straps.length && !filters.straps.includes(p.strap)) return false;
      if (filters.movements.length && !filters.movements.includes(p.movement)) return false;
      if (filters.sizes.length && !filters.sizes.includes(p.caseSize)) return false;
      if (filters.colors.length && !p.colors.some((c) => filters.colors.includes(c.name))) return false;
      if (filters.minRating && p.rating < filters.minRating) return false;
      if (p.price > filters.priceMax) return false;
      return true;
    });

    switch (sort) {
      case "newest":
        list = [...list].sort((a, b) => Number(b.isNew) - Number(a.isNew));
        break;
      case "price-asc":
        list = [...list].sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list = [...list].sort((a, b) => b.price - a.price);
        break;
      case "rating":
        list = [...list].sort((a, b) => b.rating - a.rating);
        break;
      default:
        list = [...list].sort((a, b) => b.reviewCount - a.reviewCount);
    }
    return list;
  }, [baseProducts, filters, sort]);

  const activeChips: { key: string; label: string; clear: () => void }[] = [
    ...filters.brands.map((b) => ({ key: `b-${b}`, label: b, clear: () => setFilters({ ...filters, brands: filters.brands.filter((x) => x !== b) }) })),
    ...filters.straps.map((s) => ({ key: `s-${s}`, label: s, clear: () => setFilters({ ...filters, straps: filters.straps.filter((x) => x !== s) }) })),
    ...filters.movements.map((m) => ({ key: `m-${m}`, label: m, clear: () => setFilters({ ...filters, movements: filters.movements.filter((x) => x !== m) }) })),
    ...filters.sizes.map((sz) => ({ key: `sz-${sz}`, label: `${sz} میلی‌متر`, clear: () => setFilters({ ...filters, sizes: filters.sizes.filter((x) => x !== sz) }) })),
    ...filters.colors.map((c) => ({ key: `c-${c}`, label: c, clear: () => setFilters({ ...filters, colors: filters.colors.filter((x) => x !== c) }) })),
    ...(filters.minRating ? [{ key: "rating", label: `${filters.minRating}★ و بالاتر`, clear: () => setFilters({ ...filters, minRating: 0 }) }] : []),
  ];

  const title = categoryTitles[category] ?? "همه‌ی ساعت‌ها";

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <Breadcrumb items={[{ label: "خانه", href: "/" }, { label: title }]} />
      <h1 className="mb-6 text-2xl font-semibold sm:text-3xl">{title}</h1>

      <div className="flex gap-8">
        <aside className="hidden w-64 shrink-0 lg:block">
          <FilterSidebar filters={filters} onChange={setFilters} facets={facets} />
        </aside>

        <div className="min-w-0 flex-1">
          {/* Toolbar */}
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-border pb-4">
            <p className="tabular text-sm text-muted">{formatNumber(filtered.length)} نتیجه</p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSheetOpen(true)}
                className="flex items-center gap-1.5 rounded-full border border-border px-3 py-2 text-sm font-medium lg:hidden"
              >
                <SlidersHorizontal size={15} /> فیلترها
              </button>
              <label className="sr-only" htmlFor="sort">
                مرتب‌سازی
              </label>
              <select
                id="sort"
                value={sort}
                onChange={(e) => setSort(e.target.value as SortKey)}
                className="rounded-full border border-border bg-bg px-3 py-2 text-sm"
              >
                {Object.entries(SORT_LABELS).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
              <div className="hidden items-center gap-1 rounded-full border border-border p-1 sm:flex">
                <button
                  onClick={() => setView("grid")}
                  aria-pressed={view === "grid"}
                  aria-label="نمایش شبکه‌ای"
                  className={`flex h-7 w-7 items-center justify-center rounded-full ${view === "grid" ? "bg-text text-bg" : ""}`}
                >
                  <LayoutGrid size={14} />
                </button>
                <button
                  onClick={() => setView("list")}
                  aria-pressed={view === "list"}
                  aria-label="نمایش فهرستی"
                  className={`flex h-7 w-7 items-center justify-center rounded-full ${view === "list" ? "bg-text text-bg" : ""}`}
                >
                  <List size={14} />
                </button>
              </div>
            </div>
          </div>

          {activeChips.length > 0 && (
            <div className="mb-4 flex flex-wrap items-center gap-2">
              {activeChips.map((c) => (
                <Chip key={c.key} active onClick={c.clear}>
                  {c.label} <X size={13} />
                </Chip>
              ))}
              <button onClick={() => setFilters(EMPTY_FILTERS)} className="text-xs font-medium text-accent hover:underline">
                پاک کردن همه
              </button>
            </div>
          )}

          <ProductGrid products={filtered} view={view} loading={loading} />
        </div>
      </div>

      <BottomSheet
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        title="فیلترها"
        footer={
          <div className="flex gap-2">
            <Button variant="secondary" className="flex-1" onClick={() => setFilters(EMPTY_FILTERS)}>
              حذف فیلترها
            </Button>
            <Button className="flex-1" onClick={() => setSheetOpen(false)}>
              نمایش {formatNumber(filtered.length)} نتیجه
            </Button>
          </div>
        }
      >
        <FilterSidebar filters={filters} onChange={setFilters} facets={facets} />
      </BottomSheet>
    </div>
  );
}

export function priceLabel(v: number) {
  return formatPrice(v);
}
