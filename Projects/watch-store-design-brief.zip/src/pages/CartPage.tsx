import { useState } from "react";
import { Link } from "react-router-dom";
import { Minus, Plus, Trash2, ShoppingBag, Tag } from "lucide-react";
import { useCartDetails, useStore } from "../store/useStore";
import { Breadcrumb } from "../components/ui/Breadcrumb";
import { EmptyState } from "../components/ui/States";
import { Button } from "../components/ui/Button";
import { formatPrice, toFaDigits } from "../lib/format";

const VALID_CODES: Record<string, number> = { CHRONOS10: 0.1, WELCOME5: 0.05 };

export default function CartPage() {
  const lines = useCartDetails();
  const setQty = useStore((s) => s.setQty);
  const removeFromCart = useStore((s) => s.removeFromCart);
  const [code, setCode] = useState("");
  const [applied, setApplied] = useState<{ code: string; percent: number } | null>(null);
  const [codeState, setCodeState] = useState<"idle" | "invalid">("idle");

  const subtotal = lines.reduce((sum, l) => sum + l.product.price * l.qty, 0);
  const discount = applied ? Math.round(subtotal * applied.percent) : 0;
  const shipping = subtotal > 0 && subtotal < 5000000 ? 350000 : 0;
  const total = subtotal - discount + shipping;

  function applyCode(e: React.FormEvent) {
    e.preventDefault();
    const normalized = code.trim().toUpperCase();
    if (VALID_CODES[normalized]) {
      setApplied({ code: normalized, percent: VALID_CODES[normalized] });
      setCodeState("idle");
    } else {
      setApplied(null);
      setCodeState("invalid");
    }
  }

  if (lines.length === 0) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <Breadcrumb items={[{ label: "خانه", href: "/" }, { label: "سبد خرید" }]} />
        <EmptyState
          icon={<ShoppingBag size={28} />}
          title="سبدت خالی است"
          message="یک ساعت خوب انتخاب کنیم؟"
          ctaLabel="مشاهده‌ی محصولات"
          onCta={() => (window.location.href = "/category/all")}
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <Breadcrumb items={[{ label: "خانه", href: "/" }, { label: "سبد خرید" }]} />
      <h1 className="mb-6 text-2xl font-semibold sm:text-3xl">سبد خرید</h1>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          {lines.map((l) => (
            <div key={l.productId + l.colorId} className="flex gap-4 rounded-[18px] border border-border p-4">
              <img src={l.color.image} alt={l.product.name} className="h-24 w-24 shrink-0 rounded-[14px] object-cover" />
              <div className="flex flex-1 flex-col">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <Link to={`/product/${l.product.slug}`} className="font-medium hover:text-accent">
                      {l.product.name}
                    </Link>
                    <p className="text-sm text-muted">
                      {l.product.brand} · رنگ: {l.color.name}
                    </p>
                  </div>
                  <button
                    onClick={() => removeFromCart(l.productId, l.colorId)}
                    aria-label={`حذف ${l.product.name}`}
                    className="text-muted hover:text-danger"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                <div className="mt-auto flex items-center justify-between pt-3">
                  <div className="flex items-center gap-3 rounded-full border border-border px-3 py-1.5">
                    <button
                      onClick={() => setQty(l.productId, l.colorId, l.qty - 1)}
                      disabled={l.qty <= 1}
                      aria-label="کم کردن تعداد"
                      className="disabled:opacity-30"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="tabular w-5 text-center text-sm">{toFaDigits(l.qty)}</span>
                    <button onClick={() => setQty(l.productId, l.colorId, l.qty + 1)} aria-label="افزودن تعداد">
                      <Plus size={14} />
                    </button>
                  </div>
                  <span className="tabular font-semibold">{formatPrice(l.product.price * l.qty)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <aside className="h-fit space-y-4 rounded-[18px] border border-border p-5">
          <h2 className="font-semibold">خلاصه‌ی سفارش</h2>

          <form onSubmit={applyCode} className="space-y-1.5">
            <label htmlFor="discount-code" className="text-sm text-muted">
              کد تخفیف
            </label>
            <div className="flex gap-2">
              <input
                id="discount-code"
                value={code}
                onChange={(e) => {
                  setCode(e.target.value);
                  setCodeState("idle");
                }}
                placeholder="مثلاً CHRONOS10"
                className="flex-1 rounded-[12px] border border-border bg-bg px-3 py-2 text-sm outline-none focus:border-accent"
              />
              <Button type="submit" variant="secondary" size="sm">
                <Tag size={14} /> اعمال
              </Button>
            </div>
            {codeState === "invalid" && <p className="text-xs text-danger">کد تخفیف معتبر نیست.</p>}
            {applied && <p className="text-xs text-success">کد «{applied.code}» اعمال شد.</p>}
          </form>

          <div className="space-y-2 border-t border-border pt-4 text-sm">
            <div className="flex justify-between">
              <span className="text-muted">جمع کالاها</span>
              <span className="tabular">{formatPrice(subtotal)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-success">
                <span>تخفیف</span>
                <span className="tabular">−{formatPrice(discount)}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-muted">هزینه‌ی ارسال</span>
              <span className="tabular">{shipping === 0 ? "رایگان" : formatPrice(shipping)}</span>
            </div>
            <div className="flex justify-between border-t border-border pt-2 text-base font-semibold">
              <span>مبلغ قابل پرداخت</span>
              <span className="tabular">{formatPrice(total)}</span>
            </div>
          </div>

          <Link to="/checkout">
            <Button className="w-full" size="lg">
              ادامه‌ی خرید
            </Button>
          </Link>
        </aside>
      </div>
    </div>
  );
}
