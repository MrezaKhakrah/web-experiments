import { Link } from "react-router-dom";
import { useMemo } from "react";
import { ArrowLeft, Clock3 } from "lucide-react";
import { products } from "../data/products";
import { brands } from "../data/brands";
import { blogPosts } from "../data/blog";
import { categoryChips } from "../data/categories";
import { ProductCard } from "../components/product/ProductCard";
import { Carousel } from "../components/product/Carousel";
import { ProductGrid } from "../components/product/ProductGrid";
import { CountdownTimer } from "../components/ui/CountdownTimer";
import { PriceTag } from "../components/ui/PriceTag";
import { Chip } from "../components/ui/Chip";
import { Button } from "../components/ui/Button";

export default function Home() {
  const newProducts = useMemo(() => products.filter((p) => p.isNew), []);
  const bestSellers = useMemo(() => products.filter((p) => p.isBestSeller).slice(0, 8), []);
  const deals = useMemo(() => products.filter((p) => p.isDeal), []);
  const heroDeal = deals[0];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-black text-white">
        <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-8 px-4 py-16 sm:px-6 sm:py-24 lg:grid-cols-2">
          <div className="order-2 space-y-5 text-center lg:order-1 lg:text-start">
            <span className="inline-block rounded-full border border-white/20 px-3 py-1 text-xs text-white/70">
              مجموعه‌ی پاییز ۱۴۰۳
            </span>
            <h1 className="text-4xl font-semibold leading-tight tracking-[-0.02em] sm:text-6xl">
              زمان، دقیق‌تر
              <br />
              از همیشه.
            </h1>
            <p className="mx-auto max-w-md text-base leading-8 text-white/70 lg:mx-0">
              ساعتی که با تو حرکت می‌کند. از لوکس‌ترین مکانیزم‌های اتوماتیک تا هوشمندترین دستیار مچی.
            </p>
            <div className="flex flex-col items-center gap-3 sm:flex-row lg:justify-start">
              <Link to="/category/luxury">
                <Button size="lg">مشاهده‌ی کلکسیون</Button>
              </Link>
              <Link to="/product/meridian-1" className="text-sm font-medium text-white underline underline-offset-4 hover:text-white/80">
                معرفی مریدین هریتج گلد
              </Link>
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <img
              src="/images/hero-watch.jpg"
              alt="ساعت لوکس کرونوس روی پس‌زمینه‌ی تیره"
              className="mx-auto aspect-[4/5] w-full max-w-md rounded-[28px] object-cover motion-safe:animate-fade-up"
              fetchPriority="high"
            />
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl space-y-16 px-4 py-14 sm:px-6">
        {/* Category chips */}
        <section aria-label="دسته‌بندی‌ها">
          <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
            {categoryChips.map((c) => (
              <Link key={c.slug} to={c.slug === "all" ? "/category/all" : `/category/${c.slug}`}>
                <Chip>
                  <span aria-hidden="true">{c.emoji}</span> {c.title}
                </Chip>
              </Link>
            ))}
          </div>
        </section>

        {/* New arrivals */}
        <section aria-labelledby="new-heading">
          <Carousel title="تازه‌ها">
            {newProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </Carousel>
        </section>

        {/* Best sellers */}
        <section aria-labelledby="best-heading">
          <div className="mb-4 flex items-center justify-between">
            <h2 id="best-heading" className="text-xl font-semibold sm:text-2xl">
              پرفروش‌ها
            </h2>
            <Link to="/category/all" className="flex items-center gap-1 text-sm font-medium text-accent">
              مشاهده‌ی همه
              <ArrowLeft size={14} className="rtl:rotate-180" />
            </Link>
          </div>
          <ProductGrid products={bestSellers} />
        </section>

        {/* Deal of the day */}
        {heroDeal && (
          <section aria-labelledby="deal-heading" className="overflow-hidden rounded-[28px] bg-black text-white">
            <div className="grid grid-cols-1 items-center gap-6 p-6 sm:p-10 lg:grid-cols-2">
              <div className="relative order-2 aspect-[16/9] overflow-hidden rounded-[18px] lg:order-1">
                <img src="/images/deal-banner.jpg" alt="" className="h-full w-full object-cover" />
              </div>
              <div className="order-1 space-y-4 lg:order-2">
                <h2 id="deal-heading" className="flex items-center gap-2 text-2xl font-semibold sm:text-3xl">
                  <Clock3 size={24} aria-hidden="true" /> شگفت‌انگیز امروز
                </h2>
                <p className="text-white/70">پیشنهادهای محدود، فقط تا پایان تایمر.</p>
                <CountdownTimer endsAt={heroDeal.dealEndsAt!} className="text-lg" />
                <div className="flex items-center gap-3 pt-2">
                  <img src={heroDeal.images[0]} alt={heroDeal.name} className="h-16 w-16 rounded-[12px] object-cover" />
                  <div>
                    <p className="text-sm font-medium">{heroDeal.name}</p>
                    <PriceTag price={heroDeal.price} oldPrice={heroDeal.oldPrice} size="sm" />
                  </div>
                </div>
                <Link to={`/product/${heroDeal.slug}`}>
                  <Button variant="secondary" className="bg-white text-black hover:bg-white/90">
                    مشاهده‌ی پیشنهاد
                  </Button>
                </Link>
              </div>
            </div>
            <div className="border-t border-white/10 p-6 sm:p-10">
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                {deals.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Brands */}
        <section aria-labelledby="brands-heading">
          <h2 id="brands-heading" className="mb-6 text-xl font-semibold sm:text-2xl">
            برندها
          </h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {brands.map((b) => (
              <Link
                key={b.slug}
                to={`/category/${b.category}`}
                className="flex flex-col items-center justify-center gap-1 rounded-[18px] border border-border bg-surface px-4 py-6 text-center grayscale transition-all duration-200 hover:grayscale-0"
              >
                <span className="text-lg font-semibold">{b.name}</span>
                <span className="text-xs text-muted">{b.tagline}</span>
              </Link>
            ))}
          </div>
        </section>

        {/* Blog */}
        <section aria-labelledby="blog-heading">
          <h2 id="blog-heading" className="mb-6 text-xl font-semibold sm:text-2xl">
            از بلاگ کرونوس
          </h2>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
            {blogPosts.map((post) => (
              <Link
                key={post.id}
                to="/blog"
                className="group overflow-hidden rounded-[18px] border border-border bg-bg shadow-soft transition-transform duration-200 hover:-translate-y-0.5"
              >
                <div className="aspect-[16/10] overflow-hidden">
                  <img
                    src={post.image}
                    alt=""
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <p className="mb-1 text-xs text-muted">
                    {post.date} · {post.readMinutes} دقیقه مطالعه
                  </p>
                  <h3 className="mb-1 font-semibold leading-7">{post.title}</h3>
                  <p className="text-sm text-muted">{post.excerpt}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
