import { useMemo } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { SearchX } from "lucide-react";
import { products } from "../data/products";
import { Breadcrumb } from "../components/ui/Breadcrumb";
import { ProductGrid } from "../components/product/ProductGrid";
import { Button } from "../components/ui/Button";

export default function SearchPage() {
  const [params] = useSearchParams();
  const q = params.get("q")?.trim() ?? "";

  const results = useMemo(() => {
    if (!q) return [];
    const term = q.toLowerCase();
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(term) ||
        p.brand.toLowerCase().includes(term) ||
        p.category.includes(term) ||
        p.movement.includes(term)
    );
  }, [q]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <Breadcrumb items={[{ label: "خانه", href: "/" }, { label: "جستجو" }]} />
      <h1 className="mb-2 text-2xl font-semibold sm:text-3xl">نتایج جستجو برای «{q}»</h1>
      <p className="mb-6 text-sm text-muted">{results.length} نتیجه پیدا شد</p>

      {results.length === 0 ? (
        <div className="flex flex-col items-center gap-4 rounded-[18px] border border-dashed border-border px-6 py-16 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-surface text-muted">
            <SearchX size={28} />
          </div>
          <h2 className="text-lg font-semibold">نتیجه‌ای پیدا نشد</h2>
          <p className="max-w-sm text-sm text-muted">
            جستجوی دیگری امتحان کن یا یکی از دسته‌های محبوب را ببین: لوکس، اسپرت، هوشمند.
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            <Link to="/category/luxury">
              <Button variant="secondary" size="sm">لوکس</Button>
            </Link>
            <Link to="/category/sport">
              <Button variant="secondary" size="sm">اسپرت</Button>
            </Link>
            <Link to="/category/smart">
              <Button variant="secondary" size="sm">هوشمند</Button>
            </Link>
          </div>
        </div>
      ) : (
        <ProductGrid products={results} />
      )}
    </div>
  );
}
