import { blogPosts } from "../data/blog";
import { Breadcrumb } from "../components/ui/Breadcrumb";

export default function Blog() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
      <Breadcrumb items={[{ label: "خانه", href: "/" }, { label: "بلاگ" }]} />
      <h1 className="mb-8 text-2xl font-semibold sm:text-3xl">بلاگ کرونوس</h1>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        {blogPosts.map((post) => (
          <article key={post.id} className="overflow-hidden rounded-[18px] border border-border shadow-soft">
            <div className="aspect-[16/10] overflow-hidden">
              <img src={post.image} alt="" className="h-full w-full object-cover" />
            </div>
            <div className="p-5">
              <p className="mb-1.5 text-xs text-muted">
                {post.date} · {post.readMinutes} دقیقه مطالعه
              </p>
              <h2 className="mb-2 text-lg font-semibold leading-8">{post.title}</h2>
              <p className="leading-7 text-muted">{post.excerpt}</p>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
