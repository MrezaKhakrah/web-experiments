import { CheckCircle2, Info, XCircle } from "lucide-react";
import { useStore } from "../../store/useStore";

const icons = {
  success: <CheckCircle2 size={18} className="text-success" aria-hidden="true" />,
  error: <XCircle size={18} className="text-danger" aria-hidden="true" />,
  info: <Info size={18} className="text-accent" aria-hidden="true" />,
};

export function ToastHost() {
  const toasts = useStore((s) => s.toasts);
  const dismiss = useStore((s) => s.dismissToast);

  return (
    <div
      className="pointer-events-none fixed inset-x-0 bottom-4 z-[100] flex flex-col items-center gap-2 px-4 sm:bottom-6"
      aria-live="polite"
      aria-atomic="true"
    >
      {toasts.map((t) => (
        <div
          key={t.id}
          className="pointer-events-auto flex w-full max-w-sm items-center gap-2 rounded-[14px] border border-border bg-bg px-4 py-3 text-sm shadow-soft motion-safe:animate-fade-up"
          role="status"
        >
          {icons[t.tone]}
          <span className="flex-1">{t.message}</span>
          <button onClick={() => dismiss(t.id)} aria-label="بستن پیام" className="text-muted hover:text-text">
            ×
          </button>
        </div>
      ))}
    </div>
  );
}
