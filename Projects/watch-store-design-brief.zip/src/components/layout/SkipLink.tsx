export function SkipLink() {
  return (
    <a href="#main-content" className="skip-link">
      برو به محتوای اصلی
    </a>
  );
}
