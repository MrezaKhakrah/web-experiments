import { Link } from "react-router-dom";
import { Camera, Send, Phone, ShieldCheck, Truck, RotateCcw, BadgeCheck } from "lucide-react";

const trust = [
  { icon: BadgeCheck, title: "ضمانت اصالت", desc: "همه‌ی کالاها اورجینال" },
  { icon: ShieldCheck, title: "گارانتی ۲۴ ماهه", desc: "پشتیبانی رسمی" },
  { icon: RotateCcw, title: "۷ روز بازگشت", desc: "بدون پرسش اضافه" },
  { icon: Truck, title: "ارسال رایگان", desc: "برای خریدهای بالای ۵ میلیون" },
];

const columns = [
  {
    title: "دسته‌بندی‌ها",
    links: [
      { label: "ساعت لوکس", to: "/category/luxury" },
      { label: "ساعت اسپرت", to: "/category/sport" },
      { label: "ساعت هوشمند", to: "/category/smart" },
      { label: "مقایسه محصولات", to: "/compare" },
    ],
  },
  {
    title: "خدمات مشتریان",
    links: [
      { label: "گارانتی", to: "/warranty" },
      { label: "بازگشت کالا", to: "/returns" },
      { label: "درباره‌ی ما", to: "/about" },
      { label: "حریم خصوصی", to: "/privacy" },
    ],
  },
  {
    title: "حساب کاربری",
    links: [
      { label: "سفارش‌های من", to: "/account" },
      { label: "علاقه‌مندی‌ها", to: "/account?tab=wishlist" },
      { label: "آدرس‌ها", to: "/account?tab=addresses" },
      { label: "سبد خرید", to: "/cart" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border bg-surface">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="mb-12 grid grid-cols-2 gap-6 sm:grid-cols-4">
          {trust.map((t) => (
            <div key={t.title} className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-bg text-accent">
                <t.icon size={18} aria-hidden="true" />
              </div>
              <div>
                <p className="text-sm font-semibold">{t.title}</p>
                <p className="text-xs text-muted">{t.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
          <div className="col-span-2 sm:col-span-1">
            <div className="mb-3 flex items-center gap-2 text-lg font-semibold">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-text text-bg text-sm">⌚</span>
              کرونوس
            </div>
            <p className="mb-4 text-sm leading-7 text-muted">زمان، دقیق‌تر از همیشه.</p>
            <div className="flex items-center gap-2">
              <a
                href="#"
                aria-label="اینستاگرام کرونوس"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-border hover:border-text/40"
              >
                <Camera size={16} />
              </a>
              <a
                href="#"
                aria-label="تلگرام کرونوس"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-border hover:border-text/40"
              >
                <Send size={16} />
              </a>
              <a
                href="tel:02100000000"
                aria-label="تماس با پشتیبانی"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-border hover:border-text/40"
              >
                <Phone size={16} />
              </a>
            </div>
          </div>
          {columns.map((col) => (
            <div key={col.title}>
              <h3 className="mb-3 text-sm font-semibold">{col.title}</h3>
              <ul className="space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <Link to={l.to} className="text-sm text-muted transition-colors hover:text-text">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-border pt-6 text-xs text-muted sm:flex-row">
          <p>© ۱۴۰۳ فروشگاه کرونوس. تمام حقوق محفوظ است.</p>
          <p>طراحی‌شده با الهام از دقت ساعت‌سازی سوئیسی.</p>
        </div>
      </div>
    </footer>
  );
}
