import { Link } from "react-router-dom";
import { Minus, Plus, Trash2, X, ShoppingBag } from "lucide-react";
import { useCartDetails, useStore } from "../../store/useStore";
import { formatPrice } from "../../lib/format";
import { Button } from "../ui/Button";
import { EmptyState } from "../ui/States";

export function CartDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const lines = useCartDetails();
  const setQty = useStore((s) => s.setQty);
  const removeFromCart = useStore((s) => s.removeFromCart);
  const total = lines.reduce((sum, l) => sum + l.product.price * l.qty, 0);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label="سبد خرید">
      <button className="absolute inset-0 bg-black/40" aria-label="بستن سبد خرید" onClick={onClose} />
      <div className="relative z-10 flex h-full w-full max-w-md flex-col bg-bg shadow-soft motion-safe:animate-fade-up">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 className="text-lg font-semibold">سبد خرید ({lines.reduce((n, l) => n + l.qty, 0)})</h2>
          <button onClick={onClose} aria-label="بستن" className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-surface">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {lines.length === 0 ? (
            <EmptyState
              icon={<ShoppingBag size={28} />}
              title="سبدت خالی است"
              message="یک ساعت خوب انتخاب کنیم؟"
              ctaLabel="مشاهده‌ی محصولات"
              onCta={onClose}
            />
          ) : (
            <ul className="space-y-4">
              {lines.map((l) => (
                <li key={l.productId + l.colorId} className="flex gap-3">
                  <img
                    src={l.color.image}
                    alt={l.product.name}
                    className="h-20 w-20 shrink-0 rounded-[14px] object-cover"
                  />
                  <div className="flex flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <Link to={`/product/${l.product.slug}`} onClick={onClose} className="text-sm font-medium hover:text-accent">
                        {l.product.name}
                      </Link>
                      <button
                        onClick={() => removeFromCart(l.productId, l.colorId)}
                        aria-label={`حذف ${l.product.name} از سبد`}
                        className="text-muted hover:text-danger"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                    <span className="text-xs text-muted">رنگ: {l.color.name}</span>
                    <div className="mt-2 flex items-center justify-between">
                      <div className="flex items-center gap-2 rounded-full border border-border px-2 py-1">
                        <button
                          onClick={() => setQty(l.productId, l.colorId, l.qty - 1)}
                          disabled={l.qty <= 1}
                          aria-label="کم کردن تعداد"
                          className="flex h-5 w-5 items-center justify-center disabled:opacity-30"
                        >
                          <Minus size={13} />
                        </button>
                        <span className="tabular w-4 text-center text-sm">{l.qty}</span>
                        <button
                          onClick={() => setQty(l.productId, l.colorId, l.qty + 1)}
                          aria-label="افزودن تعداد"
                          className="flex h-5 w-5 items-center justify-center"
                        >
                          <Plus size={13} />
                        </button>
                      </div>
                      <span className="tabular text-sm font-semibold">{formatPrice(l.product.price * l.qty)}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {lines.length > 0 && (
          <div className="space-y-3 border-t border-border px-5 py-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted">جمع کل</span>
              <span className="tabular text-lg font-semibold">{formatPrice(total)}</span>
            </div>
            <Link to="/cart" onClick={onClose}>
              <Button className="w-full" variant="secondary">
                مشاهده‌ی سبد خرید
              </Button>
            </Link>
            <Link to="/checkout" onClick={onClose}>
              <Button className="w-full">ادامه‌ی خرید</Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
