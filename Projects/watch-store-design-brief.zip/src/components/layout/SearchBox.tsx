import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Clock, TrendingUp, X } from "lucide-react";
import { products } from "../../data/products";
import { useStore } from "../../store/useStore";
import { formatPrice } from "../../lib/format";

const POPULAR = ["ساعت هوشمند", "مریدین", "اتوماتیک", "ولوسیس استورم", "ساعت اسپرت زیر ۱۰ میلیون"];

export function SearchBox({ compact, onNavigate }: { compact?: boolean; onNavigate?: () => void }) {
  const [term, setTerm] = useState("");
  const [debounced, setDebounced] = useState("");
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const history = useStore((s) => s.searchHistory);
  const addHistory = useStore((s) => s.addSearchHistory);
  const clearHistory = useStore((s) => s.clearSearchHistory);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const id = setTimeout(() => setDebounced(term), 300);
    return () => clearTimeout(id);
  }, [term]);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const results = debounced
    ? products
        .filter(
          (p) => p.name.includes(debounced) || p.brand.includes(debounced) || p.category.includes(debounced)
        )
        .slice(0, 6)
    : [];

  function submit(value: string) {
    if (!value.trim()) return;
    addHistory(value.trim());
    setOpen(false);
    onNavigate?.();
    navigate(`/search?q=${encodeURIComponent(value.trim())}`);
  }

  return (
    <div ref={boxRef} className="relative w-full">
      <form
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          submit(term);
        }}
        className="relative"
      >
        <Search
          size={17}
          className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-muted"
          aria-hidden="true"
        />
        <label htmlFor="site-search" className="sr-only">
          جستجوی محصول
        </label>
        <input
          id="site-search"
          type="search"
          value={term}
          onFocus={() => setOpen(true)}
          onChange={(e) => setTerm(e.target.value)}
          placeholder="جستجوی ساعت، برند یا مدل…"
          className={`w-full rounded-full border border-border bg-surface py-2.5 pe-10 ps-4 text-sm outline-none transition-colors focus:border-accent ${
            compact ? "" : "sm:py-3"
          }`}
        />
        {term && (
          <button
            type="button"
            onClick={() => setTerm("")}
            aria-label="پاک کردن جستجو"
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted hover:text-text"
          >
            <X size={16} />
          </button>
        )}
      </form>

      {open && (
        <div className="absolute z-40 mt-2 w-full overflow-hidden rounded-[18px] border border-border bg-bg shadow-soft">
          {debounced ? (
            results.length > 0 ? (
              <ul>
                {results.map((p) => (
                  <li key={p.id}>
                    <button
                      onClick={() => {
                        setOpen(false);
                        onNavigate?.();
                        addHistory(p.name);
                        navigate(`/product/${p.slug}`);
                      }}
                      className="flex w-full items-center gap-3 px-4 py-2.5 text-start text-sm transition-colors hover:bg-surface"
                    >
                      <img src={p.images[0]} alt="" className="h-10 w-10 rounded-lg object-cover" />
                      <span className="flex-1">
                        <span className="block font-medium">{p.name}</span>
                        <span className="block text-xs text-muted">{p.brand}</span>
                      </span>
                      <span className="tabular text-xs text-muted">{formatPrice(p.price)}</span>
                    </button>
                  </li>
                ))}
                <li className="border-t border-border">
                  <button
                    onClick={() => submit(debounced)}
                    className="w-full px-4 py-2.5 text-center text-sm font-medium text-accent hover:bg-surface"
                  >
                    مشاهده‌ی همه‌ی نتایج «{debounced}»
                  </button>
                </li>
              </ul>
            ) : (
              <div className="px-4 py-6 text-center text-sm text-muted">
                نتیجه‌ای برای «{debounced}» پیدا نشد.
              </div>
            )
          ) : (
            <div className="p-4">
              {history.length > 0 && (
                <div className="mb-3">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-xs font-medium text-muted">تاریخچه‌ی جستجو</span>
                    <button onClick={clearHistory} className="text-xs text-accent hover:underline">
                      پاک کردن
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {history.map((h) => (
                      <button
                        key={h}
                        onClick={() => submit(h)}
                        className="flex items-center gap-1 rounded-full border border-border px-3 py-1.5 text-xs hover:border-text/40"
                      >
                        <Clock size={12} aria-hidden="true" />
                        {h}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <div>
                <span className="mb-2 flex items-center gap-1 text-xs font-medium text-muted">
                  <TrendingUp size={13} aria-hidden="true" />
                  جستجوهای پرطرفدار
                </span>
                <div className="flex flex-wrap gap-2">
                  {POPULAR.map((h) => (
                    <button
                      key={h}
                      onClick={() => submit(h)}
                      className="rounded-full bg-surface px-3 py-1.5 text-xs hover:bg-border/60"
                    >
                      {h}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
