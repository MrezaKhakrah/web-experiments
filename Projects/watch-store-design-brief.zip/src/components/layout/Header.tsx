import { useEffect, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { Heart, Scale, ShoppingBag, User, Menu, X, Moon, Sun, Search as SearchIcon } from "lucide-react";
import { SearchBox } from "./SearchBox";
import { useStore } from "../../store/useStore";
import { cn } from "../../utils/cn";

const NAV_LINKS = [
  { to: "/", label: "خانه" },
  { to: "/category/luxury", label: "لوکس" },
  { to: "/category/sport", label: "اسپرت" },
  { to: "/category/smart", label: "هوشمند" },
  { to: "/blog", label: "بلاگ" },
];

export function Header({ onOpenCart }: { onOpenCart: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [mobileSearch, setMobileSearch] = useState(false);
  const [dark, setDark] = useState(false);
  const cart = useStore((s) => s.cart);
  const wishlist = useStore((s) => s.wishlist);
  const compare = useStore((s) => s.compare);
  const cartCount = cart.reduce((n, l) => n + l.qty, 0);

  useEffect(() => {
    const saved = localStorage.getItem("chronos-theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const isDark = saved ? saved === "dark" : prefersDark;
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  function toggleDark() {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("chronos-theme", next ? "dark" : "light");
  }

  return (
    <header className="sticky top-0 z-30 border-b border-border/70 bg-bg/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6">
        <button
          className="-mr-2 flex h-9 w-9 items-center justify-center rounded-full hover:bg-surface md:hidden"
          onClick={() => setMenuOpen(true)}
          aria-label="باز کردن منو"
        >
          <Menu size={20} />
        </button>

        <Link to="/" className="flex items-center gap-2 text-lg font-semibold tracking-tight">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-text text-bg text-sm">⌚</span>
          <span className="hidden sm:inline">کرونوس</span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex" aria-label="ناوبری اصلی">
          {NAV_LINKS.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === "/"}
              className={({ isActive }) =>
                cn(
                  "rounded-full px-3.5 py-2 text-sm font-medium transition-colors duration-200",
                  isActive ? "text-accent" : "text-text hover:bg-surface"
                )
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden flex-1 max-w-md md:block">
          <SearchBox compact />
        </div>

        <div className="mr-auto flex items-center gap-1">
          <button
            className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-surface md:hidden"
            onClick={() => setMobileSearch((v) => !v)}
            aria-label="جستجو"
          >
            <SearchIcon size={19} />
          </button>
          <button
            onClick={toggleDark}
            className="hidden h-9 w-9 items-center justify-center rounded-full hover:bg-surface sm:flex"
            aria-label={dark ? "فعال‌سازی حالت روشن" : "فعال‌سازی حالت تاریک"}
          >
            {dark ? <Sun size={19} /> : <Moon size={19} />}
          </button>
          <Link
            to="/compare"
            className="relative hidden h-9 w-9 items-center justify-center rounded-full hover:bg-surface sm:flex"
            aria-label={`مقایسه، ${compare.length} محصول`}
          >
            <Scale size={19} />
            {compare.length > 0 && (
              <span className="absolute -top-0.5 -left-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-[10px] font-bold text-white">
                {compare.length}
              </span>
            )}
          </Link>
          <Link
            to="/account?tab=wishlist"
            className="relative hidden h-9 w-9 items-center justify-center rounded-full hover:bg-surface sm:flex"
            aria-label={`علاقه‌مندی‌ها، ${wishlist.length} محصول`}
          >
            <Heart size={19} />
            {wishlist.length > 0 && (
              <span className="absolute -top-0.5 -left-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-[10px] font-bold text-white">
                {wishlist.length}
              </span>
            )}
          </Link>
          <Link
            to="/account"
            className="hidden h-9 w-9 items-center justify-center rounded-full hover:bg-surface sm:flex"
            aria-label="حساب کاربری"
          >
            <User size={19} />
          </Link>
          <button
            onClick={onOpenCart}
            className="relative flex h-9 w-9 items-center justify-center rounded-full hover:bg-surface"
            aria-label={`سبد خرید، ${cartCount} کالا`}
          >
            <ShoppingBag size={19} />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -left-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-[10px] font-bold text-white">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {mobileSearch && (
        <div className="border-t border-border px-4 py-3 md:hidden">
          <SearchBox onNavigate={() => setMobileSearch(false)} />
        </div>
      )}

      {menuOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <button className="absolute inset-0 bg-black/40" aria-label="بستن منو" onClick={() => setMenuOpen(false)} />
          <div className="absolute inset-y-0 right-0 flex w-72 flex-col gap-1 bg-bg p-5 shadow-soft motion-safe:animate-fade-up">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-lg font-semibold">منو</span>
              <button onClick={() => setMenuOpen(false)} aria-label="بستن منو" className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-surface">
                <X size={18} />
              </button>
            </div>
            {NAV_LINKS.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === "/"}
                onClick={() => setMenuOpen(false)}
                className="rounded-[12px] px-3 py-3 text-sm font-medium hover:bg-surface"
              >
                {l.label}
              </NavLink>
            ))}
            <div className="my-2 h-px bg-border" />
            <Link to="/compare" onClick={() => setMenuOpen(false)} className="rounded-[12px] px-3 py-3 text-sm font-medium hover:bg-surface">
              مقایسه ({compare.length})
            </Link>
            <Link to="/account?tab=wishlist" onClick={() => setMenuOpen(false)} className="rounded-[12px] px-3 py-3 text-sm font-medium hover:bg-surface">
              علاقه‌مندی‌ها ({wishlist.length})
            </Link>
            <Link to="/account" onClick={() => setMenuOpen(false)} className="rounded-[12px] px-3 py-3 text-sm font-medium hover:bg-surface">
              حساب کاربری
            </Link>
            <button onClick={toggleDark} className="flex items-center gap-2 rounded-[12px] px-3 py-3 text-start text-sm font-medium hover:bg-surface">
              {dark ? <Sun size={17} /> : <Moon size={17} />}
              {dark ? "حالت روشن" : "حالت تاریک"}
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
