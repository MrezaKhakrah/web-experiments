import { formatPrice, discountPercent, formatPercent } from "../../lib/format";
import { cn } from "../../utils/cn";

interface Props {
  price: number;
  oldPrice?: number;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const sizeClasses = {
  sm: "text-sm",
  md: "text-lg",
  lg: "text-2xl",
};

export function PriceTag({ price, oldPrice, size = "md", className }: Props) {
  const percent = discountPercent(price, oldPrice);
  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      <span className={cn("tabular font-semibold", sizeClasses[size])}>{formatPrice(price)}</span>
      {percent > 0 && (
        <>
          <span className="tabular text-sm text-muted line-through">{formatPrice(oldPrice!)}</span>
          <span className="rounded-md bg-danger/10 px-1.5 py-0.5 text-xs font-semibold text-danger">
            {formatPercent(percent)}−
          </span>
        </>
      )}
    </div>
  );
}
