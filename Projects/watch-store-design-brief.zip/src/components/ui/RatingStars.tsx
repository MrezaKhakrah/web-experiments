import { Star } from "lucide-react";
import { toFaDigits } from "../../lib/format";
import { cn } from "../../utils/cn";

interface Props {
  rating: number;
  reviewCount?: number;
  size?: number;
  showNumber?: boolean;
  className?: string;
}

export function RatingStars({ rating, reviewCount, size = 14, showNumber = true, className }: Props) {
  return (
    <div className={cn("flex items-center gap-1.5", className)} role="img" aria-label={`امتیاز ${toFaDigits(rating)} از ۵`}>
      <div className="flex items-center" aria-hidden="true">
        {Array.from({ length: 5 }).map((_, i) => {
          const filled = i + 1 <= Math.round(rating);
          return (
            <Star
              key={i}
              width={size}
              height={size}
              className={filled ? "fill-accent text-accent" : "fill-transparent text-border"}
              strokeWidth={1.5}
            />
          );
        })}
      </div>
      {showNumber && <span className="tabular text-xs text-muted">{toFaDigits(rating.toFixed(1))}</span>}
      {reviewCount !== undefined && (
        <span className="tabular text-xs text-muted">({toFaDigits(reviewCount)})</span>
      )}
    </div>
  );
}
