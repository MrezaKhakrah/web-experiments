import { useEffect, useState } from "react";
import { toFaDigits } from "../../lib/format";

function getParts(ms: number) {
  const total = Math.max(0, ms);
  const h = Math.floor(total / 3600000);
  const m = Math.floor((total % 3600000) / 60000);
  const s = Math.floor((total % 60000) / 1000);
  return { h, m, s };
}

export function CountdownTimer({ endsAt, className }: { endsAt: number; className?: string }) {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const { h, m, s } = getParts(endsAt - now);
  const pad = (n: number) => toFaDigits(String(n).padStart(2, "0"));

  return (
    <div className={`flex items-center gap-1 tabular font-semibold ${className ?? ""}`} dir="ltr" aria-label="زمان باقی‌مانده پیشنهاد">
      <span className="rounded-md bg-black/80 px-1.5 py-0.5 text-white">{pad(h)}</span>
      <span>:</span>
      <span className="rounded-md bg-black/80 px-1.5 py-0.5 text-white">{pad(m)}</span>
      <span>:</span>
      <span className="rounded-md bg-black/80 px-1.5 py-0.5 text-white">{pad(s)}</span>
    </div>
  );
}
