import { useEffect } from "react";
import type { ReactNode } from "react";
import { X } from "lucide-react";
import { createPortal } from "react-dom";

interface Props {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
}

export function BottomSheet({ open, onClose, title, children, footer }: Props) {
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  if (!open) return null;

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center" role="dialog" aria-modal="true" aria-label={title}>
      <button
        className="absolute inset-0 bg-black/40 motion-safe:animate-[fade-up_0.3s_ease-out]"
        aria-label="بستن"
        onClick={onClose}
      />
      <div className="relative z-10 flex max-h-[85vh] w-full flex-col rounded-t-[28px] bg-bg shadow-soft sm:max-w-lg sm:rounded-[28px] motion-safe:animate-fade-up">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button
            onClick={onClose}
            aria-label="بستن پنجره"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-surface transition-colors hover:bg-border"
          >
            <X size={18} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="border-t border-border px-5 py-4">{footer}</div>}
      </div>
    </div>,
    document.body
  );
}
