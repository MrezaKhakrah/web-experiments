import type { ButtonHTMLAttributes } from "react";
import { cn } from "../../utils/cn";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  active?: boolean;
}

export function Chip({ active, className, children, ...rest }: Props) {
  return (
    <button
      type="button"
      aria-pressed={active}
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-4 py-2 text-sm font-medium transition-all duration-200 ease-out focus-visible:outline-2",
        active
          ? "border-text bg-text text-bg"
          : "border-border bg-bg text-text hover:border-text/50",
        className
      )}
      {...rest}
    >
      {children}
    </button>
  );
}
