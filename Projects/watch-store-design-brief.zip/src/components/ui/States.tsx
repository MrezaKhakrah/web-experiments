import type { ReactNode } from "react";
import { PackageSearch, WifiOff, AlertTriangle } from "lucide-react";
import { Button } from "./Button";

export function EmptyState({
  title,
  message,
  ctaLabel,
  onCta,
  icon,
}: {
  title: string;
  message: string;
  ctaLabel?: string;
  onCta?: () => void;
  icon?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center gap-4 rounded-[18px] border border-dashed border-border px-6 py-16 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-surface text-muted" aria-hidden="true">
        {icon ?? <PackageSearch size={28} />}
      </div>
      <div className="space-y-1">
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="text-sm text-muted">{message}</p>
      </div>
      {ctaLabel && onCta && (
        <Button onClick={onCta} size="md">
          {ctaLabel}
        </Button>
      )}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-4 rounded-[18px] border border-danger/30 bg-danger/5 px-6 py-16 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-danger/10 text-danger" aria-hidden="true">
        <AlertTriangle size={28} />
      </div>
      <p className="text-sm font-medium">{message}</p>
      <Button variant="danger" onClick={onRetry}>
        دوباره تلاش کن
      </Button>
    </div>
  );
}

export function OfflineBanner({ visible }: { visible: boolean }) {
  if (!visible) return null;
  return (
    <div
      role="status"
      className="flex items-center justify-center gap-2 bg-danger px-4 py-2 text-center text-sm font-medium text-white"
    >
      <WifiOff size={16} aria-hidden="true" />
      اتصال اینترنت برقرار نیست. برخی بخش‌ها ممکن است کار نکنند.
    </div>
  );
}
