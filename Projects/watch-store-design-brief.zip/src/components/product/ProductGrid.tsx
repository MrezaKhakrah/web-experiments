import type { Product } from "../../data/types";
import { ProductCard } from "./ProductCard";
import { ProductCardSkeleton } from "../ui/Skeleton";
import { EmptyState } from "../ui/States";
import { cn } from "../../utils/cn";

export function ProductGrid({
  products,
  view = "grid",
  loading,
  columns = 4,
}: {
  products: Product[];
  view?: "grid" | "list";
  loading?: boolean;
  columns?: 3 | 4;
}) {
  if (loading) {
    return (
      <div
        className={cn(
          "grid gap-4",
          view === "list" ? "grid-cols-1" : columns === 3 ? "grid-cols-2 sm:grid-cols-3" : "grid-cols-2 sm:grid-cols-3 lg:grid-cols-4"
        )}
      >
        {Array.from({ length: 8 }).map((_, i) => (
          <ProductCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <EmptyState
        title="محصولی پیدا نشد"
        message="فیلترها را تغییر بده یا جستجوی دیگری را امتحان کن."
      />
    );
  }

  return (
    <div
      className={cn(
        "grid gap-4",
        view === "list"
          ? "grid-cols-1"
          : columns === 3
          ? "grid-cols-2 sm:grid-cols-3"
          : "grid-cols-2 sm:grid-cols-3 lg:grid-cols-4"
      )}
    >
      {products.map((p) => (
        <ProductCard key={p.id} product={p} view={view} />
      ))}
    </div>
  );
}
