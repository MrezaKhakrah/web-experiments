import { useRef } from "react";
import { ChevronRight } from "lucide-react";
import type { ReactNode } from "react";

export function Carousel({ children, title }: { children: ReactNode[]; title?: string }) {
  const trackRef = useRef<HTMLDivElement>(null);

  function scrollBy(dir: 1 | -1) {
    const el = trackRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * el.clientWidth * 0.8, behavior: "smooth" });
  }

  return (
    <div>
      {title && (
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold sm:text-2xl">{title}</h2>
          <div className="hidden items-center gap-2 sm:flex">
            <button
              onClick={() => scrollBy(1)}
              aria-label="آیتم بعدی"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-border hover:border-text/40"
            >
              <ChevronRight size={16} className="rtl:rotate-180" />
            </button>
            <button
              onClick={() => scrollBy(-1)}
              aria-label="آیتم قبلی"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-border hover:border-text/40"
            >
              <ChevronRight size={16} className="rotate-180 rtl:rotate-0" />
            </button>
          </div>
        </div>
      )}
      <div
        ref={trackRef}
        className="no-scrollbar flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-smooth pb-2"
      >
        {children.map((child, i) => (
          <div key={i} className="w-[220px] shrink-0 snap-start sm:w-[260px]">
            {child}
          </div>
        ))}
      </div>
    </div>
  );
}
