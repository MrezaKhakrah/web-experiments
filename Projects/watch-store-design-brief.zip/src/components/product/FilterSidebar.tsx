import type { ReactNode } from "react";
import type { MovementType, StrapMaterial } from "../../data/types";
import { formatPrice } from "../../lib/format";
import { RatingStars } from "../ui/RatingStars";

export interface Filters {
  brands: string[];
  straps: StrapMaterial[];
  movements: MovementType[];
  sizes: number[];
  colors: string[];
  minRating: number;
  priceMax: number;
}

export const DEFAULT_PRICE_MAX = 100000000;

export const EMPTY_FILTERS: Filters = {
  brands: [],
  straps: [],
  movements: [],
  sizes: [],
  colors: [],
  minRating: 0,
  priceMax: DEFAULT_PRICE_MAX,
};

interface Facets {
  brands: string[];
  straps: StrapMaterial[];
  movements: MovementType[];
  sizes: number[];
  colors: { name: string; hex: string }[];
}

function toggleItem<T>(arr: T[], item: T): T[] {
  return arr.includes(item) ? arr.filter((i) => i !== item) : [...arr, item];
}

export function FilterSidebar({
  filters,
  onChange,
  facets,
}: {
  filters: Filters;
  onChange: (f: Filters) => void;
  facets: Facets;
}) {
  return (
    <div className="space-y-6">
      <FilterGroup title="برند">
        {facets.brands.map((b) => (
          <label key={b} className="flex items-center gap-2 py-1 text-sm">
            <input
              type="checkbox"
              checked={filters.brands.includes(b)}
              onChange={() => onChange({ ...filters, brands: toggleItem(filters.brands, b) })}
              className="h-4 w-4 accent-[#0071e3]"
            />
            {b}
          </label>
        ))}
      </FilterGroup>

      <FilterGroup title="جنس بند">
        {facets.straps.map((s) => (
          <label key={s} className="flex items-center gap-2 py-1 text-sm">
            <input
              type="checkbox"
              checked={filters.straps.includes(s)}
              onChange={() => onChange({ ...filters, straps: toggleItem(filters.straps, s) })}
              className="h-4 w-4 accent-[#0071e3]"
            />
            {s}
          </label>
        ))}
      </FilterGroup>

      <FilterGroup title="نوع موتور">
        {facets.movements.map((m) => (
          <label key={m} className="flex items-center gap-2 py-1 text-sm">
            <input
              type="checkbox"
              checked={filters.movements.includes(m)}
              onChange={() => onChange({ ...filters, movements: toggleItem(filters.movements, m) })}
              className="h-4 w-4 accent-[#0071e3]"
            />
            {m}
          </label>
        ))}
      </FilterGroup>

      <FilterGroup title="اندازه‌ی قاب (میلی‌متر)">
        <div className="flex flex-wrap gap-2">
          {facets.sizes.map((sz) => (
            <button
              key={sz}
              onClick={() => onChange({ ...filters, sizes: toggleItem(filters.sizes, sz) })}
              aria-pressed={filters.sizes.includes(sz)}
              className={`h-8 min-w-[42px] rounded-[10px] border px-2 text-xs font-medium transition-colors ${
                filters.sizes.includes(sz) ? "border-text bg-text text-bg" : "border-border hover:border-text/40"
              }`}
            >
              {sz}
            </button>
          ))}
        </div>
      </FilterGroup>

      <FilterGroup title="رنگ">
        <div className="flex flex-wrap gap-2">
          {facets.colors.map((c) => (
            <button
              key={c.name}
              onClick={() => onChange({ ...filters, colors: toggleItem(filters.colors, c.name) })}
              aria-pressed={filters.colors.includes(c.name)}
              aria-label={c.name}
              title={c.name}
              className={`h-8 w-8 rounded-full border-2 transition-transform ${
                filters.colors.includes(c.name) ? "scale-110 border-accent" : "border-border"
              }`}
              style={{ backgroundColor: c.hex }}
            />
          ))}
        </div>
      </FilterGroup>

      <FilterGroup title="حداکثر قیمت">
        <input
          type="range"
          min={1000000}
          max={DEFAULT_PRICE_MAX}
          step={500000}
          value={filters.priceMax}
          onChange={(e) => onChange({ ...filters, priceMax: Number(e.target.value) })}
          className="w-full accent-[#0071e3]"
          aria-label="بازه قیمت"
        />
        <p className="tabular mt-1 text-xs text-muted">تا {formatPrice(filters.priceMax)}</p>
      </FilterGroup>

      <FilterGroup title="حداقل امتیاز">
        <div className="flex flex-col gap-1">
          {[4, 3, 2].map((r) => (
            <button
              key={r}
              onClick={() => onChange({ ...filters, minRating: filters.minRating === r ? 0 : r })}
              aria-pressed={filters.minRating === r}
              className={`flex items-center gap-2 rounded-[10px] border px-2 py-1.5 text-start transition-colors ${
                filters.minRating === r ? "border-text bg-surface" : "border-transparent hover:bg-surface"
              }`}
            >
              <RatingStars rating={r} showNumber={false} />
              <span className="text-xs text-muted">و بالاتر</span>
            </button>
          ))}
        </div>
      </FilterGroup>
    </div>
  );
}

function FilterGroup({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="border-b border-border pb-5 last:border-0">
      <h3 className="mb-2.5 text-sm font-semibold">{title}</h3>
      {children}
    </div>
  );
}
