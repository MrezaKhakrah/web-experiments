import { Link } from "react-router-dom";
import { X } from "lucide-react";
import { useStore, getProduct } from "../../store/useStore";
import { Button } from "../ui/Button";

export function CompareBar() {
  const compare = useStore((s) => s.compare);
  const removeFromCompare = useStore((s) => s.removeFromCompare);
  const clearCompare = useStore((s) => s.clearCompare);

  if (compare.length === 0) return null;
  const items = compare.map((id) => getProduct(id)).filter(Boolean);

  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-bg/95 backdrop-blur-md shadow-soft motion-safe:animate-fade-up">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
        <div className="flex flex-1 items-center gap-2 overflow-x-auto no-scrollbar">
          {items.map(
            (p) =>
              p && (
                <div key={p.id} className="relative flex shrink-0 items-center gap-2 rounded-[12px] border border-border p-1.5 pe-2">
                  <img src={p.images[0]} alt={p.name} className="h-9 w-9 rounded-[8px] object-cover" />
                  <span className="max-w-[90px] truncate text-xs font-medium">{p.name}</span>
                  <button
                    onClick={() => removeFromCompare(p.id)}
                    aria-label={`حذف ${p.name} از مقایسه`}
                    className="text-muted hover:text-danger"
                  >
                    <X size={13} />
                  </button>
                </div>
              )
          )}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={clearCompare} className="text-xs text-muted hover:text-danger">
            پاک کردن
          </button>
          <Link to="/compare">
            <Button size="sm">مقایسه ({compare.length})</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
