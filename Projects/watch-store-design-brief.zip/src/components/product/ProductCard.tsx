import { Link } from "react-router-dom";
import { useState } from "react";
import { Heart, Scale, ShoppingBag } from "lucide-react";
import type { Product } from "../../data/types";
import { PriceTag } from "../ui/PriceTag";
import { RatingStars } from "../ui/RatingStars";
import { useStore } from "../../store/useStore";
import { cn } from "../../utils/cn";

export function ProductCard({ product, view = "grid" }: { product: Product; view?: "grid" | "list" }) {
  const [imgLoaded, setImgLoaded] = useState(false);
  const wishlist = useStore((s) => s.wishlist);
  const compare = useStore((s) => s.compare);
  const toggleWishlist = useStore((s) => s.toggleWishlist);
  const toggleCompare = useStore((s) => s.toggleCompare);
  const addToCart = useStore((s) => s.addToCart);

  const isWished = wishlist.includes(product.id);
  const isCompared = compare.includes(product.id);
  const outOfStock = product.stock <= 0;

  const badge = product.isDeal ? { label: "شگفت‌انگیز", cls: "bg-danger text-white" } : product.isNew ? { label: "جدید", cls: "bg-accent text-white" } : product.isBestSeller ? { label: "پرفروش", cls: "bg-text text-bg" } : null;

  return (
    <article
      className={cn(
        "group relative flex rounded-[18px] border border-border bg-bg p-3 shadow-soft transition-all duration-200 ease-out hover:-translate-y-0.5 hover:shadow-[0_2px_4px_rgba(0,0,0,.06),0_16px_32px_rgba(0,0,0,.08)]",
        view === "grid" ? "flex-col" : "flex-row gap-4"
      )}
    >
      <div className={cn("relative overflow-hidden rounded-[14px] bg-surface", view === "grid" ? "aspect-square w-full" : "aspect-square w-32 shrink-0 sm:w-40")}>
        {!imgLoaded && <div className="absolute inset-0 animate-pulse bg-border/50" />}
        <Link to={`/product/${product.slug}`} className="block h-full w-full" aria-label={product.name}>
          <img
            src={product.images[0]}
            alt={`${product.brand} ${product.name}`}
            loading="lazy"
            onLoad={() => setImgLoaded(true)}
            className={cn(
              "h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105",
              imgLoaded ? "opacity-100" : "opacity-0"
            )}
          />
        </Link>
        {badge && (
          <span className={cn("absolute right-2 top-2 rounded-md px-2 py-0.5 text-[11px] font-semibold", badge.cls)}>
            {badge.label}
          </span>
        )}
        <button
          onClick={() => toggleWishlist(product.id)}
          aria-pressed={isWished}
          aria-label={isWished ? "حذف از علاقه‌مندی‌ها" : "افزودن به علاقه‌مندی‌ها"}
          className="absolute left-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-bg/90 text-text opacity-0 shadow-soft transition-opacity duration-200 group-hover:opacity-100 focus-visible:opacity-100"
        >
          <Heart size={15} className={isWished ? "fill-danger text-danger" : ""} />
        </button>
      </div>

      <div className={cn("flex flex-1 flex-col", view === "grid" ? "mt-3" : "justify-center")}>
        <span className="text-xs text-muted">{product.brand}</span>
        <Link to={`/product/${product.slug}`} className="mt-0.5 line-clamp-2 text-sm font-medium hover:text-accent">
          {product.name}
        </Link>
        <RatingStars rating={product.rating} reviewCount={product.reviewCount} className="mt-1.5" />
        <PriceTag price={product.price} oldPrice={product.oldPrice} size="sm" className="mt-2" />
        {outOfStock && <span className="mt-1 text-xs font-medium text-danger">ناموجود</span>}

        <div className="mt-3 flex items-center gap-2">
          <button
            onClick={() => addToCart(product.id, product.colors[0].id)}
            disabled={outOfStock}
            className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-[12px] bg-text text-bg text-xs font-medium transition-all duration-200 hover:opacity-90 active:scale-[0.98] disabled:bg-border disabled:text-muted"
          >
            <ShoppingBag size={14} aria-hidden="true" />
            {outOfStock ? "ناموجود" : "افزودن به سبد"}
          </button>
          <button
            onClick={() => toggleCompare(product.id)}
            aria-pressed={isCompared}
            aria-label="افزودن به مقایسه"
            className={cn(
              "flex h-9 w-9 shrink-0 items-center justify-center rounded-[12px] border transition-colors",
              isCompared ? "border-accent bg-accent/10 text-accent" : "border-border hover:border-text/40"
            )}
          >
            <Scale size={14} />
          </button>
        </div>
      </div>
    </article>
  );
}
