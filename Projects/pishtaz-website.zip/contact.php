<?php
/**
 * Contact form handler for Pishtaz.
 * Upload next to index.html in public_html. Requires PHP with mail() enabled (default on DirectAdmin).
 */

// ====== EDIT THESE TWO LINES ======
$TO_EMAIL   = 'hello@yourdomain.ir';   // where messages are delivered
$FROM_EMAIL = 'no-reply@yourdomain.ir'; // an address on YOUR domain (helps avoid spam filters)
// ==================================

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

function respond($ok, $code = 200) {
    http_response_code($code);
    echo json_encode(array('ok' => $ok));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, 405);
}

// Honeypot: bots fill this hidden field
if (!empty($_POST['website'])) {
    respond(true);
}

// Simple rate limit: one message per 30 seconds per session
session_start();
if (isset($_SESSION['last_sent']) && (time() - $_SESSION['last_sent']) < 30) {
    respond(false, 429);
}

function clean($v, $max) {
    $v = trim((string) $v);
    $v = str_replace(array("\r", "\n", "%0a", "%0d"), ' ', $v); // block header injection
    return mb_substr($v, 0, $max, 'UTF-8');
}

$name    = clean(isset($_POST['name']) ? $_POST['name'] : '', 100);
$email   = clean(isset($_POST['email']) ? $_POST['email'] : '', 150);
$message = trim(isset($_POST['message']) ? (string) $_POST['message'] : '');
$message = mb_substr($message, 0, 3000, 'UTF-8');

if ($name === '' || $message === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond(false, 422);
}

$subject = '=?UTF-8?B?' . base64_encode('پیام جدید از وب‌سایت: ' . $name) . '?=';

$body  = "Name: $name\n";
$body .= "Email: $email\n";
$body .= "IP: " . (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '-') . "\n";
$body .= "----------------------------------------\n";
$body .= $message . "\n";

$headers  = "From: Pishtaz Website <$FROM_EMAIL>\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
$headers .= "X-Mailer: PHP/" . phpversion();

$sent = @mail($TO_EMAIL, $subject, $body, $headers);

if ($sent) {
    $_SESSION['last_sent'] = time();
    respond(true);
}
respond(false, 500);
