(function () {
  'use strict';

  /* ---------- Translations ---------- */
  var T = {
    fa: {
      title: 'پیشتاز | Pishtaz',
      skip: 'پرش به محتوا',
      brand: 'پیشتاز',
      'nav.home': 'خانه', 'nav.about': 'درباره من', 'nav.skills': 'مهارت‌ها',
      'nav.projects': 'پروژه‌ها', 'nav.journey': 'مسیر من', 'nav.contact': 'تماس',
      'hero.eyebrow': 'سلام، من پیشتاز هستم',
      'hero.t1': 'سایت‌ها و تجربه‌هایی', 'hero.t2': 'فراتر از انتظار', 'hero.t3': 'می‌سازم',
      'hero.lead': 'طراحی و توسعه وب‌سایت‌های سریع، زیبا و کاملاً واکنش‌گرا؛ از ایده تا اجرا.',
      'hero.cta1': 'مشاهده پروژه‌ها', 'hero.cta2': 'تماس با من',
      'about.kicker': 'آشنایی', 'about.title': 'درباره من',
      'about.p1': 'من پیشتاز هستم؛ علاقه‌مند به ساختن چیزهایی که هم زیبا باشند و هم درست کار کنند. در هر پروژه روی سرعت، سادگی و تجربه کاربری تمرکز می‌کنم.',
      'about.p2': 'این وب‌سایت جایی است برای نمایش کارها، ثبت مسیر یادگیری و ارتباط با شما.',
      'about.c1': 'سرعت بالا', 'about.c2': 'طراحی تمیز', 'about.c3': 'سازگار با موبایل', 'about.c4': 'کد خوانا', 'about.c5': 'پشتیبانی',
      'skills.kicker': 'توانایی‌ها', 'skills.title': 'مهارت‌ها',
      'skills.s1.t': 'طراحی رابط کاربری', 'skills.s1.d': 'رابط‌های ساده، خوانا و دلنشین که کاربر را بدون سردرگمی هدایت می‌کنند.',
      'skills.s2.t': 'توسعه وب', 'skills.s2.d': 'ساخت وب‌سایت‌های سبک و پایدار با HTML، CSS و جاوااسکریپت مدرن.',
      'skills.s3.t': 'طراحی واکنش‌گرا', 'skills.s3.d': 'نمایش بی‌نقص روی موبایل، تبلت و دسکتاپ با هر اندازه صفحه.',
      'skills.s4.t': 'بهینه‌سازی و سئو', 'skills.s4.d': 'سرعت بارگذاری بالا و ساختار مناسب برای دیده‌شدن در موتورهای جستجو.',
      'projects.kicker': 'نمونه کارها', 'projects.title': 'پروژه‌ها',
      'projects.p1.t': 'پروژه نمونه ۱', 'projects.p1.d': 'توضیح کوتاهی درباره این پروژه، هدف آن و نتیجه‌ای که به دست آمد.',
      'projects.p2.t': 'پروژه نمونه ۲', 'projects.p2.d': 'توضیح کوتاهی درباره این پروژه، هدف آن و نتیجه‌ای که به دست آمد.',
      'projects.p3.t': 'پروژه نمونه ۳', 'projects.p3.d': 'توضیح کوتاهی درباره این پروژه، هدف آن و نتیجه‌ای که به دست آمد.',
      'journey.kicker': 'دفترچه', 'journey.title': 'مسیر من',
      'journey.j1.w': 'شروع', 'journey.j1.t': 'اولین قدم‌ها', 'journey.j1.d': 'آشنایی با دنیای وب و ساخت اولین صفحه‌ها.',
      'journey.j2.w': 'رشد', 'journey.j2.t': 'یادگیری و تمرین', 'journey.j2.d': 'کار روی پروژه‌های واقعی و یادگیری ابزارهای تازه.',
      'journey.j3.w': 'امروز', 'journey.j3.t': 'ساختن با کیفیت', 'journey.j3.d': 'تمرکز بر ساخت وب‌سایت‌هایی که سریع، زیبا و قابل اعتماد هستند.',
      'contact.kicker': 'ارتباط', 'contact.title': 'تماس با من',
      'contact.text': 'پروژه یا ایده‌ای دارید؟ پیام بگذارید تا در اولین فرصت پاسخ بدهم.',
      'contact.email': 'ایمیل', 'contact.phone': 'تلفن',
      'form.name': 'نام', 'form.email': 'ایمیل', 'form.message': 'پیام', 'form.send': 'ارسال پیام',
      'form.sending': 'در حال ارسال...',
      'form.ok': 'پیام شما با موفقیت ارسال شد. سپاسگزارم!',
      'form.err': 'ارسال پیام ناموفق بود. لطفاً دوباره تلاش کنید.',
      'form.invalid': 'لطفاً همه فیلدها را درست پر کنید.',
      'footer.rights': 'همه حقوق محفوظ است.', 'footer.top': 'بازگشت به بالا ↑'
    },
    en: {
      title: 'Pishtaz | Portfolio',
      skip: 'Skip to content',
      brand: 'Pishtaz',
      'nav.home': 'Home', 'nav.about': 'About', 'nav.skills': 'Skills',
      'nav.projects': 'Projects', 'nav.journey': 'Journey', 'nav.contact': 'Contact',
      'hero.eyebrow': "Hi, I'm Pishtaz",
      'hero.t1': 'I build websites and', 'hero.t2': 'experiences beyond', 'hero.t3': 'expectation',
      'hero.lead': 'Designing and developing fast, beautiful and fully responsive websites, from idea to launch.',
      'hero.cta1': 'View projects', 'hero.cta2': 'Contact me',
      'about.kicker': 'Introduction', 'about.title': 'About me',
      'about.p1': 'I am Pishtaz, passionate about building things that look great and work properly. In every project I focus on speed, simplicity and user experience.',
      'about.p2': 'This website is a place to show my work, record my learning path and get in touch with you.',
      'about.c1': 'Fast', 'about.c2': 'Clean design', 'about.c3': 'Mobile friendly', 'about.c4': 'Readable code', 'about.c5': 'Support',
      'skills.kicker': 'Abilities', 'skills.title': 'Skills',
      'skills.s1.t': 'UI design', 'skills.s1.d': 'Simple, readable and pleasant interfaces that guide users without confusion.',
      'skills.s2.t': 'Web development', 'skills.s2.d': 'Lightweight, reliable websites built with HTML, CSS and modern JavaScript.',
      'skills.s3.t': 'Responsive design', 'skills.s3.d': 'Flawless display on mobile, tablet and desktop at any screen size.',
      'skills.s4.t': 'Optimization & SEO', 'skills.s4.d': 'Fast loading and a solid structure to be found by search engines.',
      'projects.kicker': 'Portfolio', 'projects.title': 'Projects',
      'projects.p1.t': 'Sample project 1', 'projects.p1.d': 'A short description of this project, its goal and the result that was achieved.',
      'projects.p2.t': 'Sample project 2', 'projects.p2.d': 'A short description of this project, its goal and the result that was achieved.',
      'projects.p3.t': 'Sample project 3', 'projects.p3.d': 'A short description of this project, its goal and the result that was achieved.',
      'journey.kicker': 'Diary', 'journey.title': 'My journey',
      'journey.j1.w': 'Beginning', 'journey.j1.t': 'First steps', 'journey.j1.d': 'Discovering the world of the web and building my first pages.',
      'journey.j2.w': 'Growth', 'journey.j2.t': 'Learning and practice', 'journey.j2.d': 'Working on real projects and learning new tools.',
      'journey.j3.w': 'Today', 'journey.j3.t': 'Building with quality', 'journey.j3.d': 'Focused on creating websites that are fast, beautiful and trustworthy.',
      'contact.kicker': 'Get in touch', 'contact.title': 'Contact me',
      'contact.text': 'Have a project or an idea? Leave a message and I will reply as soon as possible.',
      'contact.email': 'Email', 'contact.phone': 'Phone',
      'form.name': 'Name', 'form.email': 'Email', 'form.message': 'Message', 'form.send': 'Send message',
      'form.sending': 'Sending...',
      'form.ok': 'Your message was sent successfully. Thank you!',
      'form.err': 'Sending failed. Please try again.',
      'form.invalid': 'Please fill in all fields correctly.',
      'footer.rights': 'All rights reserved.', 'footer.top': 'Back to top ↑'
    }
  };

  var root = document.documentElement;
  var lang = 'fa';

  function store(key, val) { try { localStorage.setItem(key, val); } catch (e) {} }
  function load(key) { try { return localStorage.getItem(key); } catch (e) { return null; } }

  function t(key) { return (T[lang] && T[lang][key]) || key; }

  function applyLang(l) {
    lang = T[l] ? l : 'fa';
    root.lang = lang;
    root.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.title = T[lang].title;
    var nodes = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < nodes.length; i++) {
      var k = nodes[i].getAttribute('data-i18n');
      if (T[lang][k] !== undefined) nodes[i].textContent = T[lang][k];
    }
    var btn = document.getElementById('langBtn');
    if (btn) {
      btn.textContent = lang === 'fa' ? 'EN' : 'فا';
      btn.setAttribute('aria-label', lang === 'fa' ? 'Switch to English' : 'تغییر به فارسی');
    }
    var status = document.getElementById('formStatus');
    if (status) { status.textContent = ''; status.className = 'status'; }
    store('pishtaz-lang', lang);
  }

  function initLang() {
    var saved = load('pishtaz-lang');
    if (!saved) {
      var nav = (navigator.language || 'fa').toLowerCase();
      saved = nav.indexOf('fa') === 0 ? 'fa' : 'en';
    }
    applyLang(saved);
    var btn = document.getElementById('langBtn');
    if (btn) btn.addEventListener('click', function () { applyLang(lang === 'fa' ? 'en' : 'fa'); });
  }

  /* ---------- Mobile menu ---------- */
  function initMenu() {
    var btn = document.getElementById('menuBtn');
    var nav = document.getElementById('nav');
    if (!btn || !nav) return;

    function setOpen(open) {
      nav.classList.toggle('open', open);
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    btn.addEventListener('click', function () { setOpen(!nav.classList.contains('open')); });
    nav.addEventListener('click', function (e) { if (e.target.tagName === 'A') setOpen(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setOpen(false); });
    document.addEventListener('click', function (e) {
      if (nav.classList.contains('open') && !nav.contains(e.target) && !btn.contains(e.target)) setOpen(false);
    });
    window.addEventListener('resize', function () { if (window.innerWidth > 860) setOpen(false); });
  }

  /* ---------- Header state + active link ---------- */
  function initScroll() {
    var header = document.querySelector('.site-header');
    var links = document.querySelectorAll('.nav a');
    var map = {};
    var sections = [];
    for (var i = 0; i < links.length; i++) {
      var id = (links[i].getAttribute('href') || '').replace('#', '');
      var sec = id && document.getElementById(id);
      if (sec) { map[id] = links[i]; sections.push(sec); }
    }

    function onScroll() {
      if (header) header.classList.toggle('scrolled', window.scrollY > 10);
    }
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });

    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) {
            for (var k in map) map[k].classList.remove('active');
            if (map[en.target.id]) map[en.target.id].classList.add('active');
          }
        });
      }, { rootMargin: '-45% 0px -50% 0px' });
      sections.forEach(function (s) { io.observe(s); });
    }
  }

  /* ---------- Reveal on scroll ---------- */
  function initReveal() {
    var els = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)) {
      for (var i = 0; i < els.length; i++) els[i].classList.add('in');
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    for (var j = 0; j < els.length; j++) {
      els[j].style.transitionDelay = (j % 4) * 70 + 'ms';
      io.observe(els[j]);
    }
  }

  /* ---------- Starfield ---------- */
  function initStars() {
    var canvas = document.getElementById('stars');
    if (!canvas || !canvas.getContext) return;
    var ctx = canvas.getContext('2d');
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var stars = [], w = 0, h = 0, dpr = Math.min(window.devicePixelRatio || 1, 2), raf;

    function resize() {
      w = window.innerWidth; h = window.innerHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var count = Math.round(Math.min(220, (w * h) / 7000));
      stars = [];
      for (var i = 0; i < count; i++) {
        stars.push({
          x: Math.random() * w, y: Math.random() * h,
          r: Math.random() * 1.4 + 0.2,
          a: Math.random() * 0.7 + 0.3,
          s: Math.random() * 0.02 + 0.004,
          d: Math.random() * 0.12 + 0.02,
          blue: Math.random() < 0.3
        });
      }
      draw(0);
    }

    function draw(time) {
      ctx.clearRect(0, 0, w, h);
      for (var i = 0; i < stars.length; i++) {
        var s = stars[i];
        var tw = reduce ? s.a : s.a * (0.6 + 0.4 * Math.sin(time * s.s + i));
        ctx.globalAlpha = tw;
        ctx.fillStyle = s.blue ? '#9cc4ff' : '#ffffff';
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, 6.2832);
        ctx.fill();
        if (!reduce) {
          s.y += s.d;
          if (s.y > h + 2) { s.y = -2; s.x = Math.random() * w; }
        }
      }
      ctx.globalAlpha = 1;
    }

    function loop(time) { draw(time); raf = requestAnimationFrame(loop); }

    resize();
    window.addEventListener('resize', resize);
    if (!reduce) {
      raf = requestAnimationFrame(loop);
      document.addEventListener('visibilitychange', function () {
        if (document.hidden) cancelAnimationFrame(raf); else raf = requestAnimationFrame(loop);
      });
    }
  }

  /* ---------- Contact form ---------- */
  function initForm() {
    var form = document.getElementById('contactForm');
    if (!form) return;
    var status = document.getElementById('formStatus');
    var btn = document.getElementById('sendBtn');

    function show(msg, cls) { status.textContent = msg; status.className = 'status ' + cls; }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var fields = form.querySelectorAll('input[name="name"], input[name="email"], textarea');
      var ok = true;
      for (var i = 0; i < fields.length; i++) {
        var f = fields[i];
        var valid = f.value.trim().length > 0 && (f.type !== 'email' || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.value.trim()));
        f.classList.toggle('invalid', !valid);
        if (!valid) ok = false;
      }
      if (!ok) { show(t('form.invalid'), 'err'); return; }

      btn.disabled = true;
      var original = btn.textContent;
      btn.textContent = t('form.sending');
      show('', '');

      var body = new FormData(form);
      body.append('lang', lang);

      fetch(form.getAttribute('action'), { method: 'POST', body: body, headers: { 'Accept': 'application/json' } })
        .then(function (r) { return r.json().catch(function () { return { ok: false }; }); })
        .then(function (data) {
          if (data && data.ok) { show(t('form.ok'), 'ok'); form.reset(); }
          else show(t('form.err'), 'err');
        })
        .catch(function () { show(t('form.err'), 'err'); })
        .then(function () { btn.disabled = false; btn.textContent = t(btn.getAttribute('data-i18n')) || original; });
    });
  }

  /* ---------- Init ---------- */
  function init() {
    var y = document.getElementById('year');
    if (y) y.textContent = new Date().getFullYear();
    initLang();
    initMenu();
    initScroll();
    initReveal();
    initStars();
    initForm();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
